-- =======================================================
-- SMART STORE ROOM MANAGEMENT SYSTEM
-- Database: store_room_management
-- MySQL 8.0+ Compatible Dump with Sample Data
-- =======================================================

CREATE DATABASE IF NOT EXISTS `store_room_management` 
DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `store_room_management`;

-- -------------------------------------------------------
-- Table structure for table `users`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `stock_adjustments`;
DROP TABLE IF EXISTS `stock_transactions`;
DROP TABLE IF EXISTS `items`;
DROP TABLE IF EXISTS `employees`;
DROP TABLE IF EXISTS `departments`;
DROP TABLE IF EXISTS `suppliers`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('Admin', 'Store Manager', 'Store Staff') NOT NULL DEFAULT 'Store Staff',
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_username` (`username`),
  INDEX `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `categories`
-- -------------------------------------------------------
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_cat_name` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `suppliers`
-- -------------------------------------------------------
CREATE TABLE `suppliers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `supplier_name` VARCHAR(120) NOT NULL,
  `contact_person` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `address` TEXT NOT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_supplier_name` (`supplier_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `departments`
-- -------------------------------------------------------
CREATE TABLE `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `department_name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_dept_name` (`department_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `employees`
-- -------------------------------------------------------
CREATE TABLE `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_code` VARCHAR(50) NOT NULL UNIQUE,
  `employee_name` VARCHAR(100) NOT NULL,
  `department_id` INT NOT NULL,
  `designation` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX `idx_emp_code` (`employee_code`),
  INDEX `idx_emp_dept` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `items`
-- -------------------------------------------------------
CREATE TABLE `items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `item_code` VARCHAR(50) NOT NULL UNIQUE,
  `item_name` VARCHAR(150) NOT NULL,
  `category_id` INT NOT NULL,
  `supplier_id` INT NULL,
  `unit` VARCHAR(30) NOT NULL DEFAULT 'Pieces',
  `description` TEXT NULL,
  `minimum_stock` INT NOT NULL DEFAULT 5,
  `reorder_level` INT NOT NULL DEFAULT 10,
  `maximum_stock` INT NOT NULL DEFAULT 100,
  `current_stock` INT NOT NULL DEFAULT 0,
  `purchase_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `selling_or_issue_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `location` VARCHAR(100) NOT NULL DEFAULT 'Main Store Room',
  `rack_no` VARCHAR(50) NOT NULL DEFAULT 'R-01',
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  INDEX `idx_item_code` (`item_code`),
  INDEX `idx_item_category` (`category_id`),
  INDEX `idx_item_supplier` (`supplier_id`),
  INDEX `idx_current_stock` (`current_stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `stock_transactions`
-- -------------------------------------------------------
CREATE TABLE `stock_transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_code` VARCHAR(50) NOT NULL UNIQUE,
  `item_id` INT NOT NULL,
  `transaction_type` ENUM('IN', 'OUT', 'RETURN', 'ADJUSTMENT') NOT NULL,
  `quantity` INT NOT NULL,
  `previous_stock` INT NOT NULL,
  `new_stock` INT NOT NULL,
  `supplier_id` INT NULL,
  `employee_id` INT NULL,
  `department_id` INT NULL,
  `unit_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `reference_no` VARCHAR(100) NULL,
  `remarks` TEXT NULL,
  `transaction_date` DATE NOT NULL,
  `created_by` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX `idx_tx_type` (`transaction_type`),
  INDEX `idx_tx_item` (`item_id`),
  INDEX `idx_tx_date` (`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table structure for table `stock_adjustments`
-- -------------------------------------------------------
CREATE TABLE `stock_adjustments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `item_id` INT NOT NULL,
  `old_quantity` INT NOT NULL,
  `new_quantity` INT NOT NULL,
  `difference` INT NOT NULL,
  `reason` TEXT NOT NULL,
  `adjusted_by` INT NOT NULL,
  `adjustment_date` DATE NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX `idx_adj_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =======================================================
-- SAMPLE DATA INSERTION
-- Password for all demo accounts is: admin123
-- BCrypt hash: $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
-- =======================================================

-- Users (1 Admin, 1 Store Manager, 1 Store Staff)
INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `role`, `status`) VALUES
(1, 'System Administrator', 'admin', 'admin@smartstore.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'Active'),
(2, 'Vikas Sharma', 'manager', 'manager@smartstore.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Store Manager', 'Active'),
(3, 'Rajesh Verma', 'staff', 'staff@smartstore.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Store Staff', 'Active');

-- Categories (5 Categories)
INSERT INTO `categories` (`id`, `category_name`, `description`, `status`) VALUES
(1, 'Office Stationery', 'Pens, notebooks, printer paper, toner, and general desk supplies', 'Active'),
(2, 'IT Hardware & Peripherals', 'Keyboards, mice, HDMI cables, adapters, and networking accessories', 'Active'),
(3, 'Electrical & Lighting', 'LED fixtures, extension cords, fuses, and power strips', 'Active'),
(4, 'Safety & PPE Equipment', 'Helmets, safety goggles, reflective vests, and fire blankets', 'Active'),
(5, 'Facility & Cleaning Supplies', 'Disinfectants, hand sanitizers, microfiber towels, and soap dispensers', 'Active');

-- Suppliers (5 Suppliers)
INSERT INTO `suppliers` (`id`, `supplier_name`, `contact_person`, `phone`, `email`, `address`, `status`) VALUES
(1, 'Apex Global Stationery Ltd', 'Michael Scott', '+1 (555) 234-8901', 'orders@apexstationery.com', '124 Commerce Blvd, Suite 400, Chicago, IL', 'Active'),
(2, 'Nexus IT Distribution Inc', 'Sarah Connor', '+1 (555) 345-6712', 'sales@nexusitcorp.com', '88 Silicon Parkway, Austin, TX', 'Active'),
(3, 'Vanguard Industrial Supply', 'Bruce Wayne', '+1 (555) 456-7823', 'contact@vanguardind.com', '700 Industrial Row, Detroit, MI', 'Active'),
(4, 'ProSafe Gear & Equipment', 'Diana Prince', '+1 (555) 567-8934', 'orders@prosafegear.com', '45 Defense Ave, Columbus, OH', 'Active'),
(5, 'SparkClean Commercial Essentials', 'Arthur Dent', '+1 (555) 678-9045', 'supply@sparkclean.com', '910 Harbor Road, Seattle, WA', 'Active');

-- Departments (5 Departments)
INSERT INTO `departments` (`id`, `department_name`, `description`, `status`) VALUES
(1, 'Information Technology', 'Software development, infrastructure, cybersecurity, and hardware support', 'Active'),
(2, 'Operations & Logistics', 'Warehouse logistics, dispatch, shipping, and supply chain control', 'Active'),
(3, 'Human Resources', 'Recruitment, talent retention, payroll, and employee onboarding', 'Active'),
(4, 'Finance & Accounting', 'Corporate budgeting, billing, accounts payable, and auditing', 'Active'),
(5, 'Facilities & Maintenance', 'Building operations, electrical safety, plumbing, and janitorial services', 'Active');

-- Employees (10 Employees)
INSERT INTO `employees` (`id`, `employee_code`, `employee_name`, `department_id`, `designation`, `phone`, `email`, `status`) VALUES
(1, 'EMP-1001', 'Alex Johnson', 1, 'Senior Cloud Engineer', '+1 (555) 101-1122', 'alex.j@company.org', 'Active'),
(2, 'EMP-1002', 'Emily Davis', 1, 'Systems Administrator', '+1 (555) 101-1123', 'emily.d@company.org', 'Active'),
(3, 'EMP-1003', 'Carlos Rodriguez', 2, 'Logistics Supervisor', '+1 (555) 101-1124', 'carlos.r@company.org', 'Active'),
(4, 'EMP-1004', 'Maria Gonzalez', 2, 'Inventory Auditor', '+1 (555) 101-1125', 'maria.g@company.org', 'Active'),
(5, 'EMP-1005', 'David Kim', 3, 'HR Business Partner', '+1 (555) 101-1126', 'david.k@company.org', 'Active'),
(6, 'EMP-1006', 'Hannah Smith', 3, 'Talent Acquisition Specialist', '+1 (555) 101-1127', 'hannah.s@company.org', 'Active'),
(7, 'EMP-1007', 'Robert Chen', 4, 'Senior Financial Analyst', '+1 (555) 101-1128', 'robert.c@company.org', 'Active'),
(8, 'EMP-1008', 'Sophia Taylor', 4, 'Accounts Payable Lead', '+1 (555) 101-1129', 'sophia.t@company.org', 'Active'),
(9, 'EMP-1009', 'Marcus Miller', 5, 'Chief Maintenance Technician', '+1 (555) 101-1130', 'marcus.m@company.org', 'Active'),
(10, 'EMP-1010', 'Chloe Wilson', 5, 'Safety & Compliance Officer', '+1 (555) 101-1131', 'chloe.w@company.org', 'Active');

-- Items (20 items spanning Healthy, Low Stock, and Out of Stock)
INSERT INTO `items` (`id`, `item_code`, `item_name`, `category_id`, `supplier_id`, `unit`, `description`, `minimum_stock`, `reorder_level`, `maximum_stock`, `current_stock`, `purchase_price`, `selling_or_issue_price`, `location`, `rack_no`, `status`) VALUES
(1, 'ITM-0001', 'A4 Multipurpose Copy Paper 80GSM (Box of 5 Reams)', 1, 1, 'Boxes', 'High brightness paper for laser and inkjet printers', 10, 25, 150, 48, 28.50, 32.00, 'Main Store Room', 'A-01', 'Active'),
(2, 'ITM-0002', 'Pilot G2 0.7mm Rollerball Gel Pens (Black, Box 12)', 1, 1, 'Boxes', 'Smooth gel ink archival quality pens', 5, 12, 80, 8, 14.20, 16.50, 'Main Store Room', 'A-02', 'Active'),
(3, 'ITM-0003', 'Heavy Duty Stapler & Staples Bundle', 1, 1, 'Sets', 'Capacity up to 100 sheets with 5000 pins', 3, 6, 30, 2, 22.00, 25.00, 'Main Store Room', 'A-03', 'Active'),
(4, 'ITM-0004', 'Sticky Notes 3x3 Pastel Assorted (Pack 12)', 1, 1, 'Packs', 'Strong adhesion self-adhesive reminder pads', 8, 15, 100, 0, 9.80, 11.50, 'Main Store Room', 'A-04', 'Active'),
(5, 'ITM-0005', 'Wireless Ergonomic Optical Mouse', 2, 2, 'Pieces', '2.4GHz silent click with adjustable DPI', 6, 12, 60, 24, 18.00, 22.00, 'Electronics Bay', 'B-01', 'Active'),
(6, 'ITM-0006', 'Braided 4K HDMI Cable 2.0 (2 Meters)', 2, 2, 'Pieces', 'Gold plated connectors high speed 18Gbps', 10, 20, 100, 16, 7.50, 9.50, 'Electronics Bay', 'B-02', 'Active'),
(7, 'ITM-0007', 'USB-C Multiport 7-in-1 Adapter Hub', 2, 2, 'Pieces', 'HDMI 4K, 100W PD, 3x USB 3.0, SD Card', 4, 8, 40, 0, 34.00, 40.00, 'Electronics Bay', 'B-03', 'Active'),
(8, 'ITM-0008', 'Cat6 Snagless Gigabit Ethernet Cable (10M)', 2, 2, 'Pieces', 'High performance RJ45 LAN network patch cords', 12, 25, 120, 62, 6.20, 8.00, 'Electronics Bay', 'B-04', 'Active'),
(9, 'ITM-0009', 'Mechanical Backlit Keyboard (US Layout)', 2, 2, 'Pieces', 'Tactile switch corporate edition keyboard', 5, 10, 45, 11, 45.00, 52.00, 'Electronics Bay', 'B-05', 'Active'),
(10, 'ITM-0010', 'Heavy Duty 6-Outlet Surge Protector Extension (5M)', 3, 3, 'Pieces', 'Surge suppression 1800 Joules with circuit breaker', 8, 15, 75, 5, 19.50, 23.00, 'Electrical Rack', 'C-01', 'Active'),
(11, 'ITM-0011', 'Industrial AAA Alkaline Batteries (Pack of 24)', 3, 3, 'Packs', '10-year shelf life leak-proof alkaline cells', 10, 20, 100, 38, 12.00, 15.00, 'Electrical Rack', 'C-02', 'Active'),
(12, 'ITM-0012', 'Energy Saving LED Tube Light 18W T8', 3, 3, 'Pieces', 'Cool daylight 6500K 1200mm commercial grade', 15, 30, 150, 22, 5.80, 7.20, 'Electrical Rack', 'C-03', 'Active'),
(13, 'ITM-0013', 'Digital Multimeter with Auto-Ranging', 3, 3, 'Pieces', 'Measures voltage, current, resistance and continuity', 2, 4, 15, 6, 38.00, 44.00, 'Electrical Rack', 'C-04', 'Active'),
(14, 'ITM-0014', 'OSHA Approved High-Impact Safety Helmets', 4, 4, 'Pieces', 'Vented hard hat with adjustable ratchet suspension', 6, 12, 50, 19, 16.50, 20.00, 'Safety Vault', 'D-01', 'Active'),
(15, 'ITM-0015', 'Anti-Fog Chemical Splash Safety Goggles', 4, 4, 'Pairs', 'Clear polycarbonate scratch-resistant wide view', 10, 20, 80, 0, 4.50, 6.00, 'Safety Vault', 'D-02', 'Active'),
(16, 'ITM-0016', 'High Visibility Reflective Vest Class 2 (XL)', 4, 4, 'Pieces', 'Fluorescent yellow with 2-inch silver reflective tape', 8, 16, 80, 7, 7.80, 9.50, 'Safety Vault', 'D-03', 'Active'),
(17, 'ITM-0017', 'Nitrile Chemical Resistant Work Gloves (Box of 100)', 4, 4, 'Boxes', 'Powder-free 6 mil puncture resistant', 10, 25, 120, 54, 15.00, 18.00, 'Safety Vault', 'D-04', 'Active'),
(18, 'ITM-0018', 'Industrial Hand Sanitizer Gel 5-Liter Jug', 5, 5, 'Jugs', '75% Isopropyl alcohol hospital grade with pump', 4, 10, 40, 3, 24.00, 28.00, 'Sanitation Deck', 'E-01', 'Active'),
(19, 'ITM-0019', 'Commercial Microfiber Cleaning Towels (Pack of 36)', 5, 5, 'Packs', 'Lint-free, scratch-free multi-surface cloths', 8, 15, 80, 42, 18.50, 22.00, 'Sanitation Deck', 'E-02', 'Active'),
(20, 'ITM-0020', 'Automatic Wall-Mounted Hand Soap Dispenser', 5, 5, 'Pieces', 'Touchless infrared sensor 1000ml reservoir', 3, 8, 35, 14, 29.00, 35.00, 'Sanitation Deck', 'E-03', 'Active');

-- Stock Transactions (Sample Transactions)
INSERT INTO `stock_transactions` (`id`, `transaction_code`, `item_id`, `transaction_type`, `quantity`, `previous_stock`, `new_stock`, `supplier_id`, `employee_id`, `department_id`, `unit_price`, `reference_no`, `remarks`, `transaction_date`, `created_by`) VALUES
(1, 'TXN-20260901-001', 1, 'IN', 60, 0, 60, 1, NULL, NULL, 28.50, 'INV-APEX-8891', 'Initial bulk stock intake for Q3', '2026-09-01', 1),
(2, 'TXN-20260901-002', 5, 'IN', 30, 0, 30, 2, NULL, NULL, 18.00, 'INV-NEXUS-4401', 'Procurement for new onboarding batches', '2026-09-01', 1),
(3, 'TXN-20260902-001', 1, 'OUT', 12, 60, 48, NULL, 5, 3, 32.00, 'REQ-HR-0045', 'Issued for corporate training & orientation packets', '2026-09-02', 2),
(4, 'TXN-20260902-002', 5, 'OUT', 6, 30, 24, NULL, 1, 1, 22.00, 'REQ-IT-0098', 'Issued for software engineering team expansion', '2026-09-02', 2),
(5, 'TXN-20260903-001', 4, 'OUT', 15, 15, 0, NULL, 7, 4, 11.50, 'REQ-FIN-0112', 'Quarterly fiscal review audit workbooks', '2026-09-03', 3),
(6, 'TXN-20260904-001', 7, 'OUT', 8, 8, 0, NULL, 2, 1, 40.00, 'REQ-IT-0104', 'Conference room display connectors replacement', '2026-09-04', 2),
(7, 'TXN-20260905-001', 5, 'RETURN', 2, 22, 24, NULL, 1, 1, 22.00, 'RET-IT-0012', 'Returned surplus unused ergonomic mouse from dev lab', '2026-09-05', 3),
(8, 'TXN-20260906-001', 10, 'OUT', 10, 15, 5, NULL, 9, 5, 23.00, 'REQ-FAC-0082', 'Server room auxiliary power upgrade maintenance', '2026-09-06', 2),
(9, 'TXN-20260907-001', 2, 'OUT', 6, 14, 8, NULL, 6, 3, 16.50, 'REQ-HR-0056', 'New hires stationery kits distribution', '2026-09-07', 3),
(10, 'TXN-20260907-002', 18, 'OUT', 7, 10, 3, NULL, 10, 5, 28.00, 'REQ-FAC-0089', 'Monthly sanitation stations refill cycle', '2026-09-07', 2);

-- Sample Stock Adjustments
INSERT INTO `stock_adjustments` (`id`, `item_id`, `old_quantity`, `new_quantity`, `difference`, `reason`, `adjusted_by`, `adjustment_date`) VALUES
(1, 3, 5, 2, -3, 'Physical audit reconciliation: 3 units damaged due to water leak in Rack A-03', 1, '2026-09-04'),
(2, 9, 10, 11, 1, 'Uncounted sealed backup box discovered during routine shelf reorganization', 2, '2026-09-05');
