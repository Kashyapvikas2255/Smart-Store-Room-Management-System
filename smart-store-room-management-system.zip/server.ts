import express from 'express';
import { spawn, ChildProcess } from 'child_process';
import http from 'http';
import path from 'path';

const app = express();
const PORT = 3000;
const PHP_PORT = 8085;

const storeRoomDir = path.join(process.cwd(), 'store-room-management');

// Spawn PHP built-in web server
let phpProcess: ChildProcess | null = null;
let isShuttingDown = false;

function startPhpServer() {
  if (isShuttingDown) return;
  console.log(`Starting PHP built-in server on 127.0.0.1:${PHP_PORT} rooted at ${storeRoomDir}...`);
  phpProcess = spawn('php', ['-S', `127.0.0.1:${PHP_PORT}`, '-t', storeRoomDir], {
    stdio: 'inherit',
  });

  phpProcess.on('error', (err) => {
    console.error('PHP server execution error:', err);
  });

  phpProcess.on('exit', (code, signal) => {
    console.log(`PHP server stopped (code: ${code}, signal: ${signal})`);
    if (!isShuttingDown) {
      console.log('Restarting PHP server in 1 second...');
      setTimeout(startPhpServer, 1000);
    }
  });
}

startPhpServer();

// Clean up child process on exit
process.on('SIGINT', () => {
  isShuttingDown = true;
  if (phpProcess) phpProcess.kill('SIGINT');
  process.exit();
});

process.on('SIGTERM', () => {
  isShuttingDown = true;
  if (phpProcess) phpProcess.kill('SIGTERM');
  process.exit();
});

// Proxy HTTP requests directly to PHP built-in server
app.use((req, res) => {
  const forwardedProto = (req.headers['x-forwarded-proto'] as string) || 'https';
  const options: http.RequestOptions = {
    hostname: '127.0.0.1',
    port: PHP_PORT,
    path: req.url,
    method: req.method,
    headers: {
      ...req.headers,
      host: `127.0.0.1:${PHP_PORT}`,
      'x-forwarded-for': req.socket.remoteAddress || '',
      'x-forwarded-proto': forwardedProto,
    },
  };

  const proxyReq = http.request(options, (proxyRes) => {
    // Clone headers
    const headers: http.OutgoingHttpHeaders = { ...proxyRes.headers };

    // Ensure session cookies are compatible with cross-site iframes (SameSite=None, Secure, Partitioned)
    if (headers['set-cookie']) {
      const rawCookies = Array.isArray(headers['set-cookie'])
        ? headers['set-cookie']
        : [headers['set-cookie']];

      headers['set-cookie'] = rawCookies.map((cookie) => {
        let c = cookie;
        if (!c.toLowerCase().includes('path=')) {
          c += '; Path=/';
        }
        if (c.toLowerCase().includes('samesite=')) {
          c = c.replace(/SameSite=(Lax|Strict)/gi, 'SameSite=None');
        } else {
          c += '; SameSite=None';
        }
        if (!c.toLowerCase().includes('secure')) {
          c += '; Secure';
        }
        if (!c.toLowerCase().includes('partitioned')) {
          c += '; Partitioned';
        }
        return c;
      });
    }

    res.writeHead(proxyRes.statusCode || 200, headers);
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (err) => {
    console.error('Proxy routing error:', err.message);
    res.status(503).send(`
      <html>
        <head><title>Store Room System Starting...</title></head>
        <body style="font-family:sans-serif;text-align:center;padding:50px;">
          <h2>Smart Store Room Management System Initializing...</h2>
          <p>Please wait a few seconds and <a href="javascript:location.reload()">refresh</a>.</p>
        </body>
      </html>
    `);
  });

  if (req.method && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method.toUpperCase())) {
    req.pipe(proxyReq);
  } else {
    proxyReq.end();
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Production Reverse Proxy server listening on http://0.0.0.0:${PORT} -> PHP:${PHP_PORT}`);
});
