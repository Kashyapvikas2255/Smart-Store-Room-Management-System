<?php
/**
 * Smart Store Room Management System
 * Low Stock Alerts & Reorder Requirements
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Low Stock Alerts';
$db = Database::getConnection();

// Query items where current_stock <= reorder_level AND current_stock > 0
$sql = "
    SELECT 
        i.*,
        c.category_name,
        s.supplier_name,
        s.contact_person,
        s.phone as supplier_phone,
        (i.maximum_stock - i.current_stock) as suggested_reorder_qty
    FROM items i
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    WHERE i.status = 'Active' 
      AND i.current_stock <= i.reorder_level 
      AND i.current_stock > 0
    ORDER BY (i.current_stock / i.reorder_level) ASC, i.item_name ASC
";
$items = $db->query($sql)->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <div class="d-flex align-items-center gap-2 mb-1">
      <span class="badge bg-warning text-dark fs-6 px-3 py-1">
        <i class="fa-solid fa-triangle-exclamation me-1"></i> Threshold Alerts
      </span>
      <span class="badge bg-light text-dark border"><?= count($items) ?> Items Requiring Reorder</span>
    </div>
    <h3 class="fw-bold mb-0 text-dark">Low Stock Alert List</h3>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Procurement Sheet
    </button>
    <a href="../reports/inventory-summary.php" class="btn btn-outline-primary">
      <i class="fa-solid fa-chart-pie me-1"></i> Inventory Summary
    </a>
  </div>
</div>

<div class="alert alert-warning border-0 shadow-sm d-flex align-items-center gap-3 mb-4 rounded-3" role="alert">
  <div class="fs-2 text-warning"><i class="fa-solid fa-boxes-packing"></i></div>
  <div>
    <strong>Action Required:</strong> The following items are below their defined reorder threshold points. Expedite purchase orders to preferred vendors to prevent out-of-stock operational halts.
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Item Code</th>
          <th>Item Details</th>
          <th>Location / Rack</th>
          <th>Current Stock</th>
          <th>Reorder Level</th>
          <th>Suggested Reorder Qty</th>
          <th>Primary Vendor</th>
          <th class="text-end">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($items)): ?>
          <tr>
            <td colspan="8" class="text-center py-5 text-muted">
              <i class="fa-solid fa-circle-check fs-2 text-success mb-2 d-block"></i>
              No low stock items detected! All inventory is adequately stocked above reorder thresholds.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($items as $item): ?>
            <tr>
              <td>
                <span class="font-monospace fw-bold text-dark"><?= e($item['item_code']) ?></span>
              </td>
              <td>
                <div class="fw-bold text-dark">
                  <a href="../items/view.php?id=<?= $item['id'] ?>" class="text-decoration-none text-dark hover-primary">
                    <?= e($item['item_name']) ?>
                  </a>
                </div>
                <small class="text-muted"><?= e($item['category_name']) ?> &bull; Unit Cost: <?= format_currency($item['purchase_price']) ?></small>
              </td>
              <td>
                <span class="small fw-medium text-dark"><?= e($item['location']) ?></span>
                <div class="text-muted fs-xs">Rack: <?= e($item['rack_no']) ?></div>
              </td>
              <td>
                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle fs-6 fw-bold px-2 py-1">
                  <?= $item['current_stock'] ?> <?= e($item['unit']) ?>
                </span>
              </td>
              <td>
                <span class="text-muted fw-semibold"><?= $item['reorder_level'] ?> <?= e($item['unit']) ?></span>
              </td>
              <td>
                <strong class="text-primary">+<?= max(1, $item['suggested_reorder_qty']) ?> <?= e($item['unit']) ?></strong>
                <div class="text-muted fs-xs">To max (<?= $item['maximum_stock'] ?>)</div>
              </td>
              <td>
                <div class="fw-medium text-dark small"><?= e($item['supplier_name'] ?? 'Not Assigned') ?></div>
                <?php if (!empty($item['supplier_phone'])): ?>
                  <small class="text-muted"><i class="fa-solid fa-phone me-1"></i><?= e($item['supplier_phone']) ?></small>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a href="../stock/stock-in.php?item_id=<?= $item['id'] ?>" class="btn btn-sm btn-success text-nowrap">
                  <i class="fa-solid fa-arrow-down-to-bracket me-1"></i> Restock
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
