<?php
/**
 * Smart Store Room Management System
 * Out of Stock Emergency Alerts
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Out of Stock Alerts';
$db = Database::getConnection();

// Query items where current_stock = 0
$sql = "
    SELECT 
        i.*,
        c.category_name,
        s.supplier_name,
        s.contact_person,
        s.phone as supplier_phone,
        s.email as supplier_email
    FROM items i
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    WHERE i.status = 'Active' AND i.current_stock = 0
    ORDER BY i.item_name ASC
";
$items = $db->query($sql)->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <div class="d-flex align-items-center gap-2 mb-1">
      <span class="badge bg-danger fs-6 px-3 py-1">
        <i class="fa-solid fa-circle-exclamation me-1"></i> Stockout Critical
      </span>
      <span class="badge bg-light text-dark border"><?= count($items) ?> Zero-Stock SKUs</span>
    </div>
    <h3 class="fw-bold mb-0 text-dark">Out of Stock Alert Roster</h3>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Stockout List
    </button>
    <a href="../stock/stock-in.php" class="btn btn-success">
      <i class="fa-solid fa-arrow-down-to-bracket me-1"></i> Receive Stock In
    </a>
  </div>
</div>

<?php if (!empty($items)): ?>
  <div class="alert alert-danger border-0 shadow-sm d-flex align-items-center gap-3 mb-4 rounded-3" role="alert">
    <div class="fs-2 text-danger"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div>
      <strong>Critical Deficiency Warning:</strong> The items listed below are entirely depleted. Internal requisitions for these items are currently blocked until replacement shipments arrive.
    </div>
  </div>
<?php endif; ?>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Item Code</th>
          <th>Item Description</th>
          <th>Category</th>
          <th>Store Bin</th>
          <th>Stock Balance</th>
          <th>Reorder Target</th>
          <th>Supplier Contact</th>
          <th class="text-end">Emergency Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($items)): ?>
          <tr>
            <td colspan="8" class="text-center py-5 text-muted">
              <i class="fa-solid fa-box-archive fs-2 text-success mb-2 d-block"></i>
              No out-of-stock items detected! All items currently have inventory available.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($items as $item): ?>
            <tr>
              <td>
                <span class="font-monospace fw-bold text-danger"><?= e($item['item_code']) ?></span>
              </td>
              <td>
                <div class="fw-bold text-dark">
                  <a href="../items/view.php?id=<?= $item['id'] ?>" class="text-decoration-none text-dark hover-primary">
                    <?= e($item['item_name']) ?>
                  </a>
                </div>
                <small class="text-muted"><?= e($item['unit']) ?> &bull; Unit Cost: <?= format_currency($item['purchase_price']) ?></small>
              </td>
              <td>
                <span class="badge bg-light text-dark border"><?= e($item['category_name']) ?></span>
              </td>
              <td>
                <span class="small fw-medium text-dark"><?= e($item['location']) ?></span>
                <div class="text-muted fs-xs">Rack: <?= e($item['rack_no']) ?></div>
              </td>
              <td>
                <span class="badge bg-danger fs-6 fw-bold px-3 py-1">
                  0 <?= e($item['unit']) ?>
                </span>
              </td>
              <td>
                <span class="text-muted fw-semibold"><?= $item['reorder_level'] ?> <?= e($item['unit']) ?> min</span>
              </td>
              <td>
                <div class="fw-medium text-dark small"><?= e($item['supplier_name'] ?? 'No supplier') ?></div>
                <?php if (!empty($item['supplier_phone'])): ?>
                  <small class="text-muted d-block"><i class="fa-solid fa-phone me-1"></i><?= e($item['supplier_phone']) ?></small>
                <?php endif; ?>
                <?php if (!empty($item['supplier_email'])): ?>
                  <small class="text-muted d-block"><i class="fa-solid fa-envelope me-1"></i><?= e($item['supplier_email']) ?></small>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a href="../stock/stock-in.php?item_id=<?= $item['id'] ?>" class="btn btn-sm btn-success text-nowrap">
                  <i class="fa-solid fa-arrow-down-to-bracket me-1"></i> Immediate Stock In
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
