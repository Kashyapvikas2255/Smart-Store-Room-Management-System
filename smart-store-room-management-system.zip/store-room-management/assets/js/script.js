/**
 * Smart Store Room Management System
 * Main Frontend Script
 */

document.addEventListener('DOMContentLoaded', function () {
  // Sidebar Toggle for Mobile & Desktop
  const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebarBackdrop');

  if (sidebarToggleBtn && sidebar) {
    sidebarToggleBtn.addEventListener('click', function () {
      if (window.innerWidth < 992) {
        sidebar.classList.toggle('show');
        if (backdrop) {
          backdrop.classList.toggle('show');
        }
      } else {
        document.body.classList.toggle('sidebar-collapsed');
      }
    });
  }

  if (backdrop) {
    backdrop.addEventListener('click', function () {
      sidebar.classList.remove('show');
      backdrop.classList.remove('show');
    });
  }

  // Auto-dismiss Flash Alerts after 5 seconds
  const autoAlerts = document.querySelectorAll('.alert-dismissible');
  autoAlerts.forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) {
        bsAlert.close();
      }
    }, 6000);
  });

  // Dynamic stock difference calculator for Adjustment Form
  const currentStockInput = document.getElementById('adj_current_stock');
  const newStockInput = document.getElementById('adj_new_stock');
  const diffDisplay = document.getElementById('adj_difference');
  const diffHidden = document.getElementById('adj_difference_val');

  if (currentStockInput && newStockInput && diffDisplay) {
    function calcDiff() {
      const current = parseInt(currentStockInput.value) || 0;
      const next = parseInt(newStockInput.value) || 0;
      const diff = next - current;
      diffDisplay.textContent = (diff > 0 ? '+' : '') + diff;
      diffDisplay.className = 'badge ' + (diff > 0 ? 'bg-success' : (diff < 0 ? 'bg-danger' : 'bg-secondary')) + ' fs-6 px-3 py-2';
      if (diffHidden) {
        diffHidden.value = diff;
      }
    }
    newStockInput.addEventListener('input', calcDiff);
  }

  // Stock Out Validation: Check Available Quantity
  const stockOutForm = document.getElementById('stockOutForm');
  const stockOutItemSelect = document.getElementById('stock_out_item');
  const stockOutQty = document.getElementById('stock_out_qty');
  const availableStockNotice = document.getElementById('availableStockNotice');

  if (stockOutItemSelect) {
    stockOutItemSelect.addEventListener('change', function () {
      const selectedOption = this.options[this.selectedIndex];
      const stock = parseInt(selectedOption.getAttribute('data-stock')) || 0;
      if (availableStockNotice) {
        availableStockNotice.textContent = `Available in Store: ${stock} units`;
        availableStockNotice.className = stock > 0 ? 'text-success fw-bold' : 'text-danger fw-bold';
      }
    });
  }

  if (stockOutForm && stockOutItemSelect && stockOutQty) {
    stockOutForm.addEventListener('submit', function (e) {
      const selectedOption = stockOutItemSelect.options[stockOutItemSelect.selectedIndex];
      const stock = parseInt(selectedOption.getAttribute('data-stock')) || 0;
      const req = parseInt(stockOutQty.value) || 0;
      if (req > stock) {
        e.preventDefault();
        alert(`Insufficient stock available! Current stock is ${stock}, but requested quantity is ${req}.`);
      }
    });
  }
});

// Confirmation Dialog Helper
function confirmAction(message, url) {
  if (confirm(message || 'Are you sure you want to proceed?')) {
    window.location.href = url;
  }
}
