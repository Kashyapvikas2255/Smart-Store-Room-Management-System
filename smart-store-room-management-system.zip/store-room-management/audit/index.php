<?php
/**
 * Smart Store Room Management System
 * Physical Stock Audit & Verification Dashboard
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Physical Stock Audit & Verification';
$db = Database::getConnection();
$is_manager_or_admin = has_role(['Admin', 'Store Manager']);

// CSV Export of Audits
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $rows = $db->query("
        SELECT 
            sa.audit_code,
            sa.title,
            COALESCE(c.category_name, 'All Store Room Categories') as category_scope,
            sa.status,
            sa.total_items,
            sa.matched_items,
            sa.discrepant_items,
            sa.net_variance_qty,
            sa.net_variance_value,
            u.name as conducted_by_name,
            sa.created_at,
            sa.completed_at,
            sa.remarks
        FROM stock_audits sa
        LEFT JOIN categories c ON sa.category_id = c.id
        LEFT JOIN users u ON sa.conducted_by = u.id
        ORDER BY sa.id DESC
    ")->fetchAll();

    $headers = [
        'Audit Code', 'Title', 'Category Scope', 'Status', 'Total Items Audited',
        'Matched Items', 'Discrepant Items', 'Net Variance Qty', 'Net Variance Value ($)',
        'Auditor Name', 'Started At', 'Completed At', 'Remarks'
    ];
    $export_rows = [];
    foreach ($rows as $r) {
        $export_rows[] = [
            $r['audit_code'],
            $r['title'],
            $r['category_scope'],
            $r['status'],
            $r['total_items'],
            $r['matched_items'],
            $r['discrepant_items'],
            $r['net_variance_qty'],
            $r['net_variance_value'],
            $r['conducted_by_name'],
            $r['created_at'],
            $r['completed_at'] ?? 'In Progress',
            $r['remarks'] ?? ''
        ];
    }
    export_to_csv('Stock_Audits_Summary_' . date('Y-m-d') . '.csv', $headers, $export_rows);
}

// Fetch metrics
$metric_stmt = $db->query("
    SELECT 
        COUNT(*) as total_audits,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed_audits,
        SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_audits,
        SUM(discrepant_items) as total_discrepancies,
        SUM(net_variance_value) as net_variance_sum
    FROM stock_audits
");
$metrics = $metric_stmt->fetch();

// Fetch audit sessions list
$audits = $db->query("
    SELECT 
        sa.*,
        c.category_name,
        u.name as conducted_by_name
    FROM stock_audits sa
    LEFT JOIN categories c ON sa.category_id = c.id
    LEFT JOIN users u ON sa.conducted_by = u.id
    ORDER BY sa.id DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="container-fluid p-0">
  <!-- Page Header -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
      <h3 class="fw-bold mb-1 text-dark">Physical Stock Audit & Verification</h3>
      <p class="text-muted small mb-0">Periodic stock-taking, count reconciliation, variance tracking, and inventory certification</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a href="index.php?export=csv" class="btn btn-outline-success d-flex align-items-center gap-2">
        <i class="fa-solid fa-file-excel"></i>
        <span>Export CSV</span>
      </a>
      <?php if ($is_manager_or_admin): ?>
        <a href="start.php" class="btn btn-primary d-flex align-items-center gap-2">
          <i class="fa-solid fa-play"></i>
          <span>Start New Stock Audit</span>
        </a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Metric Badges -->
  <div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
      <div class="card stat-card border-0 shadow-sm">
        <div class="card-body p-3 d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-semibold text-uppercase">Total Audits</span>
            <h3 class="fw-bold mb-0 text-dark"><?= (int)($metrics['total_audits'] ?? 0) ?></h3>
            <span class="text-xs text-muted">Stock-taking verification cycles</span>
          </div>
          <div class="rounded-3 p-3 bg-primary-subtle text-primary fs-3">
            <i class="fa-solid fa-clipboard-check"></i>
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-6 col-xl-3">
      <div class="card stat-card border-0 shadow-sm">
        <div class="card-body p-3 d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-semibold text-uppercase">Completed Audits</span>
            <h3 class="fw-bold mb-0 text-success"><?= (int)($metrics['completed_audits'] ?? 0) ?></h3>
            <span class="text-xs text-muted">Reconciled & verified</span>
          </div>
          <div class="rounded-3 p-3 bg-success-subtle text-success fs-3">
            <i class="fa-solid fa-check-double"></i>
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-6 col-xl-3">
      <div class="card stat-card border-0 shadow-sm">
        <div class="card-body p-3 d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-semibold text-uppercase">Discrepancies Resolved</span>
            <h3 class="fw-bold mb-0 text-warning"><?= (int)($metrics['total_discrepancies'] ?? 0) ?></h3>
            <span class="text-xs text-muted">Variance items identified</span>
          </div>
          <div class="rounded-3 p-3 bg-warning-subtle text-warning fs-3">
            <i class="fa-solid fa-scale-unbalanced"></i>
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-6 col-xl-3">
      <div class="card stat-card border-0 shadow-sm">
        <div class="card-body p-3 d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-semibold text-uppercase">Net Variance Value</span>
            <h3 class="fw-bold mb-0 <?= ((float)($metrics['net_variance_sum'] ?? 0) < 0) ? 'text-danger' : 'text-success' ?>">
              <?= format_currency($metrics['net_variance_sum'] ?? 0) ?>
            </h3>
            <span class="text-xs text-muted">Audited financial reconciliation</span>
          </div>
          <div class="rounded-3 p-3 bg-secondary-subtle text-secondary fs-3">
            <i class="fa-solid fa-file-invoice-dollar"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Audit Sessions Table -->
  <div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
      <h6 class="fw-bold mb-0 text-dark">
        <i class="fa-solid fa-list-check text-primary me-2"></i>Physical Audit Sessions & History
      </h6>
    </div>
    <div class="table-responsive">
      <table class="table align-middle table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Audit Code & Title</th>
            <th>Scope / Category</th>
            <th>Auditor / In-Charge</th>
            <th class="text-center">Count Stats</th>
            <th class="text-center">Net Variance</th>
            <th class="text-center">Status</th>
            <th class="text-end pe-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($audits)): ?>
            <tr>
              <td colspan="7" class="text-center py-5 text-muted">
                <i class="fa-solid fa-box-open fs-1 text-secondary opacity-50 mb-3 d-block"></i>
                <h6 class="fw-semibold">No stock audits conducted yet</h6>
                <p class="small text-muted mb-3">Begin physical inventory counting to verify shelf balances against system stock.</p>
                <?php if ($is_manager_or_admin): ?>
                  <a href="start.php" class="btn btn-sm btn-primary">Start First Audit Session</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($audits as $aud): ?>
              <tr>
                <td>
                  <span class="font-monospace fw-bold text-primary"><?= e($aud['audit_code']) ?></span>
                  <div class="fw-semibold text-dark"><?= e($aud['title']) ?></div>
                  <div class="text-xs text-muted">Started: <?= format_date($aud['created_at'], true) ?></div>
                </td>
                <td>
                  <span class="badge bg-light text-dark border">
                    <i class="fa-solid fa-tags me-1 text-muted"></i><?= e($aud['category_name'] ?: 'All Store Categories') ?>
                  </span>
                </td>
                <td>
                  <div class="fw-medium text-dark"><?= e($aud['conducted_by_name'] ?? 'Store Auditor') ?></div>
                  <?php if (!empty($aud['completed_at'])): ?>
                    <div class="text-xs text-success"><i class="fa-solid fa-circle-check me-1"></i><?= format_date($aud['completed_at']) ?></div>
                  <?php endif; ?>
                </td>
                <td class="text-center">
                  <div class="fw-bold"><?= (int)$aud['total_items'] ?> <span class="text-xs text-muted fw-normal">items</span></div>
                  <div class="text-xs">
                    <span class="text-success fw-semibold"><?= (int)$aud['matched_items'] ?> matched</span> &bull; 
                    <span class="<?= ((int)$aud['discrepant_items'] > 0) ? 'text-danger fw-semibold' : 'text-muted' ?>"><?= (int)$aud['discrepant_items'] ?> diff</span>
                  </div>
                </td>
                <td class="text-center">
                  <?php $var_qty = (int)$aud['net_variance_qty']; ?>
                  <span class="badge <?= ($var_qty == 0) ? 'bg-success' : (($var_qty < 0) ? 'bg-danger' : 'bg-primary') ?>">
                    <?= ($var_qty > 0 ? '+' : '') . $var_qty ?> units
                  </span>
                  <div class="font-monospace text-xs mt-1 <?= ((float)$aud['net_variance_value'] < 0) ? 'text-danger' : 'text-success' ?>">
                    <?= format_currency($aud['net_variance_value']) ?>
                  </div>
                </td>
                <td class="text-center">
                  <?php if ($aud['status'] === 'Completed'): ?>
                    <span class="badge bg-success px-2.5 py-1.5"><i class="fa-solid fa-circle-check me-1"></i>Completed</span>
                  <?php else: ?>
                    <span class="badge bg-warning text-dark px-2.5 py-1.5"><i class="fa-solid fa-spinner fa-spin me-1"></i>In Progress</span>
                  <?php endif; ?>
                </td>
                <td class="text-end pe-3">
                  <div class="btn-group">
                    <?php if ($aud['status'] === 'In Progress'): ?>
                      <a href="verify.php?id=<?= $aud['id'] ?>" class="btn btn-sm btn-primary">
                        <i class="fa-solid fa-pen-to-square me-1"></i>Count & Verify
                      </a>
                    <?php else: ?>
                      <a href="view.php?id=<?= $aud['id'] ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fa-solid fa-file-lines me-1"></i>Audit Report
                      </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
