<?php
/**
 * Smart Store Room Management System
 * Start New Physical Stock Audit Session
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();
require_role(['Admin', 'Store Manager']);

$page_title = 'Start Stock Audit Session';
$db = Database::getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);
$error = '';

$audit_code = generate_audit_code($db);
$categories = $db->query("SELECT id, category_name FROM categories WHERE status = 'Active' ORDER BY category_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();

    $title = trim($_POST['title'] ?? '');
    $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $remarks = trim($_POST['remarks'] ?? '');

    if (empty($title)) {
        $error = 'Please provide an audit session title.';
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO stock_audits (
                    audit_code, title, category_id, status, conducted_by, remarks
                ) VALUES (?, ?, ?, 'In Progress', ?, ?)
            ");
            $stmt->execute([
                $audit_code,
                $title,
                $category_id,
                $user_id,
                $remarks
            ]);
            $new_audit_id = (int)$db->lastInsertId();

            set_flash('success', 'Stock Audit session ' . $audit_code . ' started! Enter physical counts below.');
            header('Location: verify.php?id=' . $new_audit_id);
            exit;
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="container-fluid p-0" style="max-width: 800px;">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h3 class="fw-bold mb-1 text-dark">Initiate Stock Audit Session</h3>
      <p class="text-muted small mb-0">Set up a physical count cycle to verify shelf quantities against system inventory</p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">
      <i class="fa-solid fa-arrow-left me-1"></i>Back
    </a>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fa-solid fa-circle-exclamation me-2"></i><?= e($error) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card border-0 shadow-sm">
    <div class="card-body p-4">
      <form method="POST" action="start.php">
        <input type="hidden" name="csrf_token" value="<?= e(get_csrf_token()) ?>">

        <div class="row g-3 mb-4 p-3 bg-light rounded-3">
          <div class="col-md-6">
            <label class="form-label small text-muted text-uppercase fw-semibold mb-1">Generated Audit Code</label>
            <input type="text" class="form-control font-monospace fw-bold bg-white" value="<?= e($audit_code) ?>" readonly>
          </div>
          <div class="col-md-6">
            <label class="form-label small text-muted text-uppercase fw-semibold mb-1">Lead Auditor</label>
            <input type="text" class="form-control bg-white" value="<?= e($_SESSION['user_name'] ?? 'Auditor') ?> (<?= e($_SESSION['user_role'] ?? 'Manager') ?>)" readonly>
          </div>
        </div>

        <div class="mb-4">
          <label class="form-label fw-semibold">Audit Session Title <span class="text-danger">*</span></label>
          <input type="text" name="title" class="form-control form-control-lg" required 
                 value="Physical Stock Verification - <?= date('F Y') ?>" 
                 placeholder="e.g. Monthly Physical Count - Bay 1 & 2">
          <div class="form-text small">Give this session a clear name for accounting and audit records.</div>
        </div>

        <div class="mb-4">
          <label class="form-label fw-semibold">Verification Scope (Category)</label>
          <select name="category_id" class="form-select form-select-lg">
            <option value="">-- Complete Store Room (All Categories) --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>"><?= e($cat['category_name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text small">Choose a specific category to do a targeted audit, or leave blank to count all inventory items.</div>
        </div>

        <div class="mb-4">
          <label class="form-label fw-semibold">Audit Objectives & Internal Notes</label>
          <textarea name="remarks" class="form-control" rows="3" placeholder="Enter auditor instructions, count methodology, or audit objectives..."></textarea>
        </div>

        <div class="d-flex justify-content-end gap-3 pt-3 border-top">
          <a href="index.php" class="btn btn-light border px-4">Cancel</a>
          <button type="submit" class="btn btn-primary px-4 d-flex align-items-center gap-2">
            <i class="fa-solid fa-play"></i>
            <span>Start Counting Worksheet</span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
