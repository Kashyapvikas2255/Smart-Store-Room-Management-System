<?php
/**
 * Smart Store Room Management System
 * Physical Stock Verification & Reconciliation Worksheet
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();
require_role(['Admin', 'Store Manager']);

$db = Database::getConnection();
$audit_id = (int)($_GET['id'] ?? 0);
$user_id = (int)($_SESSION['user_id'] ?? 0);

if ($audit_id <= 0) {
    header('Location: index.php');
    exit;
}

// Fetch audit session
$stmt = $db->prepare("
    SELECT sa.*, c.category_name, u.name as conducted_by_name
    FROM stock_audits sa
    LEFT JOIN categories c ON sa.category_id = c.id
    LEFT JOIN users u ON sa.conducted_by = u.id
    WHERE sa.id = ?
");
$stmt->execute([$audit_id]);
$audit = $stmt->fetch();

if (!$audit) {
    set_flash('error', 'Audit session not found.');
    header('Location: index.php');
    exit;
}

if ($audit['status'] === 'Completed') {
    header('Location: view.php?id=' . $audit_id);
    exit;
}

$page_title = 'Counting Sheet - ' . $audit['audit_code'];

// Fetch items in audit scope
$item_sql = "
    SELECT 
        i.id as item_id,
        i.item_code,
        i.item_name,
        i.current_stock as system_stock,
        i.unit,
        i.purchase_price,
        i.selling_or_issue_price,
        i.location,
        i.rack_no,
        c.category_name,
        ai.physical_stock,
        ai.difference,
        ai.reason,
        ai.remarks as item_remarks
    FROM items i
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN audit_items ai ON (ai.audit_id = ? AND ai.item_id = i.id)
    WHERE i.status = 'Active'
";
$item_params = [$audit_id];
if ($audit['category_id']) {
    $item_sql .= " AND i.category_id = ?";
    $item_params[] = $audit['category_id'];
}
$item_sql .= " ORDER BY c.category_name ASC, i.item_name ASC";

$item_stmt = $db->prepare($item_sql);
$item_stmt->execute($item_params);
$items = $item_stmt->fetchAll();

// Handle Form Submission (Draft Save or Finalize & Reconcile)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();
    $is_finalize = isset($_POST['finalize']) && $_POST['finalize'] === '1';
    $counts = $_POST['physical_stock'] ?? [];
    $reasons = $_POST['reason'] ?? [];
    $remarks_arr = $_POST['item_remarks'] ?? [];

    try {
        $db->beginTransaction();

        $total_items = count($items);
        $matched_items = 0;
        $discrepant_items = 0;
        $net_variance_qty = 0;
        $net_variance_value = 0.0;

        // Clear existing audit items for this audit session to avoid duplicates
        $del_stmt = $db->prepare("DELETE FROM audit_items WHERE audit_id = ?");
        $del_stmt->execute([$audit_id]);

        $ins_audit_item = $db->prepare("
            INSERT INTO audit_items (
                audit_id, item_id, system_stock, physical_stock,
                difference, unit_price, variance_value, reason, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        foreach ($items as $itm) {
            $i_id = $itm['item_id'];
            $sys_stock = (int)$itm['system_stock'];
            
            // Get physical count entered by user
            $phys_input = isset($counts[$i_id]) ? trim($counts[$i_id]) : '';
            $phys_stock = ($phys_input !== '') ? (int)$phys_input : $sys_stock;
            $diff = $phys_stock - $sys_stock;

            $unit_p = (float)$itm['purchase_price'] ?: 1.0;
            $var_val = $diff * $unit_p;

            $reason = trim($reasons[$i_id] ?? ($diff === 0 ? 'Matched' : 'Discrepancy'));
            $rem = trim($remarks_arr[$i_id] ?? '');

            if ($diff === 0) {
                $matched_items++;
            } else {
                $discrepant_items++;
            }
            $net_variance_qty += $diff;
            $net_variance_value += $var_val;

            // Insert into audit_items
            $ins_audit_item->execute([
                $audit_id, $i_id, $sys_stock, $phys_stock,
                $diff, $unit_p, $var_val, $reason, $rem
            ]);

            // If Finalizing, also reconcile live system stock
            if ($is_finalize && $diff !== 0) {
                // 1. Record stock adjustment
                $adj_stmt = $db->prepare("
                    INSERT INTO stock_adjustments (
                        item_id, system_stock, physical_stock, difference,
                        reason, remarks, adjusted_by, adjustment_date
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, date('now'))
                ");
                $adj_stmt->execute([
                    $i_id, $sys_stock, $phys_stock, $diff,
                    $reason, 'Reconciled during Audit #' . $audit['audit_code'] . ': ' . $rem,
                    $user_id
                ]);

                // 2. Update live item stock
                $upd_item = $db->prepare("UPDATE items SET current_stock = ?, updated_at = datetime('now') WHERE id = ?");
                $upd_item->execute([$phys_stock, $i_id]);

                // 3. Log into stock_transactions
                $txn_code = generate_transaction_code($db, 'ADJ');
                $txn_type = ($diff > 0) ? 'IN' : 'OUT';
                $txn_stmt = $db->prepare("
                    INSERT INTO stock_transactions (
                        transaction_code, item_id, transaction_type, quantity,
                        previous_stock, new_stock, unit_price, reference_no,
                        remarks, transaction_date, created_by
                    ) VALUES (?, ?, 'ADJUSTMENT', ?, ?, ?, ?, ?, ?, date('now'), ?)
                ");
                $txn_stmt->execute([
                    $txn_code, $i_id, abs($diff), $sys_stock, $phys_stock,
                    $unit_p, $audit['audit_code'],
                    'Audit Reconciliation (' . $audit['audit_code'] . '): ' . $reason,
                    $user_id
                ]);
            }
        }

        // Update Audit Session Record
        if ($is_finalize) {
            $upd_audit = $db->prepare("
                UPDATE stock_audits 
                SET status = 'Completed', total_items = ?, matched_items = ?,
                    discrepant_items = ?, net_variance_qty = ?, net_variance_value = ?,
                    completed_at = datetime('now')
                WHERE id = ?
            ");
            $upd_audit->execute([
                $total_items, $matched_items, $discrepant_items,
                $net_variance_qty, $net_variance_value, $audit_id
            ]);

            $db->commit();
            set_flash('success', 'Physical audit #' . $audit['audit_code'] . ' finalized and inventory successfully reconciled! All adjustments recorded.');
            header('Location: view.php?id=' . $audit_id);
            exit;
        } else {
            // Draft save
            $upd_audit = $db->prepare("
                UPDATE stock_audits 
                SET total_items = ?, matched_items = ?, discrepant_items = ?,
                    net_variance_qty = ?, net_variance_value = ?
                WHERE id = ?
            ");
            $upd_audit->execute([
                $total_items, $matched_items, $discrepant_items,
                $net_variance_qty, $net_variance_value, $audit_id
            ]);

            $db->commit();
            set_flash('success', 'Draft counts saved successfully. You can continue counting or finalize when ready.');
            header('Location: verify.php?id=' . $audit_id);
            exit;
        }
    } catch (Exception $e) {
        $db->rollBack();
        set_flash('error', 'Error saving counts: ' . $e->getMessage());
        header('Location: verify.php?id=' . $audit_id);
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="container-fluid p-0">
  <!-- Header Bar -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
      <div class="d-flex align-items-center gap-2 mb-1">
        <span class="badge bg-warning text-dark font-monospace"><i class="fa-solid fa-spinner fa-spin me-1"></i>Active Audit</span>
        <h3 class="fw-bold mb-0 text-dark"><?= e($audit['title']) ?></h3>
      </div>
      <p class="text-muted small mb-0">
        Code: <strong class="font-monospace text-primary"><?= e($audit['audit_code']) ?></strong> &bull; 
        Scope: <strong class="text-dark"><?= e($audit['category_name'] ?: 'All Categories') ?></strong> &bull; 
        Auditor: <strong><?= e($audit['conducted_by_name'] ?? 'Auditor') ?></strong>
      </p>
    </div>
    <div class="d-flex gap-2">
      <a href="index.php" class="btn btn-outline-secondary">
        <i class="fa-solid fa-arrow-left me-1"></i>Back
      </a>
      <button type="button" class="btn btn-outline-primary" onclick="window.print()">
        <i class="fa-solid fa-print me-1"></i>Print Blank Sheet
      </button>
    </div>
  </div>

  <!-- Live Audit Summary Ticker -->
  <div class="card border-0 shadow-sm mb-4 bg-primary text-white">
    <div class="card-body p-3">
      <div class="row g-3 text-center align-items-center">
        <div class="col-sm-3 border-end border-white-50">
          <div class="text-xs text-white-50 text-uppercase fw-semibold">Total Items in Scope</div>
          <div class="fs-4 fw-bold" id="ticker_total"><?= count($items) ?></div>
        </div>
        <div class="col-sm-3 border-end border-white-50">
          <div class="text-xs text-white-50 text-uppercase fw-semibold">Count Matched</div>
          <div class="fs-4 fw-bold text-success-emphasis" id="ticker_matched">0</div>
        </div>
        <div class="col-sm-3 border-end border-white-50">
          <div class="text-xs text-white-50 text-uppercase fw-semibold">Discrepancies</div>
          <div class="fs-4 fw-bold text-warning" id="ticker_discrepant">0</div>
        </div>
        <div class="col-sm-3">
          <div class="text-xs text-white-50 text-uppercase fw-semibold">Net Variance Units</div>
          <div class="fs-4 fw-bold" id="ticker_variance_qty">0</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Audit Counting Worksheet Table -->
  <div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
      <h6 class="fw-bold mb-0 text-dark">
        <i class="fa-solid fa-clipboard-list text-primary me-2"></i>Physical Inventory Counting Worksheet
      </h6>
      <span class="text-xs text-muted">Enter the actual count found on the shelf</span>
    </div>

    <form method="POST" action="verify.php?id=<?= $audit_id ?>" id="auditForm">
      <input type="hidden" name="csrf_token" value="<?= e(get_csrf_token()) ?>">
      <input type="hidden" name="finalize" id="finalize_input" value="0">

      <div class="table-responsive">
        <table class="table align-middle table-hover mb-0" id="auditTable">
          <thead class="table-light">
            <tr>
              <th style="width: 50px;">#</th>
              <th>Item Code & Description</th>
              <th>Location / Rack</th>
              <th class="text-center" style="width: 120px;">System Qty</th>
              <th class="text-center" style="width: 150px;">Physical Count <span class="text-danger">*</span></th>
              <th class="text-center" style="width: 140px;">Variance</th>
              <th style="width: 200px;">Reason / Discrepancy</th>
              <th>Auditor Remarks</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $idx => $itm): ?>
              <?php 
                $i_id = $itm['item_id'];
                $sys_qty = (int)$itm['system_stock'];
                $phys_qty = ($itm['physical_stock'] !== null) ? (int)$itm['physical_stock'] : $sys_qty;
                $diff = $phys_qty - $sys_qty;
                $unit_price = (float)$itm['purchase_price'];
              ?>
              <tr data-item-id="<?= $i_id ?>" data-system-stock="<?= $sys_qty ?>" data-unit-price="<?= $unit_price ?>">
                <td class="text-muted text-xs"><?= $idx + 1 ?></td>
                <td>
                  <div class="fw-bold text-dark"><?= e($itm['item_name']) ?></div>
                  <div class="text-xs text-muted">
                    <span class="font-monospace text-primary"><?= e($itm['item_code']) ?></span> &bull; 
                    <?= e($itm['category_name']) ?>
                  </div>
                </td>
                <td>
                  <div class="text-sm fw-medium text-dark"><?= e($itm['location']) ?></div>
                  <div class="text-xs text-muted">Rack: <strong><?= e($itm['rack_no']) ?></strong></div>
                </td>
                <td class="text-center">
                  <span class="fs-6 fw-bold system-qty"><?= $sys_qty ?></span>
                  <span class="text-xs text-muted d-block"><?= e($itm['unit']) ?></span>
                </td>
                <td>
                  <div class="input-group input-group-sm">
                    <input type="number" 
                           name="physical_stock[<?= $i_id ?>]" 
                           class="form-control form-control-sm text-center fw-bold phys-input" 
                           value="<?= $phys_qty ?>" 
                           min="0" 
                           required 
                           oninput="recalcRow(this)">
                    <span class="input-group-text bg-light text-xs"><?= e($itm['unit']) ?></span>
                  </div>
                </td>
                <td class="text-center">
                  <span class="badge variance-badge <?= ($diff === 0) ? 'bg-success' : (($diff < 0) ? 'bg-danger' : 'bg-primary') ?>">
                    <?= ($diff > 0 ? '+' : '') . $diff ?> <?= e($itm['unit']) ?>
                  </span>
                  <div class="text-xs font-monospace variance-value <?= ($diff < 0) ? 'text-danger' : 'text-muted' ?>">
                    <?= format_currency($diff * $unit_price) ?>
                  </div>
                </td>
                <td>
                  <select name="reason[<?= $i_id ?>]" class="form-select form-select-sm reason-select">
                    <option value="Matched" <?= ($itm['reason'] === 'Matched' || ($itm['reason'] === null && $diff === 0)) ? 'selected' : '' ?>>Matched (No Variance)</option>
                    <option value="Physical Damage" <?= ($itm['reason'] === 'Physical Damage') ? 'selected' : '' ?>>Physical Damage</option>
                    <option value="Theft / Untraced" <?= ($itm['reason'] === 'Theft / Untraced') ? 'selected' : '' ?>>Theft / Untraced Shortage</option>
                    <option value="Count Discrepancy" <?= ($itm['reason'] === 'Count Discrepancy') ? 'selected' : '' ?>>Counting / Data Discrepancy</option>
                    <option value="Unrecorded Inward" <?= ($itm['reason'] === 'Unrecorded Inward') ? 'selected' : '' ?>>Unrecorded Inward Stock</option>
                    <option value="Scrap / Discarded" <?= ($itm['reason'] === 'Scrap / Discarded') ? 'selected' : '' ?>>Scrap / Discarded</option>
                  </select>
                </td>
                <td>
                  <input type="text" name="item_remarks[<?= $i_id ?>]" class="form-control form-control-sm" placeholder="Optional notes..." value="<?= e($itm['item_remarks'] ?? '') ?>">
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Action Footer -->
      <div class="card-footer bg-light p-3 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-3">
        <span class="text-xs text-muted">
          <i class="fa-solid fa-circle-info me-1 text-primary"></i>
          Clicking <strong>"Reconcile & Finalize"</strong> will automatically adjust database stock balances to match your physical count.
        </span>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-outline-secondary" onclick="saveDraft()">
            <i class="fa-solid fa-floppy-disk me-1"></i>Save Draft Counts
          </button>
          <button type="button" class="btn btn-success px-4" onclick="confirmFinalize()">
            <i class="fa-solid fa-check-double me-1"></i>Finalize & Reconcile Inventory
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
function recalcRow(input) {
  const row = input.closest('tr');
  const sysStock = parseInt(row.getAttribute('data-system-stock') || 0);
  const unitPrice = parseFloat(row.getAttribute('data-unit-price') || 0);
  const physVal = input.value === '' ? sysStock : parseInt(input.value);
  const diff = physVal - sysStock;
  const varVal = diff * unitPrice;

  const badge = row.querySelector('.variance-badge');
  const valElem = row.querySelector('.variance-value');
  const reasonSelect = row.querySelector('.reason-select');

  badge.textContent = (diff > 0 ? '+' : '') + diff;
  if (diff === 0) {
    badge.className = 'badge variance-badge bg-success';
    valElem.className = 'text-xs font-monospace variance-value text-muted';
    valElem.textContent = '$0.00';
    if (reasonSelect.value !== 'Matched') {
      reasonSelect.value = 'Matched';
    }
  } else if (diff < 0) {
    badge.className = 'badge variance-badge bg-danger';
    valElem.className = 'text-xs font-monospace variance-value text-danger';
    valElem.textContent = '-$' + Math.abs(varVal).toFixed(2);
    if (reasonSelect.value === 'Matched') {
      reasonSelect.value = 'Count Discrepancy';
    }
  } else {
    badge.className = 'badge variance-badge bg-primary';
    valElem.className = 'text-xs font-monospace variance-value text-success';
    valElem.textContent = '+$' + varVal.toFixed(2);
    if (reasonSelect.value === 'Matched') {
      reasonSelect.value = 'Unrecorded Inward';
    }
  }

  updateGlobalTicker();
}

function updateGlobalTicker() {
  const rows = document.querySelectorAll('#auditTable tbody tr');
  let matched = 0;
  let discrepant = 0;
  let netVariance = 0;

  rows.forEach(r => {
    const sysStock = parseInt(r.getAttribute('data-system-stock') || 0);
    const input = r.querySelector('.phys-input');
    const physVal = input.value === '' ? sysStock : parseInt(input.value);
    const diff = physVal - sysStock;

    if (diff === 0) {
      matched++;
    } else {
      discrepant++;
    }
    netVariance += diff;
  });

  document.getElementById('ticker_matched').textContent = matched;
  document.getElementById('ticker_discrepant').textContent = discrepant;
  document.getElementById('ticker_variance_qty').textContent = (netVariance > 0 ? '+' : '') + netVariance;
}

function saveDraft() {
  document.getElementById('finalize_input').value = '0';
  document.getElementById('auditForm').submit();
}

function confirmFinalize() {
  const discrepant = parseInt(document.getElementById('ticker_discrepant').textContent || 0);
  let msg = 'Are you sure you want to FINALIZE this audit?';
  if (discrepant > 0) {
    msg += '\n\nWARNING: ' + discrepant + ' item(s) have stock variances. The system will automatically create Stock Adjustment entries and update database inventory balances to match your physical count.';
  } else {
    msg += '\n\nAll physical items match system records exactly.';
  }

  if (confirm(msg)) {
    document.getElementById('finalize_input').value = '1';
    document.getElementById('auditForm').submit();
  }
}

document.addEventListener('DOMContentLoaded', function() {
  updateGlobalTicker();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
