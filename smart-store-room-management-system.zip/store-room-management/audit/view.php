<?php
/**
 * Smart Store Room Management System
 * Physical Stock Audit Report & Reconciliation Certificate
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$db = Database::getConnection();
$audit_id = (int)($_GET['id'] ?? 0);

if ($audit_id <= 0) {
    header('Location: index.php');
    exit;
}

// Fetch audit session
$stmt = $db->prepare("
    SELECT sa.*, c.category_name, u.name as conducted_by_name
    FROM stock_audits sa
    LEFT JOIN categories c ON sa.category_id = c.id
    LEFT JOIN users u ON sa.conducted_by = u.id
    WHERE sa.id = ?
");
$stmt->execute([$audit_id]);
$audit = $stmt->fetch();

if (!$audit) {
    die('Stock audit record not found.');
}

// Handle Variance CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $rows = $db->prepare("
        SELECT 
            i.item_code,
            i.item_name,
            c.category_name,
            i.location,
            i.rack_no,
            ai.system_stock,
            ai.physical_stock,
            ai.difference,
            ai.unit_price,
            ai.variance_value,
            ai.reason,
            ai.remarks
        FROM audit_items ai
        JOIN items i ON ai.item_id = i.id
        JOIN categories c ON i.category_id = c.id
        WHERE ai.audit_id = ?
        ORDER BY ABS(ai.difference) DESC, i.item_name ASC
    ");
    $rows->execute([$audit_id]);
    $items_data = $rows->fetchAll();

    $headers = [
        'Item Code', 'Item Name', 'Category', 'Location', 'Rack No',
        'System Stock', 'Physical Count', 'Difference Qty', 'Unit Price ($)',
        'Variance Value ($)', 'Reason / Cause', 'Remarks'
    ];
    $export_rows = [];
    foreach ($items_data as $it) {
        $export_rows[] = [
            $it['item_code'],
            $it['item_name'],
            $it['category_name'],
            $it['location'],
            $it['rack_no'],
            $it['system_stock'],
            $it['physical_stock'],
            $it['difference'],
            $it['unit_price'],
            $it['variance_value'],
            $it['reason'],
            $it['remarks'] ?? ''
        ];
    }
    export_to_csv('Audit_' . $audit['audit_code'] . '_Variance_' . date('Y-m-d') . '.csv', $headers, $export_rows);
}

// Fetch audit items
$item_stmt = $db->prepare("
    SELECT 
        ai.*,
        i.item_code,
        i.item_name,
        i.unit,
        i.location,
        i.rack_no,
        c.category_name
    FROM audit_items ai
    JOIN items i ON ai.item_id = i.id
    JOIN categories c ON i.category_id = c.id
    WHERE ai.audit_id = ?
    ORDER BY ABS(ai.difference) DESC, i.item_name ASC
");
$item_stmt->execute([$audit_id]);
$audit_items = $item_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Stock Audit Certification - <?= e($audit['audit_code']) ?></title>
  <!-- Bootstrap 5.3 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body {
      background-color: #f8fafc;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #0f172a;
    }
    .report-card {
      max-width: 960px;
      margin: 30px auto;
      background: #ffffff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      border: 1px solid #e2e8f0;
    }
    .cert-header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 20px;
      margin-bottom: 25px;
    }
    .stat-pill {
      background: #f1f5f9;
      border-radius: 8px;
      padding: 12px 16px;
      text-align: center;
    }
    .signature-area {
      margin-top: 50px;
      padding-top: 20px;
      border-top: 1px dashed #cbd5e1;
    }
    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .report-card {
        box-shadow: none;
        border: none;
        padding: 0;
        margin: 0;
        max-width: 100%;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <!-- Top Navigation Controls (hidden on print) -->
  <div class="d-flex justify-content-between align-items-center mb-3 no-print" style="max-width:960px;margin:20px auto 0;">
    <a href="index.php" class="btn btn-outline-secondary">
      <i class="fa-solid fa-arrow-left me-1"></i>Back to Audit List
    </a>
    <div class="d-flex gap-2">
      <a href="view.php?id=<?= $audit_id ?>&export=csv" class="btn btn-outline-success">
        <i class="fa-solid fa-file-excel me-1"></i>Export Variance CSV
      </a>
      <button type="button" class="btn btn-primary" onclick="window.print()">
        <i class="fa-solid fa-print me-1"></i>Print Audit Report / Certificate
      </button>
    </div>
  </div>

  <div class="report-card">
    <!-- Header -->
    <div class="cert-header d-flex justify-content-between align-items-start">
      <div>
        <div class="d-flex align-items-center gap-2 mb-1">
          <i class="fa-solid fa-clipboard-check text-primary fs-3"></i>
          <span class="fs-4 fw-bold text-dark">PHYSICAL STOCK AUDIT & RECONCILIATION CERTIFICATE</span>
        </div>
        <div class="text-sm text-muted">Smart Store Room Management System &bull; Inventory Assurance Division</div>
        <div class="text-xs text-muted">Location: Central Store Depot, Building 4 &bull; Period: <?= date('F Y', strtotime($audit['created_at'])) ?></div>
      </div>
      <div class="text-end">
        <span class="badge bg-success px-3 py-1.5 text-uppercase fw-bold mb-1">
          <i class="fa-solid fa-certificate me-1"></i><?= e($audit['status']) ?>
        </span>
        <div class="font-monospace fw-bold fs-6 text-dark"><?= e($audit['audit_code']) ?></div>
        <div class="text-xs text-muted">Date: <?= format_date($audit['completed_at'] ?: $audit['created_at']) ?></div>
      </div>
    </div>

    <!-- Audit Session Details -->
    <div class="mb-4 p-3 bg-light rounded-3 border">
      <div class="row g-2 text-sm">
        <div class="col-sm-6">
          <span class="text-xs text-muted text-uppercase fw-semibold d-block">Audit Session Title:</span>
          <strong class="text-dark fs-6"><?= e($audit['title']) ?></strong>
        </div>
        <div class="col-sm-3">
          <span class="text-xs text-muted text-uppercase fw-semibold d-block">Auditor In-Charge:</span>
          <span class="fw-semibold"><?= e($audit['conducted_by_name'] ?? 'Store Auditor') ?></span>
        </div>
        <div class="col-sm-3">
          <span class="text-xs text-muted text-uppercase fw-semibold d-block">Verification Scope:</span>
          <span class="badge bg-light text-dark border"><?= e($audit['category_name'] ?: 'All Store Categories') ?></span>
        </div>
      </div>
      <?php if (!empty($audit['remarks'])): ?>
        <div class="text-xs text-secondary mt-2 border-top pt-2">
          <strong>Auditor Observations:</strong> <?= e($audit['remarks']) ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Metrics Row -->
    <div class="row g-3 mb-4 text-center">
      <div class="col-3">
        <div class="stat-pill border">
          <span class="text-xs text-muted text-uppercase d-block">Items Audited</span>
          <strong class="fs-5 text-dark"><?= (int)$audit['total_items'] ?></strong>
        </div>
      </div>
      <div class="col-3">
        <div class="stat-pill border">
          <span class="text-xs text-muted text-uppercase d-block">Count Matched</span>
          <strong class="fs-5 text-success"><?= (int)$audit['matched_items'] ?></strong>
        </div>
      </div>
      <div class="col-3">
        <div class="stat-pill border">
          <span class="text-xs text-muted text-uppercase d-block">Discrepancies</span>
          <strong class="fs-5 <?= ((int)$audit['discrepant_items'] > 0) ? 'text-danger' : 'text-muted' ?>">
            <?= (int)$audit['discrepant_items'] ?>
          </strong>
        </div>
      </div>
      <div class="col-3">
        <div class="stat-pill border">
          <span class="text-xs text-muted text-uppercase d-block">Net Variance Value</span>
          <strong class="fs-5 font-monospace <?= ((float)$audit['net_variance_value'] < 0) ? 'text-danger' : 'text-success' ?>">
            <?= format_currency($audit['net_variance_value']) ?>
          </strong>
        </div>
      </div>
    </div>

    <!-- Variance Breakdown Table -->
    <h6 class="fw-bold mb-3 text-dark">
      <i class="fa-solid fa-table-list text-primary me-2"></i>Physical Count vs. System Inventory Audit Ledger
    </h6>
    <div class="table-responsive mb-4">
      <table class="table table-bordered table-sm align-middle mb-0 text-sm">
        <thead class="table-light text-xs text-uppercase">
          <tr>
            <th style="width: 40px;" class="text-center">#</th>
            <th>Item SKU & Name</th>
            <th class="text-center">Location</th>
            <th class="text-center">System Qty</th>
            <th class="text-center">Physical Count</th>
            <th class="text-center">Variance</th>
            <th class="text-end">Variance Value</th>
            <th>Cause / Discrepancy Reason</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($audit_items as $idx => $it): ?>
            <?php $diff = (int)$it['difference']; ?>
            <tr class="<?= ($diff !== 0) ? 'table-warning-subtle' : '' ?>">
              <td class="text-center text-muted"><?= $idx + 1 ?></td>
              <td>
                <div class="fw-semibold text-dark"><?= e($it['item_name']) ?></div>
                <div class="text-xs font-monospace text-muted"><?= e($it['item_code']) ?> &bull; <?= e($it['category_name']) ?></div>
              </td>
              <td class="text-center text-xs text-muted"><?= e($it['location']) ?> (<?= e($it['rack_no']) ?>)</td>
              <td class="text-center font-monospace"><?= (int)$it['system_stock'] ?></td>
              <td class="text-center font-monospace fw-bold"><?= (int)$it['physical_stock'] ?></td>
              <td class="text-center">
                <?php if ($diff === 0): ?>
                  <span class="badge bg-success-subtle text-success border border-success-subtle">Matched (0)</span>
                <?php elseif ($diff < 0): ?>
                  <span class="badge bg-danger text-white"><?= $diff ?> <?= e($it['unit']) ?></span>
                <?php else: ?>
                  <span class="badge bg-primary text-white">+<?= $diff ?> <?= e($it['unit']) ?></span>
                <?php endif; ?>
              </td>
              <td class="text-end font-monospace <?= ($diff < 0) ? 'text-danger fw-bold' : 'text-muted' ?>">
                <?= format_currency($it['variance_value']) ?>
              </td>
              <td class="text-xs">
                <strong><?= e($it['reason'] ?: 'Matched') ?></strong>
                <?php if (!empty($it['remarks'])): ?>
                  <div class="text-muted"><?= e($it['remarks']) ?></div>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot class="table-light">
          <tr>
            <td colspan="5" class="text-end fw-bold">Net Total Variance Impact:</td>
            <td class="text-center fw-bold font-monospace <?= ((int)$audit['net_variance_qty'] < 0) ? 'text-danger' : 'text-success' ?>">
              <?= ((int)$audit['net_variance_qty'] > 0 ? '+' : '') . (int)$audit['net_variance_qty'] ?> units
            </td>
            <td class="text-end fw-bold font-monospace <?= ((float)$audit['net_variance_value'] < 0) ? 'text-danger' : 'text-success' ?>">
              <?= format_currency($audit['net_variance_value']) ?>
            </td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- Certification Statement & Dual Signatures -->
    <div class="signature-area">
      <div class="p-3 bg-light rounded-3 border mb-4 text-xs text-muted text-center">
        <strong>Audit Certification:</strong> I hereby certify that the physical count recorded above was conducted on-site in the presence of store keeping staff. All discrepancies have been reconciled against current database balances in accordance with store room inventory compliance policies.
      </div>

      <div class="row g-4 text-center mt-2">
        <div class="col-4">
          <div class="border-top pt-2">
            <div class="fw-bold text-sm text-dark"><?= e($audit['conducted_by_name'] ?? 'Store Auditor') ?></div>
            <div class="text-xs text-muted">Audited & Counted By</div>
            <div class="text-xs text-muted mt-1">Date: <?= format_date($audit['completed_at'] ?: $audit['created_at']) ?></div>
          </div>
        </div>

        <div class="col-4">
          <div class="border-top pt-2">
            <div class="fw-bold text-sm text-dark">Vikas Sharma</div>
            <div class="text-xs text-muted">Store Room Manager</div>
            <div class="text-xs text-muted mt-1">Reconciliation Approved</div>
          </div>
        </div>

        <div class="col-4">
          <div class="border-top pt-2">
            <div class="fw-bold text-sm text-dark">Finance / Internal Audit</div>
            <div class="text-xs text-muted">Official Verification Seal</div>
            <div class="text-xs text-muted mt-1">Stamp & Authorization</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

</body>
</html>
