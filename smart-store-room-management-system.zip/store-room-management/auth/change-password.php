<?php
/**
 * Smart Store Room Management System
 * Change Password Page
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Change Password';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Security token validation failed. Please try again.";
    } elseif (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All password fields are required.";
    } elseif (strlen($new_password) < 6) {
        $error = "New password must be at least 6 characters long.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New password and confirmation do not match.";
    } else {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("SELECT password FROM users WHERE id = :id");
            $stmt->execute([':id' => $_SESSION['user_id']]);
            $hash = $stmt->fetchColumn();

            if ($hash && password_verify($current_password, $hash)) {
                $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $update_stmt = $db->prepare("UPDATE users SET password = :pwd WHERE id = :id");
                $update_stmt->execute([':pwd' => $new_hash, ':id' => $_SESSION['user_id']]);
                
                set_flash('success', "Your password has been successfully updated.");
                header("Location: ../dashboard/index.php");
                exit;
            } else {
                $error = "Current password is incorrect.";
            }
        } catch (Exception $e) {
            $error = "Database error updating password.";
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-6 col-md-8">
    <div class="card shadow-sm border-0 rounded-3">
      <div class="card-header bg-white py-3 border-bottom">
        <h5 class="card-title mb-0 fw-bold text-dark">
          <i class="fa-solid fa-key text-primary me-2"></i> Change Account Password
        </h5>
      </div>
      <div class="card-body p-4">
        <?php if (!empty($error)): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>

        <form method="POST" action="change-password.php">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

          <div class="mb-3">
            <label for="current_password" class="form-label">Current Password</label>
            <input type="password" class="form-control" id="current_password" name="current_password" required>
          </div>

          <div class="mb-3">
            <label for="new_password" class="form-label">New Password</label>
            <input type="password" class="form-control" id="new_password" name="new_password" minlength="6" required>
            <div class="form-text">Must be at least 6 characters.</div>
          </div>

          <div class="mb-4">
            <label for="confirm_password" class="form-label">Confirm New Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="6" required>
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <a href="../dashboard/index.php" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary-deep px-4">
              <i class="fa-solid fa-check me-2"></i> Update Password
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
