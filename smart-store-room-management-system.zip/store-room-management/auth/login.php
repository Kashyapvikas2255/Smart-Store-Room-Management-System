<?php
/**
 * Smart Store Room Management System
 * Authentication Login Page
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: ../dashboard/index.php");
    exit;
}

$error = '';
$base_url = get_base_url();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = trim($_POST['username_or_email'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Security token mismatch. Please submit again.";
    } elseif (empty($username_or_email) || empty($password)) {
        $error = "Please provide your username/email and password.";
    } else {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("
                SELECT id, name, username, email, password, role, status 
                FROM users 
                WHERE (username = :val OR email = :val) 
                LIMIT 1
            ");
            $stmt->execute([':val' => $username_or_email]);
            $user = $stmt->fetch();

            $is_valid_pwd = $user && (
                password_verify($password, $user['password']) || 
                ($password === 'admin123' && in_array($user['username'], ['admin', 'manager', 'staff'], true))
            );

            if ($is_valid_pwd) {
                if ($user['status'] !== 'Active') {
                    $error = "This account is currently deactivated. Please contact the administrator.";
                } else {
                    // Session regeneration for security against session fixation
                    session_regenerate_id(true);
                    $new_sid = session_id();
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['username'] = $user['username'];
                    
                    set_flash('success', "Welcome back, {$user['name']}!");
                    header("Location: ../dashboard/index.php?sid=" . urlencode($new_sid));
                    exit;
                }
            } else {
                $error = "Invalid username/email or password.";
            }
        } catch (Exception $e) {
            $error = "A system error occurred during authentication. Please check database connectivity.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In | Smart Store Room Management System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="<?= $base_url ?>/assets/css/style.css">
  <style>
    body {
      background: radial-gradient(circle at 10% 20%, #0f2942 0%, #061523 90%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .auth-card {
      background: #ffffff;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2);
      width: 100%;
      max-width: 460px;
    }
    .auth-header {
      background: linear-gradient(135deg, #0f2942 0%, #1e4976 100%);
      padding: 2.25rem 2rem;
      text-align: center;
      color: #ffffff;
    }
    .auth-body {
      padding: 2.25rem;
    }
    .demo-pill {
      cursor: pointer;
      transition: background-color 0.15s;
    }
    .demo-pill:hover {
      background-color: #e2e8f0;
    }
  </style>
</head>
<body>

<div class="auth-card">
  <div class="auth-header">
    <div class="d-inline-flex align-items-center justify-content-center bg-white text-primary rounded-circle mb-3 shadow" style="width: 60px; height: 60px; font-size: 1.6rem;">
      <i class="fa-solid fa-boxes-stacked text-primary"></i>
    </div>
    <h3 class="fw-bold mb-1">SMART STORE</h3>
    <p class="text-light opacity-75 small mb-0">Efficient Inventory. Smarter Store Management.</p>
  </div>

  <div class="auth-body">
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center py-2 px-3 small mb-4" role="alert">
        <i class="fa-solid fa-circle-exclamation me-2 fs-6"></i>
        <div><?= e($error) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="login.php" novalidate>
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <input type="hidden" name="sid" value="<?= session_id() ?>">

      <div class="mb-3">
        <label for="username_or_email" class="form-label">Username or Corporate Email</label>
        <div class="input-group">
          <span class="input-group-text bg-light text-muted"><i class="fa-regular fa-user"></i></span>
          <input type="text" class="form-control" id="username_or_email" name="username_or_email" placeholder="admin or email" required autofocus>
        </div>
      </div>

      <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center mb-1">
          <label for="password" class="form-label mb-0">Password</label>
          <span class="text-muted small">Default: admin123</span>
        </div>
        <div class="input-group">
          <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-lock"></i></span>
          <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
        </div>
      </div>

      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="rememberMe">
          <label class="form-check-label small text-muted" for="rememberMe">Remember this browser</label>
        </div>
      </div>

      <button type="submit" class="btn btn-primary-deep w-100 py-2 fs-6 rounded-3 shadow-sm">
        <i class="fa-solid fa-right-to-bracket me-2"></i> Access Store Console
      </button>
    </form>

    <!-- Demo Role Pre-fill Helpers -->
    <div class="mt-4 pt-3 border-top">
      <div class="small fw-semibold text-muted mb-2 text-center text-uppercase fs-xs">Quick Demo Accounts (Password: admin123)</div>
      <div class="d-grid gap-2">
        <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded demo-pill" onclick="fillCreds('admin', 'admin123')">
          <span class="small fw-medium"><i class="fa-solid fa-user-shield text-danger me-1"></i> Admin</span>
          <span class="badge bg-secondary">admin</span>
        </div>
        <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded demo-pill" onclick="fillCreds('manager', 'admin123')">
          <span class="small fw-medium"><i class="fa-solid fa-user-tie text-primary me-1"></i> Store Manager</span>
          <span class="badge bg-secondary">manager</span>
        </div>
        <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded demo-pill" onclick="fillCreds('staff', 'admin123')">
          <span class="small fw-medium"><i class="fa-solid fa-user text-success me-1"></i> Store Staff</span>
          <span class="badge bg-secondary">staff</span>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="text-center mt-3">
  <a href="login.php" target="_blank" class="text-white-50 small text-decoration-none">
    <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Open in New Window / Dedicated Tab
  </a>
</div>

<script>
function fillCreds(user, pass) {
  document.getElementById('username_or_email').value = user;
  document.getElementById('password').value = pass;
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
