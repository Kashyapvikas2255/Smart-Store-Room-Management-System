<?php
/**
 * Smart Store Room Management System
 * Add Category
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Add Category';
$db = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_name = trim($_POST['category_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($category_name)) {
        $error = "Category name cannot be empty.";
    } else {
        try {
            $chk = $db->prepare("SELECT COUNT(*) FROM categories WHERE category_name = :name");
            $chk->execute([':name' => $category_name]);
            if ($chk->fetchColumn() > 0) {
                $error = "A category named '{$category_name}' already exists.";
            } else {
                $stmt = $db->prepare("INSERT INTO categories (category_name, description, status) VALUES (:name, :desc, :status)");
                $stmt->execute([':name' => $category_name, ':desc' => $description, ':status' => $status]);
                
                set_flash('success', "Category '{$category_name}' created successfully.");
                header("Location: index.php");
                exit;
            }
        } catch (Exception $e) {
            $error = "Error creating category: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold mb-0 text-dark">Add New Category</h3>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="add.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="mb-3">
          <label for="category_name" class="form-label">Category Name <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="category_name" name="category_name" placeholder="e.g. Laboratory & Chemical Reagents" required autofocus>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3" placeholder="Brief overview of items falling under this category..."></textarea>
        </div>
        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" id="status" name="status">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-floppy-disk me-2"></i> Save Category
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
