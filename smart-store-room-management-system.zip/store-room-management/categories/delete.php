<?php
/**
 * Smart Store Room Management System
 * Delete Category Handler
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid category identifier.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

try {
    // Check if category is used by any items
    $chk = $db->prepare("SELECT COUNT(*) FROM items WHERE category_id = :id");
    $chk->execute([':id' => $id]);
    $items_count = (int)$chk->fetchColumn();

    if ($items_count > 0) {
        set_flash('error', "Unable to delete this category because it is currently assigned to {$items_count} inventory item(s). Please reassign or remove those items first.");
        header("Location: index.php");
        exit;
    }

    $del = $db->prepare("DELETE FROM categories WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', "Category deleted successfully.");
} catch (Exception $e) {
    set_flash('error', "Database error during deletion: " . $e->getMessage());
}

header("Location: index.php");
exit;
