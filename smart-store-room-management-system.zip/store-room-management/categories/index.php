<?php
/**
 * Smart Store Room Management System
 * Category Management Listing
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Categories';
$db = Database::getConnection();

// Fetch categories with active items count
$stmt = $db->query("
    SELECT 
        c.*,
        COUNT(i.id) as items_count,
        COALESCE(SUM(i.current_stock), 0) as total_units
    FROM categories c
    LEFT JOIN items i ON c.id = i.category_id
    GROUP BY c.id
    ORDER BY c.category_name ASC
");
$categories = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Category Management</h3>
    <p class="text-muted mb-0 small">Organize inventory into logical categories with item count tracking.</p>
  </div>
  <?php if (has_role(['Admin', 'Store Manager'])): ?>
    <a href="add.php" class="btn btn-primary-deep">
      <i class="fa-solid fa-plus me-1"></i> Add Category
    </a>
  <?php endif; ?>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Category Name</th>
          <th>Description</th>
          <th>Total Items</th>
          <th>Stocked Units</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($categories)): ?>
          <tr><td colspan="6" class="text-center py-4 text-muted">No categories created yet.</td></tr>
        <?php else: ?>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td>
                <div class="fw-bold text-dark"><i class="fa-solid fa-tag text-primary me-2"></i><?= e($cat['category_name']) ?></div>
              </td>
              <td class="text-muted small" style="max-width: 320px;">
                <?= e($cat['description'] ?? 'No description') ?>
              </td>
              <td>
                <span class="badge bg-light text-dark border px-3 py-1"><?= $cat['items_count'] ?> SKUs</span>
              </td>
              <td>
                <span class="fw-semibold text-dark"><?= number_format($cat['total_units']) ?></span>
              </td>
              <td>
                <span class="badge <?= ($cat['status'] === 'Active') ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary' ?>">
                  <?= e($cat['status']) ?>
                </span>
              </td>
              <td class="text-end">
                <?php if (has_role(['Admin', 'Store Manager'])): ?>
                  <a href="edit.php?id=<?= $cat['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit Category">
                    <i class="fa-regular fa-pen-to-square"></i>
                  </a>
                <?php endif; ?>
                <?php if (has_role(['Admin'])): ?>
                  <a href="delete.php?id=<?= $cat['id'] ?>" class="btn btn-sm btn-outline-danger ms-1" onclick="return confirm('Delete this category? Items assigned to it will prevent deletion.');" title="Delete Category">
                    <i class="fa-regular fa-trash-can"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
