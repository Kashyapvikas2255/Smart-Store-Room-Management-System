<?php
/**
 * Smart Store Room Management System
 * Authentication and Role Authorization Helper
 */

if (session_status() === PHP_SESSION_NONE) {
    // If cookie wasn't sent (e.g. strict cross-site iframe blocking), allow session continuity via request
    $sess_name = session_name();
    if (!isset($_COOKIE[$sess_name])) {
        $fallback_sid = $_REQUEST['sid'] ?? $_SERVER['HTTP_X_SESSION_ID'] ?? '';
        if (is_string($fallback_sid) && preg_match('/^[a-zA-Z0-9,-]{16,128}$/', $fallback_sid)) {
            session_id($fallback_sid);
        }
    }

    // Set secure cookie params for iframe compatibility (SameSite=None, Secure)
    @ini_set('session.cookie_samesite', 'None');
    @ini_set('session.cookie_secure', '1');
    @ini_set('session.cookie_httponly', '1');

    session_set_cookie_params([
        'lifetime' => 86400,
        'path'     => '/',
        'httponly' => true,
        'secure'   => true,
        'samesite' => 'None'
    ]);

    session_start();
}

/**
 * Check if the user is authenticated.
 * If not, redirect to the login page.
 */
function require_auth(): void {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['flash_error'] = "Please sign in to access the system.";
        $base = get_base_url();
        header("Location: {$base}/auth/login.php");
        exit;
    }
}

/**
 * Check if current user has one of the allowed roles
 */
function require_role(array $allowed_roles): void {
    require_auth();
    $current_role = $_SESSION['user_role'] ?? '';
    if (!in_array($current_role, $allowed_roles, true)) {
        $_SESSION['flash_error'] = "Access denied: Unauthorized operation for role '{$current_role}'.";
        $base = get_base_url();
        header("Location: {$base}/dashboard/index.php");
        exit;
    }
}

/**
 * Check role boolean helper for conditional UI elements
 */
function has_role(array $allowed_roles): bool {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    return in_array($_SESSION['user_role'], $allowed_roles, true);
}

/**
 * Retrieve persistent CSRF server secret
 */
function get_csrf_secret(): string {
    $secret_file = __DIR__ . '/.csrf_secret';
    if (file_exists($secret_file)) {
        $val = trim(@file_get_contents($secret_file) ?: '');
        if ($val !== '') {
            return $val;
        }
    }
    $key = bin2hex(random_bytes(32));
    @file_put_contents($secret_file, $key);
    return $key;
}

/**
 * Generate cryptographically signed CSRF token
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    $secret = get_csrf_secret();
    $time = time();
    $sig = hash_hmac('sha256', "csrf:{$time}:" . $_SESSION['csrf_token'], $secret);
    return "{$_SESSION['csrf_token']}:{$time}:{$sig}";
}

/**
 * Verify CSRF token from POST request with dual-layer validation
 */
function verify_csrf_token(?string $token): bool {
    if (empty($token)) {
        return false;
    }

    // Layer 1: Cryptographically signed HMAC token (seed:timestamp:signature)
    $parts = explode(':', $token);
    if (count($parts) === 3) {
        [$seed, $time, $sig] = $parts;
        $timestamp = (int)$time;
        // Verify time validity (valid for 4 hours)
        if (abs(time() - $timestamp) <= 14400) {
            $secret = get_csrf_secret();
            $expected_sig = hash_hmac('sha256', "csrf:{$time}:{$seed}", $secret);
            if (hash_equals($expected_sig, $sig)) {
                // If session csrf_token exists, check that it matches the seed
                if (!empty($_SESSION['csrf_token'])) {
                    if (hash_equals($_SESSION['csrf_token'], $seed)) {
                        return true;
                    }
                }
                // If session was initialized anew on POST in an iframe, restore verified seed
                $_SESSION['csrf_token'] = $seed;
                return true;
            }
        }
    }

    // Layer 2: Direct session token match (e.g. legacy plain token)
    if (!empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token)) {
        return true;
    }

    return false;
}

/**
 * Helper to determine base URL path dynamically for relative subfolders
 */
function get_base_url(): string {
    $script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    // Strip known subdirectories
    $subfolders = ['/config', '/includes', '/auth', '/dashboard', '/items', '/categories', '/suppliers', '/employees', '/departments', '/stock', '/alerts', '/reports', '/users'];
    $path = $script_dir;
    foreach ($subfolders as $sub) {
        if (substr($path, -strlen($sub)) === $sub) {
            $path = substr($path, 0, -strlen($sub));
            break;
        }
    }
    return rtrim($path, '/');
}
