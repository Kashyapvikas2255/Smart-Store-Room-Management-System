<?php
/**
 * Smart Store Room Management System
 * Executive Analytics & Inventory Dashboard
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Executive Dashboard';
$db = Database::getConnection();

// 1. KPI Calculations
$total_items = (int)$db->query("SELECT COUNT(*) FROM items WHERE status = 'Active'")->fetchColumn();
$total_categories = (int)$db->query("SELECT COUNT(*) FROM categories WHERE status = 'Active'")->fetchColumn();
$total_stock = (int)$db->query("SELECT COALESCE(SUM(current_stock), 0) FROM items WHERE status = 'Active'")->fetchColumn();
$low_stock_items = (int)$db->query("SELECT COUNT(*) FROM items WHERE status = 'Active' AND current_stock > 0 AND current_stock <= reorder_level")->fetchColumn();
$out_of_stock_items = (int)$db->query("SELECT COUNT(*) FROM items WHERE status = 'Active' AND current_stock = 0")->fetchColumn();
$total_employees = (int)$db->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'")->fetchColumn();

$today_stock_in = (int)$db->query("
    SELECT COALESCE(SUM(quantity), 0) 
    FROM stock_transactions 
    WHERE transaction_type = 'IN' AND transaction_date = CURDATE()
")->fetchColumn();

$today_stock_out = (int)$db->query("
    SELECT COALESCE(SUM(quantity), 0) 
    FROM stock_transactions 
    WHERE transaction_type = 'OUT' AND transaction_date = CURDATE()
")->fetchColumn();

$pending_requisitions_count = get_pending_requisitions_count($db);
$total_audits_count = (int)$db->query("SELECT COUNT(*) FROM stock_audits")->fetchColumn();

// 2. Recent Transactions (Last 8)
$stmt_recent = $db->query("
    SELECT 
        st.id,
        st.transaction_code,
        st.transaction_type,
        st.quantity,
        st.transaction_date,
        st.reference_no,
        i.item_code,
        i.item_name,
        i.unit,
        s.supplier_name,
        e.employee_name,
        d.department_name,
        u.name as creator_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    JOIN users u ON st.created_by = u.id
    ORDER BY st.created_at DESC
    LIMIT 8
");
$recent_transactions = $stmt_recent->fetchAll();

// 3. Low Stock Items List for Alert Widget
$stmt_low_stock = $db->query("
    SELECT 
        id, item_code, item_name, current_stock, reorder_level, maximum_stock, unit, location, rack_no
    FROM items 
    WHERE status = 'Active' AND current_stock <= reorder_level
    ORDER BY current_stock ASC
    LIMIT 6
");
$low_stock_list = $stmt_low_stock->fetchAll();

// 4. Chart Data: Category-wise Stock Distribution
$stmt_cat_chart = $db->query("
    SELECT c.category_name, COALESCE(SUM(i.current_stock), 0) as total_units
    FROM categories c
    LEFT JOIN items i ON c.id = i.category_id AND i.status = 'Active'
    WHERE c.status = 'Active'
    GROUP BY c.id
    HAVING total_units > 0
    ORDER BY total_units DESC
");
$category_chart_data = $stmt_cat_chart->fetchAll();

// 5. Chart Data: Top 5 Issued Items (All-Time OUT)
$stmt_top_issued = $db->query("
    SELECT i.item_name, SUM(st.quantity) as total_issued
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    WHERE st.transaction_type = 'OUT'
    GROUP BY st.item_id
    ORDER BY total_issued DESC
    LIMIT 5
");
$top_issued_data = $stmt_top_issued->fetchAll();

// 6. Chart Data: Monthly Movement for Last 6 Months
$monthly_labels = [];
$monthly_in = [];
$monthly_out = [];
for ($m = 5; $m >= 0; $m--) {
    $month_str = date('Y-m', strtotime("-$m month"));
    $display_label = date('M Y', strtotime("-$m month"));
    $monthly_labels[] = $display_label;
    
    $stmt_m_in = $db->prepare("SELECT COALESCE(SUM(quantity), 0) FROM stock_transactions WHERE transaction_type = 'IN' AND DATE_FORMAT(transaction_date, '%Y-%m') = :m");
    $stmt_m_in->execute([':m' => $month_str]);
    $monthly_in[] = (int)$stmt_m_in->fetchColumn();

    $stmt_m_out = $db->prepare("SELECT COALESCE(SUM(quantity), 0) FROM stock_transactions WHERE transaction_type = 'OUT' AND DATE_FORMAT(transaction_date, '%Y-%m') = :m");
    $stmt_m_out->execute([':m' => $month_str]);
    $monthly_out[] = (int)$stmt_m_out->fetchColumn();
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<!-- Page Header and Quick Actions -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Store Room Overview</h3>
    <p class="text-muted mb-0 small">Real-time inventory levels, stock transactions, and critical restocking alerts.</p>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <a href="../stock/stock-in.php" class="btn btn-success d-inline-flex align-items-center gap-2 shadow-sm">
      <i class="fa-solid fa-arrow-down-to-bracket"></i> Stock In
    </a>
    <a href="../stock/stock-out.php" class="btn btn-danger d-inline-flex align-items-center gap-2 shadow-sm">
      <i class="fa-solid fa-arrow-up-from-bracket"></i> Stock Out
    </a>
    <a href="../items/add.php" class="btn btn-primary-deep d-inline-flex align-items-center gap-2 shadow-sm">
      <i class="fa-solid fa-plus"></i> Add Item
    </a>
  </div>
</div>

<!-- KPI Cards Grid (8 Cards) -->
<div class="row g-3 mb-4">
  <!-- Total Items -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Total Items</div>
        <div class="kpi-value mt-1"><?= number_format($total_items) ?></div>
        <div class="small text-muted mt-1">Cataloged SKUs</div>
      </div>
      <div class="kpi-icon bg-primary-subtle text-primary">
        <i class="fa-solid fa-boxes-stacked"></i>
      </div>
    </div>
  </div>

  <!-- Total Categories -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Categories</div>
        <div class="kpi-value mt-1"><?= number_format($total_categories) ?></div>
        <div class="small text-muted mt-1">Active Classifications</div>
      </div>
      <div class="kpi-icon bg-info-subtle text-info">
        <i class="fa-solid fa-tags"></i>
      </div>
    </div>
  </div>

  <!-- Total Stock Units -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Total Stock</div>
        <div class="kpi-value mt-1"><?= number_format($total_stock) ?></div>
        <div class="small text-muted mt-1">Units on Shelves</div>
      </div>
      <div class="kpi-icon bg-success-subtle text-success">
        <i class="fa-solid fa-cubes"></i>
      </div>
    </div>
  </div>

  <!-- Low Stock Items -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center border-warning-subtle">
      <div>
        <div class="kpi-label text-warning-emphasis">Low Stock Items</div>
        <div class="kpi-value text-warning mt-1"><?= number_format($low_stock_items) ?></div>
        <div class="small text-muted mt-1">&le; Reorder Level</div>
      </div>
      <div class="kpi-icon bg-warning-subtle text-warning">
        <i class="fa-solid fa-triangle-exclamation"></i>
      </div>
    </div>
  </div>

  <!-- Out of Stock Items -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center border-danger-subtle">
      <div>
        <div class="kpi-label text-danger">Out of Stock</div>
        <div class="kpi-value text-danger mt-1"><?= number_format($out_of_stock_items) ?></div>
        <div class="small text-muted mt-1">Zero Units Remaining</div>
      </div>
      <div class="kpi-icon bg-danger-subtle text-danger">
        <i class="fa-solid fa-circle-xmark"></i>
      </div>
    </div>
  </div>

  <!-- Today's Stock In -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Today's Stock In</div>
        <div class="kpi-value text-success mt-1">+<?= number_format($today_stock_in) ?></div>
        <div class="small text-muted mt-1">Units Received</div>
      </div>
      <div class="kpi-icon bg-success-subtle text-success">
        <i class="fa-solid fa-arrow-down-to-bracket"></i>
      </div>
    </div>
  </div>

  <!-- Today's Stock Out -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Today's Stock Out</div>
        <div class="kpi-value text-danger mt-1">-<?= number_format($today_stock_out) ?></div>
        <div class="small text-muted mt-1">Units Issued</div>
      </div>
      <div class="kpi-icon bg-danger-subtle text-danger">
        <i class="fa-solid fa-arrow-up-from-bracket"></i>
      </div>
    </div>
  </div>

  <!-- Total Employees -->
  <div class="col-6 col-md-3">
    <div class="card-kpi d-flex justify-content-between align-items-center">
      <div>
        <div class="kpi-label">Registered Staff</div>
        <div class="kpi-value mt-1"><?= number_format($total_employees) ?></div>
        <div class="small text-muted mt-1">Authorized Requisitioners</div>
      </div>
      <div class="kpi-icon bg-primary-subtle text-primary">
        <i class="fa-solid fa-users"></i>
      </div>
    </div>
  </div>
</div>

<!-- Charts Section -->
<div class="row g-3 mb-4">
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-chart-line text-primary me-2"></i> Stock Movement (Last 6 Months: In vs Out)
        </h6>
      </div>
      <div class="card-body">
        <canvas id="monthlyMovementChart" height="120"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-chart-pie text-info me-2"></i> Category Stock Distribution
        </h6>
      </div>
      <div class="card-body d-flex align-items-center justify-content-center">
        <div style="max-height: 250px; width: 100%;">
          <canvas id="categoryDistributionChart"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bottom Section: Recent Transactions & Low Stock Alert Widget -->
<div class="row g-3">
  <!-- Recent Transactions Table -->
  <div class="col-xl-8">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-clock-rotate-left text-primary me-2"></i> Recent Stock Transactions
        </h6>
        <a href="../stock/history.php" class="btn btn-sm btn-outline-primary">View All History</a>
      </div>
      <div class="table-responsive">
        <table class="table table-custom table-hover align-middle">
          <thead>
            <tr>
              <th>TXN Code</th>
              <th>Item</th>
              <th>Type</th>
              <th>Quantity</th>
              <th>Recipient / Supplier</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($recent_transactions)): ?>
              <tr><td colspan="6" class="text-center py-4 text-muted">No stock transactions recorded yet.</td></tr>
            <?php else: ?>
              <?php foreach ($recent_transactions as $txn): ?>
                <?php
                  $badge_class = 'bg-secondary';
                  if ($txn['transaction_type'] === 'IN') $badge_class = 'bg-success';
                  if ($txn['transaction_type'] === 'OUT') $badge_class = 'bg-danger';
                  if ($txn['transaction_type'] === 'RETURN') $badge_class = 'bg-info text-white';
                  if ($txn['transaction_type'] === 'ADJUSTMENT') $badge_class = 'bg-warning text-dark';
                ?>
                <tr>
                  <td>
                    <span class="fw-semibold text-dark font-monospace"><?= e($txn['transaction_code']) ?></span>
                    <?php if ($txn['reference_no']): ?>
                      <div class="text-muted fs-xs"><?= e($txn['reference_no']) ?></div>
                    <?php endif; ?>
                  </td>
                  <td>
                    <div class="fw-medium text-dark"><?= e($txn['item_name']) ?></div>
                    <small class="text-muted font-monospace"><?= e($txn['item_code']) ?></small>
                  </td>
                  <td>
                    <span class="badge <?= $badge_class ?>"><?= e($txn['transaction_type']) ?></span>
                  </td>
                  <td>
                    <span class="fw-bold <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? 'text-success' : 'text-danger' ?>">
                      <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? '+' : '-' ?><?= $txn['quantity'] ?> <?= e($txn['unit']) ?>
                    </span>
                  </td>
                  <td>
                    <?php if ($txn['transaction_type'] === 'IN'): ?>
                      <i class="fa-solid fa-truck-field text-muted me-1"></i> <?= e($txn['supplier_name'] ?? 'Direct Intake') ?>
                    <?php else: ?>
                      <i class="fa-solid fa-user text-muted me-1"></i> <?= e($txn['employee_name'] ?? 'Internal Store') ?>
                      <?php if ($txn['department_name']): ?>
                        <div class="text-muted fs-xs"><?= e($txn['department_name']) ?></div>
                      <?php endif; ?>
                    <?php endif; ?>
                  </td>
                  <td class="text-muted fs-sm">
                    <?= format_date($txn['transaction_date']) ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Low Stock Alert Widget -->
  <div class="col-xl-4">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="card-title fw-bold mb-0 text-warning-emphasis">
          <i class="fa-solid fa-triangle-exclamation text-warning me-2"></i> Low & Out of Stock
        </h6>
        <a href="../alerts/low-stock.php" class="btn btn-sm btn-outline-warning">View All</a>
      </div>
      <div class="card-body p-0">
        <div class="list-group list-group-flush">
          <?php if (empty($low_stock_list)): ?>
            <div class="p-4 text-center text-muted">
              <i class="fa-solid fa-circle-check text-success fs-3 mb-2"></i>
              <div>All items have healthy inventory levels!</div>
            </div>
          <?php else: ?>
            <?php foreach ($low_stock_list as $item): ?>
              <?php $status_info = get_stock_status_info($item['current_stock'], $item['reorder_level'], $item['maximum_stock']); ?>
              <div class="list-group-item p-3">
                <div class="d-flex justify-content-between align-items-start">
                  <div>
                    <h6 class="mb-0 fw-semibold text-dark"><?= e($item['item_name']) ?></h6>
                    <small class="text-muted font-monospace"><?= e($item['item_code']) ?> &bull; Rack <?= e($item['rack_no']) ?></small>
                  </div>
                  <span class="badge-status <?= $status_info['badge'] ?>">
                    <i class="fa-solid <?= $status_info['icon'] ?>"></i> <?= $status_info['status'] ?>
                  </span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-2 pt-1 border-top border-light">
                  <div class="small">
                    <span class="text-muted">Stock:</span> <strong class="<?= $item['current_stock'] == 0 ? 'text-danger' : 'text-warning' ?>"><?= $item['current_stock'] ?></strong> / Reorder: <?= $item['reorder_level'] ?> <?= e($item['unit']) ?>
                  </div>
                  <a href="../stock/stock-in.php?item_id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-success py-0 px-2">
                    <i class="fa-solid fa-cart-plus me-1"></i> Restock
                  </a>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Chart initialization scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  // 1. Monthly Movement Chart
  const monthlyCtx = document.getElementById('monthlyMovementChart');
  if (monthlyCtx) {
    new Chart(monthlyCtx, {
      type: 'bar',
      data: {
        labels: <?= json_encode($monthly_labels) ?>,
        datasets: [
          {
            label: 'Stock In (Received)',
            data: <?= json_encode($monthly_in) ?>,
            backgroundColor: 'rgba(16, 185, 129, 0.85)',
            borderRadius: 6
          },
          {
            label: 'Stock Out (Issued)',
            data: <?= json_encode($monthly_out) ?>,
            backgroundColor: 'rgba(239, 68, 68, 0.85)',
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'top' }
        },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }

  // 2. Category Distribution Chart
  const catCtx = document.getElementById('categoryDistributionChart');
  if (catCtx) {
    new Chart(catCtx, {
      type: 'doughnut',
      data: {
        labels: <?= json_encode(array_column($category_chart_data, 'category_name')) ?>,
        datasets: [{
          data: <?= json_encode(array_map('intval', array_column($category_chart_data, 'total_units'))) ?>,
          backgroundColor: [
            '#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#64748b'
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } }
        }
      }
    });
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
