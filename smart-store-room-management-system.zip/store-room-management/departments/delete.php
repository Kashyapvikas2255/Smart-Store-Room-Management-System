<?php
/**
 * Smart Store Room Management System
 * Delete Department Handler
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid department identifier.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

try {
    $chk = $db->prepare("SELECT COUNT(*) FROM employees WHERE department_id = :id");
    $chk->execute([':id' => $id]);
    $emp_count = (int)$chk->fetchColumn();

    if ($emp_count > 0) {
        set_flash('error', "Cannot delete department with {$emp_count} active employees assigned. Reassign the personnel first.");
        header("Location: index.php");
        exit;
    }

    $del = $db->prepare("DELETE FROM departments WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', "Department deleted successfully.");
} catch (Exception $e) {
    set_flash('error', "Database error: " . $e->getMessage());
}

header("Location: index.php");
exit;
