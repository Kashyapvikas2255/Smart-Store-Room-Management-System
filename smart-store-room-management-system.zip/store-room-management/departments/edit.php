<?php
/**
 * Smart Store Room Management System
 * Edit Department
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Edit Department';
$db = Database::getConnection();
$error = '';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid department identifier.");
    header("Location: index.php");
    exit;
}

$stmt = $db->prepare("SELECT * FROM departments WHERE id = :id");
$stmt->execute([':id' => $id]);
$dept = $stmt->fetch();

if (!$dept) {
    set_flash('error', "Department not found.");
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dept_name = trim($_POST['department_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($dept_name)) {
        $error = "Department name cannot be empty.";
    } else {
        try {
            $update = $db->prepare("UPDATE departments SET department_name = :name, description = :desc, status = :status WHERE id = :id");
            $update->execute([':name' => $dept_name, ':desc' => $description, ':status' => $status, ':id' => $id]);

            set_flash('success', "Department updated successfully.");
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold mb-0 text-dark">Edit Department</h3>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?= $id ?>" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="mb-3">
          <label for="department_name" class="form-label">Department Name <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="department_name" name="department_name" value="<?= e($dept['department_name']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3"><?= e($dept['description']) ?></textarea>
        </div>
        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" id="status" name="status">
            <option value="Active" <?= ($dept['status'] === 'Active') ? 'selected' : '' ?>>Active</option>
            <option value="Inactive" <?= ($dept['status'] === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
          </select>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-check me-2"></i> Update Department
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
