<?php
/**
 * Smart Store Room Management System
 * Department Management
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Departments';
$db = Database::getConnection();

// Fetch departments with employee count and total items issued to the department
$stmt = $db->query("
    SELECT 
        d.*,
        COUNT(DISTINCT e.id) as employee_count,
        COALESCE(SUM(CASE WHEN st.transaction_type = 'OUT' THEN st.quantity ELSE 0 END), 0) as total_issued_units
    FROM departments d
    LEFT JOIN employees e ON d.id = e.department_id
    LEFT JOIN stock_transactions st ON d.id = st.department_id
    GROUP BY d.id
    ORDER BY d.department_name ASC
");
$departments = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Department Directory</h3>
    <p class="text-muted mb-0 small">Manage organizational cost centers, employee allocations, and inventory consumption.</p>
  </div>
  <?php if (has_role(['Admin', 'Store Manager'])): ?>
    <a href="add.php" class="btn btn-primary-deep">
      <i class="fa-solid fa-plus me-1"></i> Add Department
    </a>
  <?php endif; ?>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Department Name</th>
          <th>Description</th>
          <th>Assigned Personnel</th>
          <th>Lifetime Consumption</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($departments)): ?>
          <tr><td colspan="6" class="text-center py-4 text-muted">No departments created.</td></tr>
        <?php else: ?>
          <?php foreach ($departments as $dept): ?>
            <tr>
              <td>
                <div class="fw-bold text-dark"><i class="fa-solid fa-building text-primary me-2"></i><?= e($dept['department_name']) ?></div>
              </td>
              <td class="text-muted small" style="max-width: 320px;">
                <?= e($dept['description'] ?? 'No description') ?>
              </td>
              <td>
                <span class="badge bg-light text-dark border px-3 py-1"><?= $dept['employee_count'] ?> Staff</span>
              </td>
              <td>
                <span class="fw-bold text-danger"><?= number_format($dept['total_issued_units']) ?> items</span>
              </td>
              <td>
                <span class="badge <?= ($dept['status'] === 'Active') ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary' ?>">
                  <?= e($dept['status']) ?>
                </span>
              </td>
              <td class="text-end">
                <a href="../reports/department-report.php?department_id=<?= $dept['id'] ?>" class="btn btn-sm btn-outline-info" title="View Consumption Report">
                  <i class="fa-solid fa-chart-pie"></i> Usage
                </a>
                <?php if (has_role(['Admin', 'Store Manager'])): ?>
                  <a href="edit.php?id=<?= $dept['id'] ?>" class="btn btn-sm btn-outline-primary ms-1" title="Edit Department">
                    <i class="fa-regular fa-pen-to-square"></i>
                  </a>
                <?php endif; ?>
                <?php if (has_role(['Admin'])): ?>
                  <a href="delete.php?id=<?= $dept['id'] ?>" class="btn btn-sm btn-outline-danger ms-1" onclick="return confirm('Delete this department? Make sure no employees are assigned.');" title="Delete Department">
                    <i class="fa-regular fa-trash-can"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
