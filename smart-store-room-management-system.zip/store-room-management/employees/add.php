<?php
/**
 * Smart Store Room Management System
 * Add Employee
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Add Employee';
$db = Database::getConnection();
$error = '';

$departments = $db->query("SELECT id, department_name FROM departments WHERE status = 'Active' ORDER BY department_name ASC")->fetchAll();

// Auto-generate employee code
$candidate_code = generate_employee_code($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emp_code = trim($_POST['employee_code'] ?? '');
    $emp_name = trim($_POST['employee_name'] ?? '');
    $dept_id = (int)($_POST['department_id'] ?? 0);
    $designation = trim($_POST['designation'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($emp_code) || empty($emp_name) || empty($dept_id) || empty($designation)) {
        $error = "Employee code, name, department, and designation are required.";
    } else {
        try {
            $chk = $db->prepare("SELECT COUNT(*) FROM employees WHERE employee_code = :code");
            $chk->execute([':code' => $emp_code]);
            if ($chk->fetchColumn() > 0) {
                $error = "Employee code '{$emp_code}' is already registered.";
            } else {
                $stmt = $db->prepare("
                    INSERT INTO employees (employee_code, employee_name, department_id, designation, phone, email, status)
                    VALUES (:code, :name, :dept, :desig, :phone, :email, :status)
                ");
                $stmt->execute([
                    ':code' => $emp_code,
                    ':name' => $emp_name,
                    ':dept' => $dept_id,
                    ':desig' => $designation,
                    ':phone' => $phone,
                    ':email' => $email,
                    ':status' => $status
                ]);

                set_flash('success', "Employee '{$emp_name}' added successfully.");
                header("Location: index.php");
                exit;
            }
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold mb-0 text-dark">Add New Employee</h3>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="add.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-md-4">
            <label for="employee_code" class="form-label">Employee Code <span class="text-danger">*</span></label>
            <input type="text" class="form-control font-monospace" id="employee_code" name="employee_code" value="<?= e($_POST['employee_code'] ?? $candidate_code) ?>" required>
          </div>
          <div class="col-md-8">
            <label for="employee_name" class="form-label">Full Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="employee_name" name="employee_name" placeholder="e.g. Sarah Jenkins" value="<?= e($_POST['employee_name'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label for="department_id" class="form-label">Department <span class="text-danger">*</span></label>
            <select class="form-select" id="department_id" name="department_id" required>
              <option value="">-- Select Department --</option>
              <?php foreach ($departments as $dept): ?>
                <option value="<?= $dept['id'] ?>" <?= (($_POST['department_id'] ?? '') == $dept['id']) ? 'selected' : '' ?>>
                  <?= e($dept['department_name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label for="designation" class="form-label">Designation / Title <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="designation" name="designation" placeholder="e.g. Senior Network Engineer" value="<?= e($_POST['designation'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="+1 (555) 302-9912" value="<?= e($_POST['phone'] ?? '') ?>">
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Work Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="s.jenkins@enterprise.internal" value="<?= e($_POST['email'] ?? '') ?>">
          </div>
          <div class="col-md-6">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status">
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-floppy-disk me-2"></i> Register Employee
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
