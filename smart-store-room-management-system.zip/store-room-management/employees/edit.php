<?php
/**
 * Smart Store Room Management System
 * Edit Employee
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Edit Employee';
$db = Database::getConnection();
$error = '';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid employee ID.");
    header("Location: index.php");
    exit;
}

$stmt = $db->prepare("SELECT * FROM employees WHERE id = :id");
$stmt->execute([':id' => $id]);
$employee = $stmt->fetch();

if (!$employee) {
    set_flash('error', "Employee record not found.");
    header("Location: index.php");
    exit;
}

$departments = $db->query("SELECT id, department_name FROM departments WHERE status = 'Active' ORDER BY department_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emp_name = trim($_POST['employee_name'] ?? '');
    $dept_id = (int)($_POST['department_id'] ?? 0);
    $designation = trim($_POST['designation'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($emp_name) || empty($dept_id) || empty($designation)) {
        $error = "Name, department, and designation are required.";
    } else {
        try {
            $stmt = $db->prepare("
                UPDATE employees 
                SET employee_name = :name, department_id = :dept, designation = :desig, phone = :phone, email = :email, status = :status
                WHERE id = :id
            ");
            $stmt->execute([
                ':name' => $emp_name,
                ':dept' => $dept_id,
                ':desig' => $designation,
                ':phone' => $phone,
                ':email' => $email,
                ':status' => $status,
                ':id' => $id
            ]);

            set_flash('success', "Employee updated successfully.");
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Edit Employee: <?= e($employee['employee_name']) ?></h3>
        <p class="text-muted small mb-0">Code: <span class="font-monospace fw-bold text-primary"><?= e($employee['employee_code']) ?></span></p>
      </div>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?= $id ?>" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label text-muted">Employee Code</label>
            <input type="text" class="form-control font-monospace bg-light" value="<?= e($employee['employee_code']) ?>" readonly>
          </div>
          <div class="col-md-8">
            <label for="employee_name" class="form-label">Full Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="employee_name" name="employee_name" value="<?= e($employee['employee_name']) ?>" required>
          </div>
          <div class="col-md-6">
            <label for="department_id" class="form-label">Department <span class="text-danger">*</span></label>
            <select class="form-select" id="department_id" name="department_id" required>
              <?php foreach ($departments as $dept): ?>
                <option value="<?= $dept['id'] ?>" <?= ($employee['department_id'] == $dept['id']) ? 'selected' : '' ?>>
                  <?= e($dept['department_name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label for="designation" class="form-label">Designation <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="designation" name="designation" value="<?= e($employee['designation']) ?>" required>
          </div>
          <div class="col-md-6">
            <label for="phone" class="form-label">Phone</label>
            <input type="text" class="form-control" id="phone" name="phone" value="<?= e($employee['phone']) ?>">
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= e($employee['email']) ?>">
          </div>
          <div class="col-md-6">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status">
              <option value="Active" <?= ($employee['status'] === 'Active') ? 'selected' : '' ?>>Active</option>
              <option value="Inactive" <?= ($employee['status'] === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-check me-2"></i> Update Employee
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
