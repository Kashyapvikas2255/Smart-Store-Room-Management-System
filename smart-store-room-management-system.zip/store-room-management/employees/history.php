<?php
/**
 * Smart Store Room Management System
 * Employee Issue History & Requisition Analytics
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid employee identifier.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

// Fetch employee profile
$stmt = $db->prepare("
    SELECT e.*, d.department_name 
    FROM employees e 
    JOIN departments d ON e.department_id = d.id 
    WHERE e.id = :id
");
$stmt->execute([':id' => $id]);
$employee = $stmt->fetch();

if (!$employee) {
    set_flash('error', "Employee not found.");
    header("Location: index.php");
    exit;
}

$page_title = 'Issue History: ' . $employee['employee_name'];

// Calculate employee totals:
// Total transactions & total items issued
$metric_stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_txns,
        COALESCE(SUM(quantity), 0) as total_qty
    FROM stock_transactions 
    WHERE employee_id = :id AND transaction_type = 'OUT'
");
$metric_stmt->execute([':id' => $id]);
$metrics = $metric_stmt->fetch();

// Most frequently issued items
$top_stmt = $db->prepare("
    SELECT 
        i.item_name,
        i.item_code,
        i.unit,
        COUNT(st.id) as req_count,
        SUM(st.quantity) as total_qty
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    WHERE st.employee_id = :id AND st.transaction_type = 'OUT'
    GROUP BY i.id
    ORDER BY total_qty DESC
    LIMIT 5
");
$top_stmt->execute([':id' => $id]);
$top_items = $top_stmt->fetchAll();

// All transactions for this employee
$hist_stmt = $db->prepare("
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        u.name as issued_by_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    JOIN users u ON st.created_by = u.id
    WHERE st.employee_id = :id
    ORDER BY st.transaction_date DESC, st.id DESC
");
$hist_stmt->execute([':id' => $id]);
$history = $hist_stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <div class="d-flex align-items-center gap-2 mb-1">
      <span class="badge bg-primary font-monospace fs-6 px-3 py-1"><?= e($employee['employee_code']) ?></span>
      <span class="badge bg-light text-dark border"><?= e($employee['department_name']) ?></span>
    </div>
    <h3 class="fw-bold mb-0 text-dark"><?= e($employee['employee_name']) ?> &mdash; Requisition History</h3>
  </div>
  <div class="d-flex gap-2">
    <a href="../stock/stock-out.php?employee_id=<?= $employee['id'] ?>" class="btn btn-danger">
      <i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Issue Items to Employee
    </a>
    <a href="index.php" class="btn btn-outline-secondary">Back to Employees</a>
  </div>
</div>

<!-- Metrics Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Requisitions</div>
      <div class="fs-3 fw-bold text-dark"><?= number_format($metrics['total_txns']) ?></div>
      <small class="text-muted">Completed issue transactions</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Items Drawn</div>
      <div class="fs-3 fw-bold text-danger"><?= number_format($metrics['total_qty']) ?></div>
      <small class="text-muted">Total discrete units drawn from store</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Designation & Department</div>
      <div class="fs-5 fw-bold text-dark"><?= e($employee['designation']) ?></div>
      <small class="text-muted"><i class="fa-solid fa-envelope me-1"></i><?= e($employee['email'] ?: 'No email on record') ?></small>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- Top Issued Items List -->
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3 border-bottom">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-fire text-warning me-2"></i> Most Frequently Drawn
        </h6>
      </div>
      <div class="card-body p-3">
        <?php if (empty($top_items)): ?>
          <p class="text-muted small text-center my-4">No requisitions on record yet.</p>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($top_items as $top): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                <div>
                  <div class="fw-semibold text-dark small"><?= e($top['item_name']) ?></div>
                  <small class="text-muted font-monospace fs-xs"><?= e($top['item_code']) ?> &bull; <?= $top['req_count'] ?> requisition(s)</small>
                </div>
                <span class="badge bg-danger-subtle text-danger border border-danger-subtle fw-bold">
                  <?= $top['total_qty'] ?> <?= e($top['unit']) ?>
                </span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Requisitions Table -->
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-clock-rotate-left text-primary me-2"></i> All Issued Items Ledger
        </h6>
        <span class="badge bg-light text-dark border"><?= count($history) ?> Records</span>
      </div>
      <div class="table-responsive">
        <table class="table table-custom table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Txn Code</th>
              <th>Item</th>
              <th>Qty</th>
              <th>Ref No</th>
              <th>Date</th>
              <th>Issued By</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($history)): ?>
              <tr><td colspan="6" class="text-center py-4 text-muted">No issue records found for this employee.</td></tr>
            <?php else: ?>
              <?php foreach ($history as $row): ?>
                <tr>
                  <td class="font-monospace fw-bold text-dark small"><?= e($row['transaction_code']) ?></td>
                  <td>
                    <div class="fw-semibold text-dark small"><?= e($row['item_name']) ?></div>
                    <small class="text-muted font-monospace fs-xs"><?= e($row['item_code']) ?></small>
                  </td>
                  <td>
                    <span class="badge <?= ($row['transaction_type'] === 'OUT') ? 'bg-danger' : 'bg-info' ?>">
                      <?= ($row['transaction_type'] === 'OUT' ? '-' : '+') . $row['quantity'] ?> <?= e($row['unit']) ?>
                    </span>
                  </td>
                  <td class="small text-muted font-monospace"><?= e($row['reference_no'] ?? '-') ?></td>
                  <td class="small text-muted"><?= format_date($row['transaction_date']) ?></td>
                  <td class="small text-muted"><?= e($row['issued_by_name']) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
