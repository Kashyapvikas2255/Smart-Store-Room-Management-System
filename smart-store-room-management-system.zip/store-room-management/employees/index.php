<?php
/**
 * Smart Store Room Management System
 * Employee Directory
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Employees';
$db = Database::getConnection();

$search = trim($_GET['search'] ?? '');
$dept_filter = trim($_GET['department_id'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if ($search !== '') {
    $where_clauses[] = "(e.employee_code LIKE :search OR e.employee_name LIKE :search OR e.designation LIKE :search OR e.email LIKE :search)";
    $params[':search'] = "%{$search}%";
}

if ($dept_filter !== '') {
    $where_clauses[] = "e.department_id = :dept_id";
    $params[':dept_id'] = $dept_filter;
}

$where_sql = implode(' AND ', $where_clauses);

// Fetch employees with issued items statistics
$sql = "
    SELECT 
        e.*,
        d.department_name,
        COUNT(DISTINCT st.id) as total_requisitions,
        COALESCE(SUM(st.quantity), 0) as total_items_issued
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    LEFT JOIN stock_transactions st ON e.id = st.employee_id AND st.transaction_type = 'OUT'
    WHERE {$where_sql}
    GROUP BY e.id
    ORDER BY e.employee_name ASC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();

// Fetch departments for filter
$departments = $db->query("SELECT id, department_name FROM departments WHERE status = 'Active' ORDER BY department_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Employee Directory</h3>
    <p class="text-muted mb-0 small">Registered staff members authorized to requisition and draw store inventory.</p>
  </div>
  <?php if (has_role(['Admin', 'Store Manager'])): ?>
    <a href="add.php" class="btn btn-primary-deep">
      <i class="fa-solid fa-user-plus me-1"></i> Add Employee
    </a>
  <?php endif; ?>
</div>

<!-- Filters -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="index.php" class="row g-2 align-items-center">
      <div class="col-md-6">
        <div class="input-group">
          <span class="input-group-text bg-white text-muted border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" name="search" class="form-control border-start-0" placeholder="Search by name, code, designation, or email..." value="<?= e($search) ?>">
        </div>
      </div>
      <div class="col-md-4">
        <select name="department_id" class="form-select">
          <option value="">-- All Departments --</option>
          <?php foreach ($departments as $dept): ?>
            <option value="<?= $dept['id'] ?>" <?= ($dept_filter == $dept['id']) ? 'selected' : '' ?>>
              <?= e($dept['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-flex gap-2">
        <button type="submit" class="btn btn-primary-deep flex-grow-1">Filter</button>
        <?php if ($search !== '' || $dept_filter !== ''): ?>
          <a href="index.php" class="btn btn-outline-secondary" title="Clear Filters"><i class="fa-solid fa-xmark"></i></a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Employee Code</th>
          <th>Employee Name</th>
          <th>Department</th>
          <th>Designation</th>
          <th>Contact</th>
          <th>Items Issued</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($employees)): ?>
          <tr><td colspan="8" class="text-center py-5 text-muted">No employees found.</td></tr>
        <?php else: ?>
          <?php foreach ($employees as $emp): ?>
            <tr>
              <td>
                <span class="font-monospace fw-bold text-dark"><?= e($emp['employee_code']) ?></span>
              </td>
              <td>
                <div class="fw-bold text-dark">
                  <a href="history.php?id=<?= $emp['id'] ?>" class="text-decoration-none text-dark hover-primary">
                    <?= e($emp['employee_name']) ?>
                  </a>
                </div>
                <small class="text-muted"><i class="fa-regular fa-envelope me-1"></i><?= e($emp['email']) ?></small>
              </td>
              <td>
                <span class="badge bg-light text-dark border"><?= e($emp['department_name']) ?></span>
              </td>
              <td>
                <span class="text-dark small"><?= e($emp['designation']) ?></span>
              </td>
              <td>
                <span class="small text-muted"><i class="fa-solid fa-phone me-1"></i><?= e($emp['phone']) ?></span>
              </td>
              <td>
                <span class="fw-bold text-danger"><?= $emp['total_items_issued'] ?> units</span>
                <div class="text-muted fs-xs"><?= $emp['total_requisitions'] ?> requests</div>
              </td>
              <td>
                <span class="badge <?= ($emp['status'] === 'Active') ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary' ?>">
                  <?= e($emp['status']) ?>
                </span>
              </td>
              <td class="text-end">
                <a href="history.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-info" title="View Issue History">
                  <i class="fa-solid fa-clock-rotate-left"></i> History
                </a>
                <?php if (has_role(['Admin', 'Store Manager'])): ?>
                  <a href="edit.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-primary ms-1" title="Edit Employee">
                    <i class="fa-regular fa-pen-to-square"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
