  </main>
  <footer class="bg-white border-top py-3 px-4 text-muted small d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
    <div>
      &copy; <?= date('Y') ?> <strong>Smart Store Room Management System</strong> — <em>Efficient Inventory. Smarter Store Management.</em>
    </div>
    <div class="d-flex align-items-center gap-3">
      <span><i class="fa-solid fa-shield-halved text-success me-1"></i> Role: <?= e($_SESSION['user_role'] ?? 'Staff') ?></span>
      <span><i class="fa-solid fa-server text-primary me-1"></i> System Active</span>
    </div>
  </footer>
</div><!-- /#content-wrapper -->
</div><!-- /#app-wrapper -->

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS Script -->
<script src="<?= $base_url ?>/assets/js/script.js"></script>
</body>
</html>
