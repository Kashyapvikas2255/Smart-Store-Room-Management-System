<?php
/**
 * Smart Store Room Management System
 * General Utility & Helper Functions
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

/**
 * Sanitize output to prevent XSS
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Format currency
 */
function format_currency($amount): string {
    return '$' . number_format((float)$amount, 2);
}

/**
 * Format date
 */
function format_date(?string $date, bool $include_time = false): string {
    if (!$date) return '-';
    $timestamp = strtotime($date);
    return $include_time ? date('d M Y, h:i A', $timestamp) : date('d M Y', $timestamp);
}

/**
 * Set flash alert message
 */
function set_flash(string $type, string $message): void {
    $_SESSION['flash_' . $type] = $message;
}

/**
 * Render flash alert messages
 */
function render_flash(): string {
    $output = '';
    if (!empty($_SESSION['flash_success'])) {
        $output .= '<div class="alert alert-success alert-dismissible fade show d-flex align-items-center mb-4" role="alert">'
            . '<i class="fa-solid fa-circle-check me-2 fs-5"></i>'
            . '<div>' . e($_SESSION['flash_success']) . '</div>'
            . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
            . '</div>';
        unset($_SESSION['flash_success']);
    }
    if (!empty($_SESSION['flash_error'])) {
        $output .= '<div class="alert alert-danger alert-dismissible fade show d-flex align-items-center mb-4" role="alert">'
            . '<i class="fa-solid fa-triangle-exclamation me-2 fs-5"></i>'
            . '<div>' . e($_SESSION['flash_error']) . '</div>'
            . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
            . '</div>';
        unset($_SESSION['flash_error']);
    }
    if (!empty($_SESSION['flash_warning'])) {
        $output .= '<div class="alert alert-warning alert-dismissible fade show d-flex align-items-center mb-4" role="alert">'
            . '<i class="fa-solid fa-circle-exclamation me-2 fs-5"></i>'
            . '<div>' . e($_SESSION['flash_warning']) . '</div>'
            . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
            . '</div>';
        unset($_SESSION['flash_warning']);
    }
    return $output;
}

/**
 * Determine stock status label & badge class
 * Rules:
 * Red: Out of Stock (current_stock = 0)
 * Orange: Low Stock (current_stock <= reorder_level)
 * Green: Healthy Stock (current_stock > reorder_level && current_stock <= maximum_stock)
 * Blue: Overstock (current_stock > maximum_stock)
 */
function get_stock_status_info(int $current, int $reorder, int $maximum): array {
    if ($current <= 0) {
        return [
            'status' => 'Out of Stock',
            'badge'  => 'badge-danger',
            'color'  => '#ef4444',
            'bg'     => '#fef2f2',
            'class'  => 'danger',
            'icon'   => 'fa-circle-xmark'
        ];
    }
    if ($current <= $reorder) {
        return [
            'status' => 'Low Stock',
            'badge'  => 'badge-warning',
            'color'  => '#f59e0b',
            'bg'     => '#fffbeb',
            'class'  => 'warning',
            'icon'   => 'fa-triangle-exclamation'
        ];
    }
    if ($maximum > 0 && $current > $maximum) {
        return [
            'status' => 'Overstock',
            'badge'  => 'badge-info',
            'color'  => '#0284c7',
            'bg'     => '#f0f9ff',
            'class'  => 'info',
            'icon'   => 'fa-arrow-up-right-dots'
        ];
    }
    return [
        'status' => 'Healthy Stock',
        'badge'  => 'badge-success',
        'color'  => '#10b981',
        'bg'     => '#ecfdf5',
        'class'  => 'success',
        'icon'   => 'fa-circle-check'
    ];
}

/**
 * Fetch system alert counts for top navbar and widgets
 */
function get_system_alert_counts(PDO $db): array {
    try {
        $stmt = $db->query("
            SELECT 
                COUNT(*) as total_alerts,
                SUM(CASE WHEN current_stock = 0 THEN 1 ELSE 0 END) as out_of_stock,
                SUM(CASE WHEN current_stock > 0 AND current_stock <= reorder_level THEN 1 ELSE 0 END) as low_stock
            FROM items 
            WHERE status = 'Active' AND current_stock <= reorder_level
        ");
        $counts = $stmt->fetch();
        return [
            'total'        => (int)($counts['total_alerts'] ?? 0),
            'out_of_stock' => (int)($counts['out_of_stock'] ?? 0),
            'low_stock'    => (int)($counts['low_stock'] ?? 0),
        ];
    } catch (Exception $e) {
        return ['total' => 0, 'out_of_stock' => 0, 'low_stock' => 0];
    }
}

/**
 * Generate Next Transaction Code
 */
function generate_transaction_code(PDO $db, string $prefix = 'TXN'): string {
    $datePart = date('Ymd');
    $stmt = $db->prepare("SELECT COUNT(*) FROM stock_transactions WHERE transaction_date = CURDATE()");
    $stmt->execute();
    $todayCount = (int)$stmt->fetchColumn() + 1;
    return sprintf("%s-%s-%03d", $prefix, $datePart, $todayCount);
}

/**
 * Generate Next Item Code
 */
function generate_item_code(PDO $db): string {
    $stmt = $db->query("SELECT MAX(id) FROM items");
    $maxId = (int)$stmt->fetchColumn() + 1;
    return sprintf("ITM-%04d", $maxId);
}

/**
 * Generate Next Requisition Number
 */
function generate_requisition_no(PDO $db): string {
    $datePart = date('Ymd');
    $stmt = $db->query("SELECT COUNT(*) FROM requisitions WHERE date(created_at) = date('now')");
    $count = (int)$stmt->fetchColumn() + 1;
    return sprintf("REQ-%s-%03d", $datePart, $count);
}

/**
 * Generate Next Stock Audit Code
 */
function generate_audit_code(PDO $db): string {
    $datePart = date('Ym');
    $stmt = $db->query("SELECT COUNT(*) FROM stock_audits");
    $count = (int)$stmt->fetchColumn() + 1;
    return sprintf("AUD-%s-%03d", $datePart, $count);
}

/**
 * Get count of pending requisitions awaiting manager approval
 */
function get_pending_requisitions_count(PDO $db): int {
    try {
        $stmt = $db->query("SELECT COUNT(*) FROM requisitions WHERE status = 'Pending'");
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Export tabular dataset directly as downloadable CSV/Excel compatible file
 */
function export_to_csv(string $filename, array $headers, array $rows): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    // Output BOM for Excel UTF-8 compatibility
    fputs($output, "\xEF\xBB\xBF");
    fputcsv($output, $headers);
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

/**
 * Requisition Status Badge Helper
 */
function get_requisition_status_badge(string $status): string {
    switch ($status) {
        case 'Pending':
            return '<span class="badge bg-warning text-dark px-2.5 py-1.5"><i class="fa-solid fa-clock me-1"></i>Pending Approval</span>';
        case 'Approved':
            return '<span class="badge bg-info text-white px-2.5 py-1.5"><i class="fa-solid fa-check-double me-1"></i>Approved</span>';
        case 'Issued':
            return '<span class="badge bg-success text-white px-2.5 py-1.5"><i class="fa-solid fa-circle-check me-1"></i>Issued & Fulfilled</span>';
        case 'Rejected':
            return '<span class="badge bg-danger text-white px-2.5 py-1.5"><i class="fa-solid fa-ban me-1"></i>Rejected</span>';
        default:
            return '<span class="badge bg-secondary">' . htmlspecialchars($status) . '</span>';
    }
}

/**
 * Priority Badge Helper
 */
function get_priority_badge(string $priority): string {
    switch ($priority) {
        case 'Critical':
            return '<span class="badge bg-danger"><i class="fa-solid fa-fire me-1"></i>Critical</span>';
        case 'Urgent':
        case 'High':
            return '<span class="badge bg-warning text-dark"><i class="fa-solid fa-bolt me-1"></i>Urgent</span>';
        case 'Normal':
        default:
            return '<span class="badge bg-light text-dark border">Normal</span>';
    }
}

