<?php
/**
 * Smart Store Room Management System
 * Header Template
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = $page_title ?? 'Dashboard';
$base_url = get_base_url();
$db = Database::getConnection();
$alert_stats = get_system_alert_counts($db);
$pending_req_count = get_pending_requisitions_count($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($page_title) ?> | Smart Store Room Management System</title>
  
  <!-- Google Fonts: Inter -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Font Awesome 6 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <!-- Chart.js (CDN for Analytics) -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="<?= $base_url ?>/assets/css/style.css">
</head>
<body>
<div id="app-wrapper">
  <!-- Backdrop for mobile drawer -->
  <div id="sidebarBackdrop" class="sidebar-backdrop"></div>
