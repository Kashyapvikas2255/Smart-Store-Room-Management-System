<?php
/**
 * Smart Store Room Management System
 * Top Navbar Component
 */
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'Staff';
$total_alerts = $alert_stats['total'] ?? 0;
?>
<div id="content-wrapper">
  <header id="top-navbar">
  <div class="d-flex align-items-center gap-3">
    <button id="sidebarToggleBtn" class="navbar-btn-toggle" type="button" aria-label="Toggle Sidebar">
      <i class="fa-solid fa-bars"></i>
    </button>
    
    <div class="d-none d-md-flex align-items-center text-muted fs-6">
      <span class="fw-semibold text-dark me-2">Store Room:</span>
      <span class="badge bg-light text-dark border"><i class="fa-solid fa-building me-1 text-primary"></i> Main Inventory Depot</span>
    </div>
  </div>

  <div class="d-flex align-items-center gap-3">
    <!-- Requisitions Quick Link -->
    <a href="<?= $base_url ?>/requisitions/index.php" class="btn btn-outline-secondary position-relative rounded-circle p-2 d-none d-sm-flex align-items-center justify-content-center" style="width: 40px; height: 40px;" title="Material Requisitions & Approvals">
      <i class="fa-solid fa-file-signature text-secondary"></i>
      <?php if (!empty($pending_req_count)): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark border border-light">
          <?= $pending_req_count ?>
        </span>
      <?php endif; ?>
    </a>

    <!-- Notification Bell -->
    <div class="dropdown">
      <button class="btn btn-outline-secondary position-relative rounded-circle p-2" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="width: 40px; height: 40px;">
        <i class="fa-regular fa-bell text-secondary"></i>
        <?php if ($total_alerts > 0): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-light">
            <?= $total_alerts ?>
            <span class="visually-hidden">unread alerts</span>
          </span>
        <?php endif; ?>
      </button>
      <ul class="dropdown-menu dropdown-menu-end shadow-sm p-2" style="min-width: 280px;">
        <li class="dropdown-header fw-bold text-uppercase fs-xs text-muted">Stock Level Alerts</li>
        <?php if ($total_alerts === 0): ?>
          <li class="p-2 text-center text-muted fs-sm">
            <i class="fa-solid fa-check-circle text-success me-1"></i> All stock levels healthy
          </li>
        <?php else: ?>
          <li>
            <a class="dropdown-item d-flex justify-content-between align-items-center rounded py-2" href="<?= $base_url ?>/alerts/out-of-stock.php">
              <span><i class="fa-solid fa-circle-xmark text-danger me-2"></i> Out of Stock</span>
              <span class="badge bg-danger rounded-pill"><?= $alert_stats['out_of_stock'] ?></span>
            </a>
          </li>
          <li>
            <a class="dropdown-item d-flex justify-content-between align-items-center rounded py-2" href="<?= $base_url ?>/alerts/low-stock.php">
              <span><i class="fa-solid fa-triangle-exclamation text-warning me-2"></i> Low Stock Threshold</span>
              <span class="badge bg-warning text-dark rounded-pill"><?= $alert_stats['low_stock'] ?></span>
            </a>
          </li>
        <?php endif; ?>
        <li><hr class="dropdown-divider my-1"></li>
        <li><a class="dropdown-item text-center text-primary fs-sm py-1" href="<?= $base_url ?>/alerts/low-stock.php">View All Action Items</a></li>
      </ul>
    </div>

    <!-- User Profile Dropdown -->
    <div class="dropdown">
      <button class="btn btn-light border d-flex align-items-center gap-2 py-1 px-2 rounded-pill" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.85rem;">
          <?= strtoupper(substr($user_name, 0, 1)) ?>
        </div>
        <div class="d-none d-sm-block text-start pe-1">
          <div class="fw-semibold lh-1" style="font-size: 0.85rem;"><?= e($user_name) ?></div>
          <small class="text-muted" style="font-size: 0.72rem;"><?= e($user_role) ?></small>
        </div>
        <i class="fa-solid fa-chevron-down text-muted fs-xs ps-1"></i>
      </button>
      <ul class="dropdown-menu dropdown-menu-end shadow-sm p-2">
        <li class="px-3 py-2 border-bottom mb-1">
          <div class="fw-bold"><?= e($user_name) ?></div>
          <div class="text-muted fs-xs"><?= e($_SESSION['user_email'] ?? '') ?></div>
          <span class="badge bg-primary-subtle text-primary border border-primary-subtle mt-1"><?= e($user_role) ?></span>
        </li>
        <li>
          <a class="dropdown-item rounded py-2" href="<?= $base_url ?>/auth/change-password.php">
            <i class="fa-solid fa-key me-2 text-muted"></i> Change Password
          </a>
        </li>
        <li><hr class="dropdown-divider my-1"></li>
        <li>
          <a class="dropdown-item rounded py-2 text-danger" href="<?= $base_url ?>/auth/logout.php">
            <i class="fa-solid fa-arrow-right-from-bracket me-2"></i> Log Out
          </a>
        </li>
      </ul>
    </div>
  </div>
</header>
<main class="p-3 p-md-4 flex-grow-1">
  <?= render_flash() ?>
