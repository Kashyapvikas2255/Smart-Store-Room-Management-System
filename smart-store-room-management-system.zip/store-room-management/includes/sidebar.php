<?php
/**
 * Smart Store Room Management System
 * Sidebar Navigation Component
 */
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$user_role = $_SESSION['user_role'] ?? 'Store Staff';
?>
<aside id="sidebar">
  <a href="<?= $base_url ?>/dashboard/index.php" class="sidebar-brand">
    <i class="fa-solid fa-boxes-stacked"></i>
    <span>SMART STORE</span>
  </a>

  <div class="sidebar-nav">
    <div class="nav-section-title">Core</div>
    <a href="<?= $base_url ?>/dashboard/index.php" class="nav-link <?= ($current_dir === 'dashboard') ? 'active' : '' ?>">
      <i class="fa-solid fa-gauge-high"></i>
      <span>Dashboard</span>
    </a>

    <div class="nav-section-title">Inventory Catalog</div>
    <a href="<?= $base_url ?>/items/index.php" class="nav-link <?= ($current_dir === 'items') ? 'active' : '' ?>">
      <i class="fa-solid fa-dolly"></i>
      <span>Items / Inventory</span>
    </a>
    <a href="<?= $base_url ?>/categories/index.php" class="nav-link <?= ($current_dir === 'categories') ? 'active' : '' ?>">
      <i class="fa-solid fa-tags"></i>
      <span>Categories</span>
    </a>

    <div class="nav-section-title">Procurement & Partners</div>
    <a href="<?= $base_url ?>/suppliers/index.php" class="nav-link <?= ($current_dir === 'suppliers') ? 'active' : '' ?>">
      <i class="fa-solid fa-truck-field"></i>
      <span>Suppliers</span>
    </a>

    <div class="nav-section-title">People & Org</div>
    <a href="<?= $base_url ?>/employees/index.php" class="nav-link <?= ($current_dir === 'employees') ? 'active' : '' ?>">
      <i class="fa-solid fa-users"></i>
      <span>Employees</span>
    </a>
    <a href="<?= $base_url ?>/departments/index.php" class="nav-link <?= ($current_dir === 'departments') ? 'active' : '' ?>">
      <i class="fa-solid fa-sitemap"></i>
      <span>Departments</span>
    </a>

    <div class="nav-section-title">Requisitions & Approval</div>
    <a href="<?= $base_url ?>/requisitions/index.php" class="nav-link <?= ($current_dir === 'requisitions' && $current_page !== 'add.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-file-signature text-info"></i>
      <span>Requisitions</span>
      <?php if (!empty($pending_req_count)): ?>
        <span class="badge bg-warning text-dark ms-auto"><?= $pending_req_count ?> pending</span>
      <?php endif; ?>
    </a>
    <a href="<?= $base_url ?>/requisitions/add.php" class="nav-link <?= ($current_page === 'add.php' && $current_dir === 'requisitions') ? 'active' : '' ?>">
      <i class="fa-solid fa-plus-circle"></i>
      <span>New Material Request</span>
    </a>

    <div class="nav-section-title">Stock Movements & Audits</div>
    <a href="<?= $base_url ?>/stock/stock-in.php" class="nav-link <?= ($current_page === 'stock-in.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-arrow-down-to-bracket text-success"></i>
      <span>Stock In</span>
    </a>
    <a href="<?= $base_url ?>/stock/stock-out.php" class="nav-link <?= ($current_page === 'stock-out.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-arrow-up-from-bracket text-danger"></i>
      <span>Stock Out (Issue)</span>
    </a>
    <a href="<?= $base_url ?>/stock/returns.php" class="nav-link <?= ($current_page === 'returns.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-rotate-left text-info"></i>
      <span>Stock Returns</span>
    </a>
    <a href="<?= $base_url ?>/audit/index.php" class="nav-link <?= ($current_dir === 'audit') ? 'active' : '' ?>">
      <i class="fa-solid fa-clipboard-check text-primary"></i>
      <span>Physical Stock Audit</span>
    </a>
    <?php if (has_role(['Admin', 'Store Manager'])): ?>
    <a href="<?= $base_url ?>/stock/adjustment.php" class="nav-link <?= ($current_page === 'adjustment.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-sliders text-warning"></i>
      <span>Stock Adjustment</span>
    </a>
    <?php endif; ?>
    <a href="<?= $base_url ?>/stock/history.php" class="nav-link <?= ($current_page === 'history.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-clock-rotate-left"></i>
      <span>Transaction Ledger</span>
    </a>

    <div class="nav-section-title">Stock Alerts</div>
    <a href="<?= $base_url ?>/alerts/low-stock.php" class="nav-link <?= ($current_page === 'low-stock.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-triangle-exclamation text-warning"></i>
      <span>Low Stock</span>
      <?php if (!empty($alert_stats['low_stock'])): ?>
        <span class="badge bg-warning text-dark ms-auto"><?= $alert_stats['low_stock'] ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= $base_url ?>/alerts/out-of-stock.php" class="nav-link <?= ($current_page === 'out-of-stock.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-circle-xmark text-danger"></i>
      <span>Out of Stock</span>
      <?php if (!empty($alert_stats['out_of_stock'])): ?>
        <span class="badge bg-danger ms-auto"><?= $alert_stats['out_of_stock'] ?></span>
      <?php endif; ?>
    </a>

    <div class="nav-section-title">Reports & Export</div>
    <a href="<?= $base_url ?>/reports/stock-report.php" class="nav-link <?= ($current_page === 'stock-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-file-lines"></i>
      <span>Current Stock</span>
    </a>
    <a href="<?= $base_url ?>/reports/stock-in-report.php" class="nav-link <?= ($current_page === 'stock-in-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-file-import"></i>
      <span>Stock In Report</span>
    </a>
    <a href="<?= $base_url ?>/reports/stock-out-report.php" class="nav-link <?= ($current_page === 'stock-out-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-file-export"></i>
      <span>Stock Out Report</span>
    </a>
    <a href="<?= $base_url ?>/reports/return-report.php" class="nav-link <?= ($current_page === 'return-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-file-shield"></i>
      <span>Returns Report</span>
    </a>
    <a href="<?= $base_url ?>/reports/employee-report.php" class="nav-link <?= ($current_page === 'employee-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-id-card-clip"></i>
      <span>Employee Usage</span>
    </a>
    <a href="<?= $base_url ?>/reports/monthly-report.php" class="nav-link <?= ($current_page === 'monthly-report.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-chart-column"></i>
      <span>Monthly Movement</span>
    </a>

    <?php if (has_role(['Admin'])): ?>
    <div class="nav-section-title">Administration</div>
    <a href="<?= $base_url ?>/users/index.php" class="nav-link <?= ($current_dir === 'users') ? 'active' : '' ?>">
      <i class="fa-solid fa-user-shield"></i>
      <span>System Users</span>
    </a>
    <?php endif; ?>

    <div class="nav-section-title">My Account</div>
    <a href="<?= $base_url ?>/auth/change-password.php" class="nav-link <?= ($current_page === 'change-password.php') ? 'active' : '' ?>">
      <i class="fa-solid fa-key"></i>
      <span>Change Password</span>
    </a>
    <a href="<?= $base_url ?>/auth/logout.php" class="nav-link text-danger-emphasis">
      <i class="fa-solid fa-right-from-bracket text-danger"></i>
      <span>Sign Out</span>
    </a>
  </div>

  <div class="sidebar-footer">
    <div class="fw-semibold text-white"><?= e($_SESSION['user_name'] ?? 'User') ?></div>
    <div class="text-xs opacity-75"><?= e($user_role) ?></div>
  </div>
</aside>
