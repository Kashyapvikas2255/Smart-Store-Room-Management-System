<?php
/**
 * Smart Store Room Management System
 * Entry Router / Redirector
 */
require_once __DIR__ . '/config/auth.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard/index.php");
} else {
    header("Location: auth/login.php");
}
exit;
