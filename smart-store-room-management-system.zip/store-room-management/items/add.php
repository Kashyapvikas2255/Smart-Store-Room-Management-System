<?php
/**
 * Smart Store Room Management System
 * Add New Item Form
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Add New Item';
$db = Database::getConnection();
$error = '';

// Pre-generate candidate item code
$auto_code = generate_item_code($db);

// Fetch categories & suppliers for dropdowns
$categories = $db->query("SELECT id, category_name FROM categories WHERE status = 'Active' ORDER BY category_name ASC")->fetchAll();
$suppliers = $db->query("SELECT id, supplier_name FROM suppliers WHERE status = 'Active' ORDER BY supplier_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_code = trim($_POST['item_code'] ?? '');
    $item_name = trim($_POST['item_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
    $unit = trim($_POST['unit'] ?? 'Pieces');
    $description = trim($_POST['description'] ?? '');
    $minimum_stock = max(0, (int)($_POST['minimum_stock'] ?? 0));
    $reorder_level = max(0, (int)($_POST['reorder_level'] ?? 0));
    $maximum_stock = max(0, (int)($_POST['maximum_stock'] ?? 100));
    $current_stock = max(0, (int)($_POST['current_stock'] ?? 0));
    $purchase_price = max(0, (float)($_POST['purchase_price'] ?? 0));
    $selling_price = max(0, (float)($_POST['selling_or_issue_price'] ?? 0));
    $location = trim($_POST['location'] ?? 'Main Store Room');
    $rack_no = trim($_POST['rack_no'] ?? 'R-01');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Security token validation failed. Please try again.";
    } elseif (empty($item_code) || empty($item_name) || empty($category_id) || empty($unit)) {
        $error = "Item code, item name, category, and unit are required fields.";
    } elseif ($reorder_level < $minimum_stock) {
        $error = "Reorder level should ideally be greater than or equal to minimum stock.";
    } else {
        try {
            // Check uniqueness of item code
            $chk = $db->prepare("SELECT COUNT(*) FROM items WHERE item_code = :code");
            $chk->execute([':code' => $item_code]);
            if ($chk->fetchColumn() > 0) {
                $error = "Item code '{$item_code}' already exists. Please use a unique code.";
            } else {
                $db->beginTransaction();

                $sql = "INSERT INTO items (
                    item_code, item_name, category_id, supplier_id, unit, description,
                    minimum_stock, reorder_level, maximum_stock, current_stock,
                    purchase_price, selling_or_issue_price, location, rack_no, status
                ) VALUES (
                    :item_code, :item_name, :category_id, :supplier_id, :unit, :description,
                    :minimum_stock, :reorder_level, :maximum_stock, :current_stock,
                    :purchase_price, :selling_price, :location, :rack_no, :status
                )";
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    ':item_code' => $item_code,
                    ':item_name' => $item_name,
                    ':category_id' => $category_id,
                    ':supplier_id' => $supplier_id,
                    ':unit' => $unit,
                    ':description' => $description,
                    ':minimum_stock' => $minimum_stock,
                    ':reorder_level' => $reorder_level,
                    ':maximum_stock' => $maximum_stock,
                    ':current_stock' => $current_stock,
                    ':purchase_price' => $purchase_price,
                    ':selling_price' => $selling_price,
                    ':location' => $location,
                    ':rack_no' => $rack_no,
                    ':status' => $status
                ]);
                $new_item_id = $db->lastInsertId();

                // If initial current stock > 0, record initial stock-in transaction
                if ($current_stock > 0) {
                    $txn_code = generate_transaction_code($db, 'TXN');
                    $txn_stmt = $db->prepare("
                        INSERT INTO stock_transactions (
                            transaction_code, item_id, transaction_type, quantity,
                            previous_stock, new_stock, supplier_id, unit_price,
                            reference_no, remarks, transaction_date, created_by
                        ) VALUES (
                            :txn_code, :item_id, 'IN', :quantity,
                            0, :new_stock, :supplier_id, :unit_price,
                            'INIT-SETUP', 'Initial inventory intake at item creation', CURDATE(), :created_by
                        )
                    ");
                    $txn_stmt->execute([
                        ':txn_code' => $txn_code,
                        ':item_id' => $new_item_id,
                        ':quantity' => $current_stock,
                        ':new_stock' => $current_stock,
                        ':supplier_id' => $supplier_id,
                        ':unit_price' => $purchase_price,
                        ':created_by' => $_SESSION['user_id']
                    ]);
                }

                $db->commit();
                set_flash('success', "Item '{$item_name}' added successfully.");
                header("Location: index.php");
                exit;
            }
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error = "Failed to save item: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Add New Inventory Item</h3>
    <p class="text-muted mb-0 small">Create a new item profile with storage location and threshold parameters.</p>
  </div>
  <a href="index.php" class="btn btn-outline-secondary">
    <i class="fa-solid fa-arrow-left me-1"></i> Back to Items
  </a>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<form method="POST" action="add.php" class="card border-0 shadow-sm rounded-3">
  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

  <div class="card-body p-4">
    <div class="row g-3">
      <!-- Section 1: Basic Identifiers -->
      <div class="col-12 border-bottom pb-2">
        <h6 class="fw-bold text-primary mb-0"><i class="fa-solid fa-tag me-2"></i>General Information</h6>
      </div>

      <div class="col-md-4">
        <label for="item_code" class="form-label">Item Code <span class="text-danger">*</span></label>
        <input type="text" class="form-control font-monospace" id="item_code" name="item_code" value="<?= e($_POST['item_code'] ?? $auto_code) ?>" required>
        <div class="form-text">Unique alphanumeric identifier (e.g. ITM-0021).</div>
      </div>

      <div class="col-md-8">
        <label for="item_name" class="form-label">Item Name <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="item_name" name="item_name" placeholder="e.g. Cat6 High Performance Ethernet Cable (5M)" value="<?= e($_POST['item_name'] ?? '') ?>" required>
      </div>

      <div class="col-md-4">
        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
        <select class="form-select" id="category_id" name="category_id" required>
          <option value="">-- Select Category --</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= (($_POST['category_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>>
              <?= e($cat['category_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="supplier_id" class="form-label">Default Supplier</label>
        <select class="form-select" id="supplier_id" name="supplier_id">
          <option value="">-- None / Multiple --</option>
          <?php foreach ($suppliers as $sup): ?>
            <option value="<?= $sup['id'] ?>" <?= (($_POST['supplier_id'] ?? '') == $sup['id']) ? 'selected' : '' ?>>
              <?= e($sup['supplier_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="unit" class="form-label">Unit of Measurement <span class="text-danger">*</span></label>
        <select class="form-select" id="unit" name="unit" required>
          <option value="Pieces">Pieces</option>
          <option value="Boxes">Boxes</option>
          <option value="Packs">Packs</option>
          <option value="Sets">Sets</option>
          <option value="Pairs">Pairs</option>
          <option value="Rolls">Rolls</option>
          <option value="Meters">Meters</option>
          <option value="Liters">Liters</option>
          <option value="Jugs">Jugs</option>
        </select>
      </div>

      <div class="col-12">
        <label for="description" class="form-label">Description / Specifications</label>
        <textarea class="form-control" id="description" name="description" rows="2" placeholder="Brief technical specs, usage context, or packaging details..."><?= e($_POST['description'] ?? '') ?></textarea>
      </div>

      <!-- Section 2: Stock Levels & Thresholds -->
      <div class="col-12 border-bottom pt-3 pb-2">
        <h6 class="fw-bold text-primary mb-0"><i class="fa-solid fa-layer-group me-2"></i>Stock Quantities & Thresholds</h6>
      </div>

      <div class="col-md-3">
        <label for="current_stock" class="form-label">Initial Stock on Hand</label>
        <input type="number" class="form-control" id="current_stock" name="current_stock" min="0" value="<?= e($_POST['current_stock'] ?? '0') ?>">
        <div class="form-text">Will generate initial intake log if > 0.</div>
      </div>

      <div class="col-md-3">
        <label for="minimum_stock" class="form-label">Minimum Stock</label>
        <input type="number" class="form-control" id="minimum_stock" name="minimum_stock" min="0" value="<?= e($_POST['minimum_stock'] ?? '5') ?>">
        <div class="form-text">Critical emergency baseline.</div>
      </div>

      <div class="col-md-3">
        <label for="reorder_level" class="form-label">Reorder Level <span class="text-danger">*</span></label>
        <input type="number" class="form-control" id="reorder_level" name="reorder_level" min="0" value="<?= e($_POST['reorder_level'] ?? '10') ?>" required>
        <div class="form-text">Triggers low stock alert.</div>
      </div>

      <div class="col-md-3">
        <label for="maximum_stock" class="form-label">Maximum Stock Capacity</label>
        <input type="number" class="form-control" id="maximum_stock" name="maximum_stock" min="1" value="<?= e($_POST['maximum_stock'] ?? '100') ?>">
        <div class="form-text">Prevents overstocking shelves.</div>
      </div>

      <!-- Section 3: Financials & Physical Placement -->
      <div class="col-12 border-bottom pt-3 pb-2">
        <h6 class="fw-bold text-primary mb-0"><i class="fa-solid fa-location-dot me-2"></i>Pricing & Location</h6>
      </div>

      <div class="col-md-3">
        <label for="purchase_price" class="form-label">Purchase Price ($)</label>
        <input type="number" step="0.01" min="0" class="form-control" id="purchase_price" name="purchase_price" value="<?= e($_POST['purchase_price'] ?? '0.00') ?>">
      </div>

      <div class="col-md-3">
        <label for="selling_or_issue_price" class="form-label">Issue Price ($)</label>
        <input type="number" step="0.01" min="0" class="form-control" id="selling_or_issue_price" name="selling_or_issue_price" value="<?= e($_POST['selling_or_issue_price'] ?? '0.00') ?>">
      </div>

      <div class="col-md-3">
        <label for="location" class="form-label">Store Location / Bay</label>
        <input type="text" class="form-control" id="location" name="location" value="<?= e($_POST['location'] ?? 'Main Store Room') ?>">
      </div>

      <div class="col-md-3">
        <label for="rack_no" class="form-label">Rack / Shelf No</label>
        <input type="text" class="form-control" id="rack_no" name="rack_no" value="<?= e($_POST['rack_no'] ?? 'R-01') ?>">
      </div>

      <div class="col-md-3">
        <label for="status" class="form-label">Status</label>
        <select class="form-select" id="status" name="status">
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>
    </div>
  </div>

  <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
    <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
    <button type="submit" class="btn btn-primary-deep px-4">
      <i class="fa-solid fa-floppy-disk me-2"></i> Save Inventory Item
    </button>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
