<?php
/**
 * Smart Store Room Management System
 * Delete Item Handler
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid item requested for deletion.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

try {
    // Check if transactions exist
    $chk_txn = $db->prepare("SELECT COUNT(*) FROM stock_transactions WHERE item_id = :id");
    $chk_txn->execute([':id' => $id]);
    $txn_count = (int)$chk_txn->fetchColumn();

    if ($txn_count > 0) {
        set_flash('error', "Cannot delete this item because it is referenced by {$txn_count} stock transactions. Consider marking its status as 'Inactive' to preserve audit history.");
        header("Location: index.php");
        exit;
    }

    $chk_adj = $db->prepare("SELECT COUNT(*) FROM stock_adjustments WHERE item_id = :id");
    $chk_adj->execute([':id' => $id]);
    $adj_count = (int)$chk_adj->fetchColumn();

    if ($adj_count > 0) {
        set_flash('error', "Cannot delete this item because it has historical stock adjustments recorded.");
        header("Location: index.php");
        exit;
    }

    $del = $db->prepare("DELETE FROM items WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', "Item removed successfully.");
} catch (Exception $e) {
    set_flash('error', "Database error during deletion: " . $e->getMessage());
}

header("Location: index.php");
exit;
