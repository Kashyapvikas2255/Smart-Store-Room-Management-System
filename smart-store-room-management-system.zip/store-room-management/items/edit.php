<?php
/**
 * Smart Store Room Management System
 * Edit Existing Item
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Edit Item';
$db = Database::getConnection();
$error = '';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid item identifier.");
    header("Location: index.php");
    exit;
}

$stmt = $db->prepare("SELECT * FROM items WHERE id = :id");
$stmt->execute([':id' => $id]);
$item = $stmt->fetch();

if (!$item) {
    set_flash('error', "Item not found in repository.");
    header("Location: index.php");
    exit;
}

// Fetch categories & suppliers
$categories = $db->query("SELECT id, category_name FROM categories WHERE status = 'Active' ORDER BY category_name ASC")->fetchAll();
$suppliers = $db->query("SELECT id, supplier_name FROM suppliers WHERE status = 'Active' ORDER BY supplier_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = trim($_POST['item_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
    $unit = trim($_POST['unit'] ?? 'Pieces');
    $description = trim($_POST['description'] ?? '');
    $minimum_stock = max(0, (int)($_POST['minimum_stock'] ?? 0));
    $reorder_level = max(0, (int)($_POST['reorder_level'] ?? 0));
    $maximum_stock = max(0, (int)($_POST['maximum_stock'] ?? 100));
    $purchase_price = max(0, (float)($_POST['purchase_price'] ?? 0));
    $selling_price = max(0, (float)($_POST['selling_or_issue_price'] ?? 0));
    $location = trim($_POST['location'] ?? '');
    $rack_no = trim($_POST['rack_no'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Security token mismatch. Please try again.";
    } elseif (empty($item_name) || empty($category_id) || empty($unit)) {
        $error = "Item name, category, and unit are required fields.";
    } else {
        try {
            $update_sql = "UPDATE items SET
                item_name = :item_name,
                category_id = :category_id,
                supplier_id = :supplier_id,
                unit = :unit,
                description = :description,
                minimum_stock = :minimum_stock,
                reorder_level = :reorder_level,
                maximum_stock = :maximum_stock,
                purchase_price = :purchase_price,
                selling_or_issue_price = :selling_price,
                location = :location,
                rack_no = :rack_no,
                status = :status
                WHERE id = :id";
            $update_stmt = $db->prepare($update_sql);
            $update_stmt->execute([
                ':item_name' => $item_name,
                ':category_id' => $category_id,
                ':supplier_id' => $supplier_id,
                ':unit' => $unit,
                ':description' => $description,
                ':minimum_stock' => $minimum_stock,
                ':reorder_level' => $reorder_level,
                ':maximum_stock' => $maximum_stock,
                ':purchase_price' => $purchase_price,
                ':selling_price' => $selling_price,
                ':location' => $location,
                ':rack_no' => $rack_no,
                ':status' => $status,
                ':id' => $id
            ]);

            set_flash('success', "Item '{$item_name}' updated successfully.");
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            $error = "Failed to update item: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Edit Item: <?= e($item['item_name']) ?></h3>
    <p class="text-muted mb-0 small">SKU: <span class="font-monospace fw-bold text-primary"><?= e($item['item_code']) ?></span> &bull; Current Stock: <?= $item['current_stock'] ?> <?= e($item['unit']) ?></p>
  </div>
  <a href="index.php" class="btn btn-outline-secondary">
    <i class="fa-solid fa-arrow-left me-1"></i> Back to Items
  </a>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<form method="POST" action="edit.php?id=<?= $id ?>" class="card border-0 shadow-sm rounded-3">
  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

  <div class="card-body p-4">
    <div class="row g-3">
      <div class="col-md-4">
        <label class="form-label text-muted">Item Code (Permanent)</label>
        <input type="text" class="form-control font-monospace bg-light" value="<?= e($item['item_code']) ?>" readonly>
      </div>

      <div class="col-md-8">
        <label for="item_name" class="form-label">Item Name <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="item_name" name="item_name" value="<?= e($item['item_name']) ?>" required>
      </div>

      <div class="col-md-4">
        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
        <select class="form-select" id="category_id" name="category_id" required>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= ($item['category_id'] == $cat['id']) ? 'selected' : '' ?>>
              <?= e($cat['category_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="supplier_id" class="form-label">Supplier</label>
        <select class="form-select" id="supplier_id" name="supplier_id">
          <option value="">-- None / Multiple --</option>
          <?php foreach ($suppliers as $sup): ?>
            <option value="<?= $sup['id'] ?>" <?= ($item['supplier_id'] == $sup['id']) ? 'selected' : '' ?>>
              <?= e($sup['supplier_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="unit" class="form-label">Unit of Measurement <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="unit" name="unit" value="<?= e($item['unit']) ?>" required>
      </div>

      <div class="col-12">
        <label for="description" class="form-label">Description / Specifications</label>
        <textarea class="form-control" id="description" name="description" rows="2"><?= e($item['description']) ?></textarea>
      </div>

      <div class="col-md-4">
        <label for="minimum_stock" class="form-label">Minimum Stock</label>
        <input type="number" class="form-control" id="minimum_stock" name="minimum_stock" min="0" value="<?= $item['minimum_stock'] ?>">
      </div>

      <div class="col-md-4">
        <label for="reorder_level" class="form-label">Reorder Level <span class="text-danger">*</span></label>
        <input type="number" class="form-control" id="reorder_level" name="reorder_level" min="0" value="<?= $item['reorder_level'] ?>" required>
      </div>

      <div class="col-md-4">
        <label for="maximum_stock" class="form-label">Maximum Stock</label>
        <input type="number" class="form-control" id="maximum_stock" name="maximum_stock" min="1" value="<?= $item['maximum_stock'] ?>">
      </div>

      <div class="col-md-3">
        <label for="purchase_price" class="form-label">Purchase Price ($)</label>
        <input type="number" step="0.01" min="0" class="form-control" id="purchase_price" name="purchase_price" value="<?= $item['purchase_price'] ?>">
      </div>

      <div class="col-md-3">
        <label for="selling_or_issue_price" class="form-label">Issue Price ($)</label>
        <input type="number" step="0.01" min="0" class="form-control" id="selling_or_issue_price" name="selling_or_issue_price" value="<?= $item['selling_or_issue_price'] ?>">
      </div>

      <div class="col-md-3">
        <label for="location" class="form-label">Location</label>
        <input type="text" class="form-control" id="location" name="location" value="<?= e($item['location']) ?>">
      </div>

      <div class="col-md-3">
        <label for="rack_no" class="form-label">Rack No</label>
        <input type="text" class="form-control" id="rack_no" name="rack_no" value="<?= e($item['rack_no']) ?>">
      </div>

      <div class="col-md-3">
        <label for="status" class="form-label">Status</label>
        <select class="form-select" id="status" name="status">
          <option value="Active" <?= ($item['status'] === 'Active') ? 'selected' : '' ?>>Active</option>
          <option value="Inactive" <?= ($item['status'] === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
        </select>
      </div>
    </div>
  </div>

  <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
    <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
    <button type="submit" class="btn btn-primary-deep px-4">
      <i class="fa-solid fa-check me-2"></i> Update Item
    </button>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
