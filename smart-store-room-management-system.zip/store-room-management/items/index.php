<?php
/**
 * Smart Store Room Management System
 * Item / Inventory Catalog Listing
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Inventory Items';
$db = Database::getConnection();

// Filters & Search
$search = trim($_GET['search'] ?? '');
$category_id = trim($_GET['category_id'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$stock_level = trim($_GET['stock_level'] ?? '');

// Pagination setup
$limit = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// Build query
$where_clauses = ["1=1"];
$params = [];

if ($search !== '') {
    $where_clauses[] = "(i.item_code LIKE :search OR i.item_name LIKE :search OR i.location LIKE :search OR i.rack_no LIKE :search)";
    $params[':search'] = "%{$search}%";
}

if ($category_id !== '') {
    $where_clauses[] = "i.category_id = :cat_id";
    $params[':cat_id'] = $category_id;
}

if ($status_filter !== '') {
    $where_clauses[] = "i.status = :status";
    $params[':status'] = $status_filter;
}

if ($stock_level === 'out') {
    $where_clauses[] = "i.current_stock = 0";
} elseif ($stock_level === 'low') {
    $where_clauses[] = "i.current_stock > 0 AND i.current_stock <= i.reorder_level";
} elseif ($stock_level === 'healthy') {
    $where_clauses[] = "i.current_stock > i.reorder_level AND i.current_stock <= i.maximum_stock";
} elseif ($stock_level === 'overstock') {
    $where_clauses[] = "i.current_stock > i.maximum_stock";
}

$where_sql = implode(' AND ', $where_clauses);

// Count total records
$count_stmt = $db->prepare("SELECT COUNT(*) FROM items i WHERE {$where_sql}");
$count_stmt->execute($params);
$total_records = (int)$count_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Fetch items
$sql = "
    SELECT 
        i.*,
        c.category_name,
        s.supplier_name
    FROM items i
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    WHERE {$where_sql}
    ORDER BY i.id DESC
    LIMIT {$limit} OFFSET {$offset}
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

// Fetch categories for filter dropdown
$categories = $db->query("SELECT id, category_name FROM categories WHERE status = 'Active' ORDER BY category_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Inventory Items</h3>
    <p class="text-muted mb-0 small">Manage and track all store room items, locations, stock thresholds, and prices.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="add.php" class="btn btn-primary-deep d-inline-flex align-items-center gap-2">
      <i class="fa-solid fa-plus"></i> Add New Item
    </a>
  </div>
</div>

<!-- Filter Bar -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="index.php" class="row g-2 align-items-center">
      <div class="col-md-4">
        <div class="input-group">
          <span class="input-group-text bg-white text-muted border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" name="search" class="form-control border-start-0" placeholder="Search by name, code, rack, or location..." value="<?= e($search) ?>">
        </div>
      </div>
      <div class="col-md-3">
        <select name="category_id" class="form-select">
          <option value="">-- All Categories --</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= $category_id == $cat['id'] ? 'selected' : '' ?>>
              <?= e($cat['category_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select name="stock_level" class="form-select">
          <option value="">-- All Stock Statuses --</option>
          <option value="out" <?= $stock_level === 'out' ? 'selected' : '' ?>>Out of Stock (0)</option>
          <option value="low" <?= $stock_level === 'low' ? 'selected' : '' ?>>Low Stock (&le; Reorder)</option>
          <option value="healthy" <?= $stock_level === 'healthy' ? 'selected' : '' ?>>Healthy Stock</option>
          <option value="overstock" <?= $stock_level === 'overstock' ? 'selected' : '' ?>>Overstock</option>
        </select>
      </div>
      <div class="col-md-2 d-flex gap-2">
        <button type="submit" class="btn btn-primary-deep flex-grow-1">Filter</button>
        <?php if ($search !== '' || $category_id !== '' || $stock_level !== '' || $status_filter !== ''): ?>
          <a href="index.php" class="btn btn-outline-secondary" title="Clear Filters"><i class="fa-solid fa-xmark"></i></a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<!-- Table Card -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle">
      <thead>
        <tr>
          <th>Item Code</th>
          <th>Item Name</th>
          <th>Category</th>
          <th>Location / Rack</th>
          <th>Current Stock</th>
          <th>Reorder Level</th>
          <th>Stock Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($items)): ?>
          <tr>
            <td colspan="8" class="text-center py-5 text-muted">
              <i class="fa-solid fa-box-open fs-2 mb-2 d-block text-secondary"></i>
              No inventory items found matching the selected criteria.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($items as $item): ?>
            <?php 
              $status_info = get_stock_status_info($item['current_stock'], $item['reorder_level'], $item['maximum_stock']); 
            ?>
            <tr>
              <td>
                <span class="font-monospace fw-bold text-dark"><?= e($item['item_code']) ?></span>
              </td>
              <td>
                <div class="fw-semibold text-dark">
                  <a href="view.php?id=<?= $item['id'] ?>" class="text-decoration-none text-dark hover-primary">
                    <?= e($item['item_name']) ?>
                  </a>
                </div>
                <small class="text-muted"><?= e($item['unit']) ?> &bull; <?= format_currency($item['purchase_price']) ?></small>
              </td>
              <td>
                <span class="badge bg-light text-dark border"><?= e($item['category_name']) ?></span>
              </td>
              <td>
                <div class="small fw-medium text-dark"><?= e($item['location']) ?></div>
                <small class="text-muted"><i class="fa-solid fa-table-cells me-1"></i>Rack: <?= e($item['rack_no']) ?></small>
              </td>
              <td>
                <span class="fw-bold fs-6 <?= $item['current_stock'] == 0 ? 'text-danger' : ($item['current_stock'] <= $item['reorder_level'] ? 'text-warning-emphasis' : 'text-dark') ?>">
                  <?= $item['current_stock'] ?>
                </span>
                <span class="text-muted small"><?= e($item['unit']) ?></span>
              </td>
              <td>
                <span class="text-muted small"><?= $item['reorder_level'] ?> <?= e($item['unit']) ?></span>
              </td>
              <td>
                <span class="badge-status <?= $status_info['badge'] ?>">
                  <i class="fa-solid <?= $status_info['icon'] ?>"></i>
                  <?= $status_info['status'] ?>
                </span>
              </td>
              <td class="text-end">
                <div class="btn-group btn-group-sm">
                  <a href="view.php?id=<?= $item['id'] ?>" class="btn btn-outline-secondary" title="View Details">
                    <i class="fa-regular fa-eye"></i>
                  </a>
                  <?php if (has_role(['Admin', 'Store Manager'])): ?>
                    <a href="edit.php?id=<?= $item['id'] ?>" class="btn btn-outline-primary" title="Edit Item">
                      <i class="fa-regular fa-pen-to-square"></i>
                    </a>
                  <?php endif; ?>
                  <?php if (has_role(['Admin'])): ?>
                    <a href="delete.php?id=<?= $item['id'] ?>" class="btn btn-outline-danger" title="Delete Item" onclick="return confirm('Are you sure you want to delete this item?');">
                      <i class="fa-regular fa-trash-can"></i>
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($total_pages > 1): ?>
    <div class="card-footer bg-white py-3 d-flex justify-content-between align-items-center">
      <div class="text-muted small">
        Showing <?= min($offset + 1, $total_records) ?> to <?= min($offset + $limit, $total_records) ?> of <?= $total_records ?> items
      </div>
      <nav>
        <ul class="pagination pagination-sm mb-0">
          <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Previous</a>
          </li>
          <?php for ($p = 1; $p <= $total_pages; $p++): ?>
            <li class="page-item <?= ($p === $page) ? 'active' : '' ?>">
              <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>"><?= $p ?></a>
            </li>
          <?php endfor; ?>
          <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next</a>
          </li>
        </ul>
      </nav>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
