<?php
/**
 * Smart Store Room Management System
 * Item Detailed Profile & Transaction Ledger
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid item requested.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

// Fetch item with relations
$stmt = $db->prepare("
    SELECT 
        i.*,
        c.category_name,
        s.supplier_name,
        s.contact_person,
        s.phone as supplier_phone,
        s.email as supplier_email
    FROM items i
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    WHERE i.id = :id
");
$stmt->execute([':id' => $id]);
$item = $stmt->fetch();

if (!$item) {
    set_flash('error', "Item record not found.");
    header("Location: index.php");
    exit;
}

$page_title = 'Item: ' . $item['item_name'];
$status_info = get_stock_status_info($item['current_stock'], $item['reorder_level'], $item['maximum_stock']);

// Calculate stock percentage against maximum stock
$stock_percentage = ($item['maximum_stock'] > 0) 
    ? min(100, round(($item['current_stock'] / $item['maximum_stock']) * 100)) 
    : 0;

// Fetch transaction history for this item
$stmt_txn = $db->prepare("
    SELECT 
        st.*,
        s.supplier_name,
        e.employee_name,
        d.department_name,
        u.name as creator_name
    FROM stock_transactions st
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    JOIN users u ON st.created_by = u.id
    WHERE st.item_id = :item_id
    ORDER BY st.created_at DESC
    LIMIT 25
");
$stmt_txn->execute([':item_id' => $id]);
$item_transactions = $stmt_txn->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <div class="d-flex align-items-center gap-2 mb-1">
      <span class="badge bg-primary font-monospace fs-6 px-3 py-1"><?= e($item['item_code']) ?></span>
      <span class="badge-status <?= $status_info['badge'] ?> fs-6">
        <i class="fa-solid <?= $status_info['icon'] ?>"></i> <?= $status_info['status'] ?>
      </span>
    </div>
    <h3 class="fw-bold mb-0 text-dark"><?= e($item['item_name']) ?></h3>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <a href="../stock/stock-in.php?item_id=<?= $item['id'] ?>" class="btn btn-success">
      <i class="fa-solid fa-arrow-down-to-bracket me-1"></i> Stock In
    </a>
    <a href="../stock/stock-out.php?item_id=<?= $item['id'] ?>" class="btn btn-danger">
      <i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Stock Out
    </a>
    <?php if (has_role(['Admin', 'Store Manager'])): ?>
      <a href="../stock/adjustment.php?item_id=<?= $item['id'] ?>" class="btn btn-warning text-dark">
        <i class="fa-solid fa-sliders me-1"></i> Adjust Stock
      </a>
      <a href="edit.php?id=<?= $item['id'] ?>" class="btn btn-outline-primary">
        <i class="fa-solid fa-pen me-1"></i> Edit
      </a>
    <?php endif; ?>
    <a href="index.php" class="btn btn-outline-secondary">Back</a>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- Stock Level Card with Visual Progress -->
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3 border-bottom">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-gauge text-primary me-2"></i> Real-time Stock Gauge
        </h6>
      </div>
      <div class="card-body p-4">
        <div class="text-center my-3">
          <div class="display-3 fw-bold <?= $item['current_stock'] == 0 ? 'text-danger' : ($item['current_stock'] <= $item['reorder_level'] ? 'text-warning' : 'text-success') ?>">
            <?= $item['current_stock'] ?>
          </div>
          <div class="text-muted text-uppercase fw-semibold tracking-wide fs-xs"><?= e($item['unit']) ?> currently in stock</div>
        </div>

        <!-- Visual Stock Progress Bar -->
        <div class="mb-4">
          <div class="d-flex justify-content-between small text-muted mb-1">
            <span>Utilization vs Capacity</span>
            <span class="fw-bold"><?= $stock_percentage ?>% (<?= $item['current_stock'] ?> / <?= $item['maximum_stock'] ?>)</span>
          </div>
          <div class="progress" style="height: 12px; border-radius: 6px;">
            <?php
              $bar_class = 'bg-success';
              if ($item['current_stock'] <= 0) $bar_class = 'bg-danger';
              elseif ($item['current_stock'] <= $item['reorder_level']) $bar_class = 'bg-warning';
              elseif ($item['current_stock'] > $item['maximum_stock']) $bar_class = 'bg-info';
            ?>
            <div class="progress-bar <?= $bar_class ?>" role="progressbar" style="width: <?= $stock_percentage ?>%;" aria-valuenow="<?= $stock_percentage ?>" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="row g-2 text-center pt-2 border-top">
          <div class="col-4 border-end">
            <small class="text-muted d-block">Min Baseline</small>
            <strong class="text-dark fs-6"><?= $item['minimum_stock'] ?></strong>
          </div>
          <div class="col-4 border-end">
            <small class="text-muted d-block">Reorder Point</small>
            <strong class="text-warning-emphasis fs-6"><?= $item['reorder_level'] ?></strong>
          </div>
          <div class="col-4">
            <small class="text-muted d-block">Max Capacity</small>
            <strong class="text-primary fs-6"><?= $item['maximum_stock'] ?></strong>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Specifications and Storage Specs -->
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm rounded-3 h-100">
      <div class="card-header bg-white py-3 border-bottom">
        <h6 class="card-title fw-bold mb-0 text-dark">
          <i class="fa-solid fa-circle-info text-primary me-2"></i> Item Specifications & Placement
        </h6>
      </div>
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-sm-6">
            <div class="small text-muted">Category</div>
            <div class="fw-semibold text-dark fs-6"><?= e($item['category_name']) ?></div>
          </div>
          <div class="col-sm-6">
            <div class="small text-muted">Unit of Measurement</div>
            <div class="fw-semibold text-dark fs-6"><?= e($item['unit']) ?></div>
          </div>
          <div class="col-sm-6">
            <div class="small text-muted">Store Location / Bay</div>
            <div class="fw-semibold text-dark fs-6"><i class="fa-solid fa-map-pin text-danger me-1"></i><?= e($item['location']) ?></div>
          </div>
          <div class="col-sm-6">
            <div class="small text-muted">Rack / Bin Position</div>
            <div class="fw-semibold text-dark fs-6"><i class="fa-solid fa-table-cells text-primary me-1"></i>Rack <?= e($item['rack_no']) ?></div>
          </div>
          <div class="col-sm-6">
            <div class="small text-muted">Purchase Cost</div>
            <div class="fw-semibold text-dark fs-6"><?= format_currency($item['purchase_price']) ?></div>
          </div>
          <div class="col-sm-6">
            <div class="small text-muted">Issue / Valuation Price</div>
            <div class="fw-semibold text-dark fs-6"><?= format_currency($item['selling_or_issue_price']) ?></div>
          </div>
          <div class="col-sm-12">
            <div class="small text-muted">Default Supplier</div>
            <div class="fw-semibold text-dark">
              <?= e($item['supplier_name'] ?? 'Not specified') ?>
              <?php if (!empty($item['supplier_phone'])): ?>
                <span class="text-muted small ms-2">(<?= e($item['supplier_phone']) ?>)</span>
              <?php endif; ?>
            </div>
          </div>
          <?php if (!empty($item['description'])): ?>
            <div class="col-12 pt-2 border-top">
              <div class="small text-muted mb-1">Item Description / Technical Notes</div>
              <p class="text-dark small mb-0"><?= nl2br(e($item['description'])) ?></p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Item Transaction Ledger -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
    <h6 class="card-title fw-bold mb-0 text-dark">
      <i class="fa-solid fa-list-check text-primary me-2"></i> Movement Ledger (Latest 25 Activity Records)
    </h6>
    <span class="badge bg-light text-dark border"><?= count($item_transactions) ?> Recorded</span>
  </div>
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Txn Code</th>
          <th>Type</th>
          <th>Qty</th>
          <th>Stock Balance</th>
          <th>Recipient / Supplier</th>
          <th>Reference</th>
          <th>User</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($item_transactions)): ?>
          <tr><td colspan="8" class="text-center py-4 text-muted">No stock movements recorded for this item yet.</td></tr>
        <?php else: ?>
          <?php foreach ($item_transactions as $txn): ?>
            <tr>
              <td class="font-monospace fw-bold text-dark"><?= e($txn['transaction_code']) ?></td>
              <td>
                <span class="badge <?= ($txn['transaction_type'] === 'IN') ? 'bg-success' : (($txn['transaction_type'] === 'OUT') ? 'bg-danger' : (($txn['transaction_type'] === 'RETURN') ? 'bg-info' : 'bg-warning text-dark')) ?>">
                  <?= e($txn['transaction_type']) ?>
                </span>
              </td>
              <td class="fw-bold <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? 'text-success' : 'text-danger' ?>">
                <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? '+' : '-' ?><?= $txn['quantity'] ?>
              </td>
              <td>
                <span class="text-muted"><?= $txn['previous_stock'] ?></span> &rarr; <strong class="text-dark"><?= $txn['new_stock'] ?></strong>
              </td>
              <td>
                <?php if ($txn['transaction_type'] === 'IN'): ?>
                  <?= e($txn['supplier_name'] ?? 'Direct Supplier') ?>
                <?php else: ?>
                  <?= e($txn['employee_name'] ?? 'Internal Store') ?>
                  <?php if ($txn['department_name']): ?>
                    <small class="text-muted d-block"><?= e($txn['department_name']) ?></small>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
              <td class="font-monospace small text-muted"><?= e($txn['reference_no'] ?? '-') ?></td>
              <td class="small text-muted"><?= e($txn['creator_name']) ?></td>
              <td class="small text-muted"><?= format_date($txn['transaction_date']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
