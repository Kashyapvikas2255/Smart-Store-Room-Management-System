<?php
/**
 * Smart Store Room Management System
 * Department Consumption & Usage Analytics
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Department Usage Report';
$db = Database::getConnection();

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$dept_id = trim($_GET['department_id'] ?? '');

$where_clauses = ["st.transaction_type = 'OUT'"];
$params = [];

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

if ($dept_id !== '') {
    $where_clauses[] = "st.department_id = :dept_id";
    $params[':dept_id'] = $dept_id;
}

$where_sql = implode(' AND ', $where_clauses);

// Department-level consumption summary
$sql = "
    SELECT 
        d.id,
        d.department_name,
        COUNT(DISTINCT st.id) as requisition_count,
        COUNT(DISTINCT st.employee_id) as active_personnel,
        COALESCE(SUM(st.quantity), 0) as total_units_consumed,
        COALESCE(SUM(st.quantity * st.unit_price), 0) as total_valuation
    FROM departments d
    LEFT JOIN stock_transactions st ON d.id = st.department_id AND {$where_sql}
    GROUP BY d.id
    ORDER BY total_units_consumed DESC
";
$stmt = $db->query($sql);
$dept_summaries = $stmt->fetchAll();

// Top 10 items consumed overall across departments
$top_items_sql = "
    SELECT 
        i.item_code,
        i.item_name,
        i.unit,
        d.department_name,
        SUM(st.quantity) as qty_sum
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    JOIN departments d ON st.department_id = d.id
    WHERE {$where_sql}
    GROUP BY st.department_id, st.item_id
    ORDER BY qty_sum DESC
    LIMIT 10
";
$top_items = $db->query($top_items_sql)->fetchAll();

// Dropdown
$all_depts = $db->query("SELECT id, department_name FROM departments ORDER BY department_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Department Consumption Analysis</h3>
    <p class="text-muted mb-0 small">Cross-department analysis of supply utilization, costs, and high-velocity item consumption.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<!-- Filter Bar -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="department-report.php" class="row g-2 align-items-center">
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label fs-xs text-muted mb-1">Filter Specific Department</label>
        <select name="department_id" class="form-select">
          <option value="">-- All Departments --</option>
          <?php foreach ($all_depts as $d): ?>
            <option value="<?= $d['id'] ?>" <?= ($dept_id == $d['id']) ? 'selected' : '' ?>>
              <?= e($d['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-flex align-items-end">
        <button type="submit" class="btn btn-primary-deep w-100 mt-md-4">Filter</button>
      </div>
    </form>
  </div>
</div>

<!-- Department Consumption Summary Table -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-header bg-white py-3 border-bottom">
    <h6 class="card-title fw-bold mb-0 text-dark">
      <i class="fa-solid fa-building text-primary me-2"></i> Department Consumption & Financial Allocation
    </h6>
  </div>
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Department Name</th>
          <th>Requisitions</th>
          <th>Requisitioning Personnel</th>
          <th>Total Units Consumed</th>
          <th>Total Disbursed Valuation</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($dept_summaries as $ds): ?>
          <tr>
            <td class="fw-bold text-dark">
              <i class="fa-solid fa-folder-open text-primary me-2"></i><?= e($ds['department_name']) ?>
            </td>
            <td>
              <span class="badge bg-light text-dark border"><?= $ds['requisition_count'] ?> requests</span>
            </td>
            <td>
              <?= $ds['active_personnel'] ?> staff members
            </td>
            <td>
              <span class="fw-bold fs-6 text-danger"><?= number_format($ds['total_units_consumed']) ?></span> items
            </td>
            <td class="fw-bold text-dark">
              <?= format_currency($ds['total_valuation']) ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Top Consumed Items by Department -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="card-header bg-white py-3 border-bottom">
    <h6 class="card-title fw-bold mb-0 text-dark">
      <i class="fa-solid fa-ranking-star text-warning me-2"></i> Highest Velocity Supplies by Department
    </h6>
  </div>
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Department</th>
          <th>Item / SKU</th>
          <th>Total Units Consumed</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($top_items)): ?>
          <tr><td colspan="3" class="text-center py-4 text-muted">No usage data recorded for the selected period.</td></tr>
        <?php else: ?>
          <?php foreach ($top_items as $ti): ?>
            <tr>
              <td>
                <span class="badge bg-light text-dark border px-2 py-1"><?= e($ti['department_name']) ?></span>
              </td>
              <td>
                <span class="fw-semibold text-dark"><?= e($ti['item_name']) ?></span>
                <span class="font-monospace text-muted fs-xs ms-1">(<?= e($ti['item_code']) ?>)</span>
              </td>
              <td>
                <span class="fw-bold text-danger"><?= number_format($ti['qty_sum']) ?> <?= e($ti['unit']) ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
