<?php
/**
 * Smart Store Room Management System
 * Employee Issue Aggregated Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Employee Requisition Report';
$db = Database::getConnection();

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$dept_id = trim($_GET['department_id'] ?? '');

$where_clauses = ["st.transaction_type = 'OUT'"];
$params = [];

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

if ($dept_id !== '') {
    $where_clauses[] = "e.department_id = :dept_id";
    $params[':dept_id'] = $dept_id;
}

$where_sql = implode(' AND ', $where_clauses);

// Employee Requisition Aggregation
$sql = "
    SELECT 
        e.id,
        e.employee_code,
        e.employee_name,
        e.designation,
        d.department_name,
        COUNT(DISTINCT st.id) as total_requests,
        COALESCE(SUM(st.quantity), 0) as total_units_drawn,
        COALESCE(SUM(st.quantity * st.unit_price), 0) as total_valuation_drawn
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    LEFT JOIN stock_transactions st ON e.id = st.employee_id AND {$where_sql}
    GROUP BY e.id
    HAVING total_units_drawn > 0
    ORDER BY total_units_drawn DESC
";
$stmt = $db->query($sql);
$employee_stats = $stmt->fetchAll();

$departments = $db->query("SELECT id, department_name FROM departments ORDER BY department_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Employee Requisition Summary Report</h3>
    <p class="text-muted mb-0 small">Audit staff requisitions, volume drawn, and organizational material distributions.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<!-- Filter Bar -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="employee-issue-report.php" class="row g-2 align-items-center">
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label fs-xs text-muted mb-1">Department</label>
        <select name="department_id" class="form-select">
          <option value="">-- All Departments --</option>
          <?php foreach ($departments as $d): ?>
            <option value="<?= $d['id'] ?>" <?= ($dept_id == $d['id']) ? 'selected' : '' ?>>
              <?= e($d['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-flex align-items-end">
        <button type="submit" class="btn btn-primary-deep w-100 mt-md-4">Filter</button>
      </div>
    </form>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Employee Details</th>
          <th>Department</th>
          <th>Designation</th>
          <th>Requisition Count</th>
          <th>Total Units Drawn</th>
          <th>Total Value</th>
          <th class="text-end">Ledger</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($employee_stats)): ?>
          <tr><td colspan="7" class="text-center py-5 text-muted">No employee requisitions found for the specified filters.</td></tr>
        <?php else: ?>
          <?php foreach ($employee_stats as $emp): ?>
            <tr>
              <td>
                <div class="fw-bold text-dark"><?= e($emp['employee_name']) ?></div>
                <span class="font-monospace text-muted fs-xs"><?= e($emp['employee_code']) ?></span>
              </td>
              <td>
                <span class="badge bg-light text-dark border"><?= e($emp['department_name']) ?></span>
              </td>
              <td class="small text-dark"><?= e($emp['designation']) ?></td>
              <td>
                <span class="badge bg-secondary-subtle text-dark"><?= $emp['total_requests'] ?> requests</span>
              </td>
              <td>
                <span class="fw-bold text-danger"><?= number_format($emp['total_units_drawn']) ?></span> units
              </td>
              <td class="fw-bold text-dark"><?= format_currency($emp['total_valuation_drawn']) ?></td>
              <td class="text-end">
                <a href="../employees/history.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-info">
                  <i class="fa-solid fa-clock-rotate-left"></i> View History
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
