<?php
/**
 * Smart Store Room Management System
 * Employee Usage Report (Alias to Employee Issue Report)
 */
require_once __DIR__ . '/employee-issue-report.php';
