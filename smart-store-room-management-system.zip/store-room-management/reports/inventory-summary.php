<?php
/**
 * Smart Store Room Management System
 * Inventory Valuation & Stock Summary Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Inventory Summary Report';
$db = Database::getConnection();

// Overall Metrics
$metric_stmt = $db->query("
    SELECT 
        COUNT(*) as total_items,
        COALESCE(SUM(current_stock), 0) as total_units,
        COALESCE(SUM(current_stock * purchase_price), 0) as total_valuation,
        COUNT(CASE WHEN current_stock <= reorder_level AND current_stock > 0 THEN 1 END) as low_stock_count,
        COUNT(CASE WHEN current_stock = 0 THEN 1 END) as out_of_stock_count
    FROM items
    WHERE status = 'Active'
");
$stats = $metric_stmt->fetch();

// Category-wise Breakdown
$cat_stmt = $db->query("
    SELECT 
        c.category_name,
        COUNT(i.id) as item_count,
        COALESCE(SUM(i.current_stock), 0) as total_units,
        COALESCE(SUM(i.current_stock * i.purchase_price), 0) as total_value,
        COUNT(CASE WHEN i.current_stock <= i.reorder_level AND i.current_stock > 0 THEN 1 END) as low_count,
        COUNT(CASE WHEN i.current_stock = 0 THEN 1 END) as out_count
    FROM categories c
    LEFT JOIN items i ON c.id = i.category_id AND i.status = 'Active'
    GROUP BY c.id
    ORDER BY total_value DESC
");
$category_breakdown = $cat_stmt->fetchAll();

// All Items Detailed Breakdown with filter
$selected_category = trim($_GET['category_id'] ?? '');
$filter_sql = ($selected_category !== '') ? "WHERE i.category_id = :cat_id AND i.status = 'Active'" : "WHERE i.status = 'Active'";
$detail_stmt = $db->prepare("
    SELECT 
        i.*,
        c.category_name,
        (i.current_stock * i.purchase_price) as item_total_value
    FROM items i
    JOIN categories c ON i.category_id = c.id
    {$filter_sql}
    ORDER BY (i.current_stock * i.purchase_price) DESC
");
if ($selected_category !== '') {
    $detail_stmt->execute([':cat_id' => $selected_category]);
} else {
    $detail_stmt->execute();
}
$detailed_items = $detail_stmt->fetchAll();

$categories = $db->query("SELECT id, category_name FROM categories ORDER BY category_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Comprehensive Inventory Valuation Summary</h3>
    <p class="text-muted mb-0 small">Audit report on store capitalization, unit volumes, and category asset distribution.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Active SKUs</div>
      <div class="fs-3 fw-bold text-dark"><?= number_format($stats['total_items']) ?></div>
      <small class="text-muted">Distinct catalog items</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Stock on Hand</div>
      <div class="fs-3 fw-bold text-primary"><?= number_format($stats['total_units']) ?></div>
      <small class="text-muted">Discrete physical units</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Asset Valuation</div>
      <div class="fs-3 fw-bold text-success"><?= format_currency($stats['total_valuation']) ?></div>
      <small class="text-muted">At purchase cost</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Deficient / Stockout SKUs</div>
      <div class="fs-3 fw-bold text-danger"><?= $stats['low_stock_count'] + $stats['out_of_stock_count'] ?></div>
      <small class="text-danger"><?= $stats['out_of_stock_count'] ?> depleted &bull; <?= $stats['low_stock_count'] ?> low</small>
    </div>
  </div>
</div>

<!-- Category Breakdown Table -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-header bg-white py-3 border-bottom">
    <h6 class="card-title fw-bold mb-0 text-dark">
      <i class="fa-solid fa-layer-group text-primary me-2"></i> Category Asset Allocation & Unit Concentration
    </h6>
  </div>
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Category Name</th>
          <th>Active SKUs</th>
          <th>Physical Units</th>
          <th>Total Asset Value</th>
          <th>% Portfolio Value</th>
          <th>Deficiencies</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($category_breakdown as $cat): ?>
          <?php 
            $pct = ($stats['total_valuation'] > 0) ? round(($cat['total_value'] / $stats['total_valuation']) * 100, 1) : 0;
          ?>
          <tr>
            <td class="fw-bold text-dark"><?= e($cat['category_name']) ?></td>
            <td><?= $cat['item_count'] ?> SKUs</td>
            <td class="fw-semibold text-dark"><?= number_format($cat['total_units']) ?></td>
            <td class="fw-bold text-success"><?= format_currency($cat['total_value']) ?></td>
            <td style="width: 200px;">
              <div class="d-flex align-items-center gap-2">
                <div class="progress flex-grow-1" style="height: 6px;">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $pct ?>%;"></div>
                </div>
                <span class="small text-muted"><?= $pct ?>%</span>
              </div>
            </td>
            <td>
              <?php if ($cat['out_count'] > 0): ?>
                <span class="badge bg-danger"><?= $cat['out_count'] ?> Out</span>
              <?php endif; ?>
              <?php if ($cat['low_count'] > 0): ?>
                <span class="badge bg-warning text-dark ms-1"><?= $cat['low_count'] ?> Low</span>
              <?php endif; ?>
              <?php if ($cat['out_count'] == 0 && $cat['low_count'] == 0): ?>
                <span class="badge bg-success-subtle text-success border border-success-subtle">Optimal</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Detailed Item Valuation Ledger -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="card-header bg-white py-3 border-bottom d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
    <h6 class="card-title fw-bold mb-0 text-dark">
      <i class="fa-solid fa-boxes-stacked text-primary me-2"></i> Inventory Item Valuation Ledger
    </h6>
    <form method="GET" class="d-flex align-items-center gap-2">
      <select name="category_id" class="form-select form-select-sm" onchange="this.form.submit()">
        <option value="">-- All Categories --</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= ($selected_category == $c['id']) ? 'selected' : '' ?>>
            <?= e($c['category_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>SKU Code</th>
          <th>Item Description</th>
          <th>Category</th>
          <th>Location / Bin</th>
          <th>Current Stock</th>
          <th>Unit Cost</th>
          <th>Total Valuation</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($detailed_items as $dit): ?>
          <tr>
            <td class="font-monospace fw-bold text-dark"><?= e($dit['item_code']) ?></td>
            <td class="fw-semibold text-dark"><?= e($dit['item_name']) ?></td>
            <td><span class="badge bg-light text-dark border"><?= e($dit['category_name']) ?></span></td>
            <td class="small text-muted"><?= e($dit['location']) ?> (Rack: <?= e($dit['rack_no']) ?>)</td>
            <td>
              <span class="fw-bold <?= ($dit['current_stock'] == 0) ? 'text-danger' : (($dit['current_stock'] <= $dit['reorder_level']) ? 'text-warning-emphasis' : 'text-dark') ?>">
                <?= $dit['current_stock'] ?>
              </span>
              <span class="text-muted small"><?= e($dit['unit']) ?></span>
            </td>
            <td><?= format_currency($dit['purchase_price']) ?></td>
            <td class="fw-bold text-success"><?= format_currency($dit['item_total_value']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
