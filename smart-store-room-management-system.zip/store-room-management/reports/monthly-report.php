<?php
/**
 * Smart Store Room Management System
 * Monthly Inventory Movement & Flow Analysis Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Monthly Movement Report';
$db = Database::getConnection();

$selected_year = (int)($_GET['year'] ?? date('Y'));

// Aggregate monthly movement
$sql = "
    SELECT 
        strftime('%m', transaction_date) as month_num,
        SUM(CASE WHEN transaction_type = 'IN' THEN quantity ELSE 0 END) as in_units,
        SUM(CASE WHEN transaction_type = 'IN' THEN (quantity * unit_price) ELSE 0 END) as in_spend,
        SUM(CASE WHEN transaction_type = 'OUT' THEN quantity ELSE 0 END) as out_units,
        SUM(CASE WHEN transaction_type = 'OUT' THEN (quantity * unit_price) ELSE 0 END) as out_valuation,
        SUM(CASE WHEN transaction_type = 'RETURN' THEN quantity ELSE 0 END) as return_units
    FROM stock_transactions
    WHERE strftime('%Y', transaction_date) = :year
    GROUP BY strftime('%m', transaction_date)
    ORDER BY month_num ASC
";

// If MySQL is active, adapt date formatting syntax
if (extension_loaded('pdo_mysql') && $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
    $sql = "
        SELECT 
            LPAD(MONTH(transaction_date), 2, '0') as month_num,
            SUM(CASE WHEN transaction_type = 'IN' THEN quantity ELSE 0 END) as in_units,
            SUM(CASE WHEN transaction_type = 'IN' THEN (quantity * unit_price) ELSE 0 END) as in_spend,
            SUM(CASE WHEN transaction_type = 'OUT' THEN quantity ELSE 0 END) as out_units,
            SUM(CASE WHEN transaction_type = 'OUT' THEN (quantity * unit_price) ELSE 0 END) as out_valuation,
            SUM(CASE WHEN transaction_type = 'RETURN' THEN quantity ELSE 0 END) as return_units
        FROM stock_transactions
        WHERE YEAR(transaction_date) = :year
        GROUP BY MONTH(transaction_date)
        ORDER BY month_num ASC
    ";
}

$stmt = $db->prepare($sql);
$stmt->execute([':year' => (string)$selected_year]);
$raw_months = $stmt->fetchAll();

$month_names = [
    '01' => 'January', '02' => 'February', '03' => 'March',
    '04' => 'April', '05' => 'May', '06' => 'June',
    '07' => 'July', '08' => 'August', '09' => 'September',
    '10' => 'October', '11' => 'November', '12' => 'December'
];

$monthly_data = [];
$tot_in_units = 0;
$tot_in_spend = 0;
$tot_out_units = 0;
$tot_out_val = 0;

foreach ($raw_months as $rm) {
    $m = $rm['month_num'];
    $monthly_data[$m] = $rm;
    $tot_in_units += (int)$rm['in_units'];
    $tot_in_spend += (float)$rm['in_spend'];
    $tot_out_units += (int)$rm['out_units'];
    $tot_out_val += (float)$rm['out_valuation'];
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Monthly Inventory Movement (<?= $selected_year ?>)</h3>
    <p class="text-muted mb-0 small">Month-by-month inflow vs. disbursement balance, financial volume, and inventory velocity.</p>
  </div>
  <div class="d-flex gap-2 align-items-center">
    <form method="GET" class="d-flex align-items-center gap-2">
      <label class="form-label mb-0 small text-muted">Year:</label>
      <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
        <?php for ($y = date('Y') + 1; $y >= date('Y') - 3; $y--): ?>
          <option value="<?= $y ?>" <?= ($selected_year == $y) ? 'selected' : '' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </form>
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
      <i class="fa-solid fa-print me-1"></i> Print
    </button>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Annual Stock Received</div>
      <div class="fs-3 fw-bold text-success">+<?= number_format($tot_in_units) ?></div>
      <small class="text-muted">Total units replenished</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Annual Procurement Spend</div>
      <div class="fs-3 fw-bold text-primary"><?= format_currency($tot_in_spend) ?></div>
      <small class="text-muted">Inbound inventory cost</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Annual Stock Disbursed</div>
      <div class="fs-3 fw-bold text-danger">-<?= number_format($tot_out_units) ?></div>
      <small class="text-muted">Units issued to staff</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Disbursed Inventory Value</div>
      <div class="fs-3 fw-bold text-dark"><?= format_currency($tot_out_val) ?></div>
      <small class="text-muted">Valuation of consumed items</small>
    </div>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Month</th>
          <th>Stock In (Units)</th>
          <th>Procurement Cost</th>
          <th>Stock Out (Units)</th>
          <th>Disbursed Value</th>
          <th>Returns Handled</th>
          <th>Net Unit Flow</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($month_names as $m_num => $m_title): ?>
          <?php 
            $data = $monthly_data[$m_num] ?? ['in_units' => 0, 'in_spend' => 0, 'out_units' => 0, 'out_valuation' => 0, 'return_units' => 0];
            $net = (int)$data['in_units'] - (int)$data['out_units'];
          ?>
          <tr>
            <td class="fw-bold text-dark">
              <?= $m_title ?> <?= $selected_year ?>
            </td>
            <td>
              <span class="text-success fw-semibold">+<?= number_format($data['in_units']) ?></span>
            </td>
            <td><?= format_currency($data['in_spend']) ?></td>
            <td>
              <span class="text-danger fw-semibold">-<?= number_format($data['out_units']) ?></span>
            </td>
            <td><?= format_currency($data['out_valuation']) ?></td>
            <td><?= number_format($data['return_units']) ?> units</td>
            <td>
              <span class="badge <?= ($net > 0) ? 'bg-success' : (($net < 0) ? 'bg-danger' : 'bg-secondary') ?> px-2 py-1">
                <?= ($net > 0) ? "+{$net}" : $net ?>
              </span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
