<?php
/**
 * Smart Store Room Management System
 * Returns History & RMA Audit Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Returns Report';
$db = Database::getConnection();

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

$where_clauses = ["st.transaction_type = 'RETURN'"];
$params = [];

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

$where_sql = implode(' AND ', $where_clauses);

$sql = "
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        e.employee_name,
        e.employee_code,
        d.department_name,
        s.supplier_name,
        u.name as creator_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    JOIN users u ON st.created_by = u.id
    WHERE {$where_sql}
    ORDER BY st.transaction_date DESC, st.id DESC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Stock Returns & Debit Audit Report</h3>
    <p class="text-muted mb-0 small">Audit goods returned by employees to store shelves and vendor RMA return records.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="return-report.php" class="row g-2 align-items-center">
      <div class="col-md-4">
        <label class="form-label fs-xs text-muted mb-1">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label fs-xs text-muted mb-1">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>">
      </div>
      <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary-deep w-100 mt-md-4">Filter Records</button>
      </div>
    </form>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Txn Code</th>
          <th>Return Date</th>
          <th>Item / SKU</th>
          <th>Direction / Party</th>
          <th>Quantity</th>
          <th>Reference #</th>
          <th>Processed By</th>
          <th>Condition / Remarks</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="8" class="text-center py-5 text-muted">No return transactions recorded in this period.</td></tr>
        <?php else: ?>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td class="font-monospace fw-bold text-dark small"><?= e($row['transaction_code']) ?></td>
              <td class="small text-muted text-nowrap"><?= format_date($row['transaction_date']) ?></td>
              <td>
                <div class="fw-semibold text-dark small"><?= e($row['item_name']) ?></div>
                <span class="font-monospace text-muted fs-xs"><?= e($row['item_code']) ?></span>
              </td>
              <td class="small">
                <?php if ($row['employee_name']): ?>
                  <span class="badge bg-success-subtle text-success border border-success-subtle mb-1 d-inline-block">From Employee</span>
                  <div class="fw-medium text-dark"><?= e($row['employee_name']) ?></div>
                  <small class="text-muted"><?= e($row['department_name']) ?></small>
                <?php else: ?>
                  <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle mb-1 d-inline-block">To Vendor</span>
                  <div class="fw-medium text-dark"><?= e($row['supplier_name'] ?? 'Vendor Direct') ?></div>
                <?php endif; ?>
              </td>
              <td>
                <span class="fw-bold text-info-emphasis"><?= $row['quantity'] ?></span>
                <span class="text-muted small"><?= e($row['unit']) ?></span>
              </td>
              <td class="font-monospace small text-muted"><?= e($row['reference_no'] ?? '-') ?></td>
              <td class="small text-muted"><?= e($row['creator_name']) ?></td>
              <td class="small text-muted" style="max-width: 250px;"><?= e($row['remarks']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
