<?php
/**
 * Smart Store Room Management System
 * Stock IN (Procurement & Receipts) Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Stock In Report';
$db = Database::getConnection();

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$supplier_id = trim($_GET['supplier_id'] ?? '');
$item_id = trim($_GET['item_id'] ?? '');

$where_clauses = ["st.transaction_type = 'IN'"];
$params = [];

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

if ($supplier_id !== '') {
    $where_clauses[] = "st.supplier_id = :supplier_id";
    $params[':supplier_id'] = $supplier_id;
}

if ($item_id !== '') {
    $where_clauses[] = "st.item_id = :item_id";
    $params[':item_id'] = $item_id;
}

$where_sql = implode(' AND ', $where_clauses);

// Fetch Summary Stats
$summary_stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_intakes,
        COALESCE(SUM(st.quantity), 0) as total_units,
        COALESCE(SUM(st.quantity * st.unit_price), 0) as total_spend
    FROM stock_transactions st
    WHERE {$where_sql}
");
$summary_stmt->execute($params);
$summary = $summary_stmt->fetch();

// Fetch Rows
$sql = "
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        s.supplier_name,
        u.name as creator_name,
        (st.quantity * st.unit_price) as row_total
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    JOIN users u ON st.created_by = u.id
    WHERE {$where_sql}
    ORDER BY st.transaction_date DESC, st.id DESC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Dropdowns
$suppliers = $db->query("SELECT id, supplier_name FROM suppliers ORDER BY supplier_name ASC")->fetchAll();
$items = $db->query("SELECT id, item_code, item_name FROM items ORDER BY item_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Stock In & Procurement Intake Report</h3>
    <p class="text-muted mb-0 small">Audit incoming stock transactions, vendor deliveries, and inventory purchase expenditures.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Delivery Shipments</div>
      <div class="fs-3 fw-bold text-dark"><?= number_format($summary['total_intakes']) ?></div>
      <small class="text-muted">Completed Stock In records</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Quantity Received</div>
      <div class="fs-3 fw-bold text-success">+<?= number_format($summary['total_units']) ?></div>
      <small class="text-muted">Total inventory units stocked</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Procurement Cost</div>
      <div class="fs-3 fw-bold text-primary"><?= format_currency($summary['total_spend']) ?></div>
      <small class="text-muted">Calculated at purchase invoice price</small>
    </div>
  </div>
</div>

<!-- Filters Form -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="stock-in-report.php" class="row g-2 align-items-center">
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">Supplier</label>
        <select name="supplier_id" class="form-select">
          <option value="">-- All Suppliers --</option>
          <?php foreach ($suppliers as $sup): ?>
            <option value="<?= $sup['id'] ?>" <?= ($supplier_id == $sup['id']) ? 'selected' : '' ?>>
              <?= e($sup['supplier_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">Item Filter</label>
        <select name="item_id" class="form-select">
          <option value="">-- All Items --</option>
          <?php foreach ($items as $it): ?>
            <option value="<?= $it['id'] ?>" <?= ($item_id == $it['id']) ? 'selected' : '' ?>>
              <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-12 d-flex justify-content-end gap-2 mt-3 pt-2 border-top">
        <?php if ($date_from !== '' || $date_to !== '' || $supplier_id !== '' || $item_id !== ''): ?>
          <a href="stock-in-report.php" class="btn btn-outline-secondary">Reset Filters</a>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary-deep px-4">Generate Report</button>
      </div>
    </form>
  </div>
</div>

<!-- Ledger Table -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Txn Code</th>
          <th>Received Date</th>
          <th>Item / SKU</th>
          <th>Delivering Supplier</th>
          <th>Quantity</th>
          <th>Unit Price</th>
          <th>Total Cost</th>
          <th>Invoice / Ref #</th>
          <th>Received By</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="9" class="text-center py-5 text-muted">No stock intake transactions match your query filters.</td></tr>
        <?php else: ?>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td class="font-monospace fw-bold text-dark small"><?= e($row['transaction_code']) ?></td>
              <td class="small text-muted text-nowrap"><?= format_date($row['transaction_date']) ?></td>
              <td>
                <div class="fw-semibold text-dark small"><?= e($row['item_name']) ?></div>
                <span class="font-monospace text-muted fs-xs"><?= e($row['item_code']) ?></span>
              </td>
              <td class="small text-dark fw-medium">
                <i class="fa-solid fa-truck text-muted me-1"></i><?= e($row['supplier_name'] ?? 'Direct Intake') ?>
              </td>
              <td>
                <span class="fw-bold text-success">+<?= $row['quantity'] ?></span>
                <span class="text-muted small"><?= e($row['unit']) ?></span>
              </td>
              <td class="small"><?= format_currency($row['unit_price']) ?></td>
              <td class="fw-bold text-dark"><?= format_currency($row['row_total']) ?></td>
              <td class="font-monospace small text-muted"><?= e($row['reference_no'] ?? '-') ?></td>
              <td class="small text-muted"><?= e($row['creator_name']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
