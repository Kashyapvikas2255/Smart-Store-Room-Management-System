<?php
/**
 * Smart Store Room Management System
 * Stock OUT (Disbursements & Requisitions) Report
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Stock Out Report';
$db = Database::getConnection();

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$department_id = trim($_GET['department_id'] ?? '');
$employee_id = trim($_GET['employee_id'] ?? '');
$item_id = trim($_GET['item_id'] ?? '');

$where_clauses = ["st.transaction_type = 'OUT'"];
$params = [];

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

if ($department_id !== '') {
    $where_clauses[] = "st.department_id = :dept_id";
    $params[':dept_id'] = $department_id;
}

if ($employee_id !== '') {
    $where_clauses[] = "st.employee_id = :emp_id";
    $params[':emp_id'] = $employee_id;
}

if ($item_id !== '') {
    $where_clauses[] = "st.item_id = :item_id";
    $params[':item_id'] = $item_id;
}

$where_sql = implode(' AND ', $where_clauses);

// Summary Stats
$summary_stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_issues,
        COALESCE(SUM(st.quantity), 0) as total_units_issued,
        COALESCE(SUM(st.quantity * st.unit_price), 0) as total_issue_value
    FROM stock_transactions st
    WHERE {$where_sql}
");
$summary_stmt->execute($params);
$summary = $summary_stmt->fetch();

// Rows
$sql = "
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        e.employee_name,
        e.employee_code,
        d.department_name,
        u.name as creator_name,
        (st.quantity * st.unit_price) as row_total
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    JOIN users u ON st.created_by = u.id
    WHERE {$where_sql}
    ORDER BY st.transaction_date DESC, st.id DESC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Dropdowns
$departments = $db->query("SELECT id, department_name FROM departments ORDER BY department_name ASC")->fetchAll();
$employees = $db->query("SELECT id, employee_name, employee_code FROM employees ORDER BY employee_name ASC")->fetchAll();
$items = $db->query("SELECT id, item_code, item_name FROM items ORDER BY item_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Stock Out & Issue Activity Report</h3>
    <p class="text-muted mb-0 small">Audit inventory disbursements across personnel, departments, and project work orders.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Report
    </button>
  </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Issue Transactions</div>
      <div class="fs-3 fw-bold text-dark"><?= number_format($summary['total_issues']) ?></div>
      <small class="text-muted">Requisition vouchers executed</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Items Distributed</div>
      <div class="fs-3 fw-bold text-danger">-<?= number_format($summary['total_units_issued']) ?></div>
      <small class="text-muted">Total physical units issued</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card border-0 shadow-sm rounded-3 p-3">
      <div class="text-muted small mb-1">Total Valuation Disbursed</div>
      <div class="fs-3 fw-bold text-primary"><?= format_currency($summary['total_issue_value']) ?></div>
      <small class="text-muted">At issue valuation price</small>
    </div>
  </div>
</div>

<!-- Filter Controls -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="stock-out-report.php" class="row g-2 align-items-center">
      <div class="col-md-2">
        <label class="form-label fs-xs text-muted mb-1">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label fs-xs text-muted mb-1">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">Department</label>
        <select name="department_id" class="form-select">
          <option value="">-- All Departments --</option>
          <?php foreach ($departments as $d): ?>
            <option value="<?= $d['id'] ?>" <?= ($department_id == $d['id']) ? 'selected' : '' ?>>
              <?= e($d['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label fs-xs text-muted mb-1">Employee</label>
        <select name="employee_id" class="form-select">
          <option value="">-- All Employees --</option>
          <?php foreach ($employees as $e): ?>
            <option value="<?= $e['id'] ?>" <?= ($employee_id == $e['id']) ? 'selected' : '' ?>>
              <?= e($e['employee_name']) ?> (<?= e($e['employee_code']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label fs-xs text-muted mb-1">Item Filter</label>
        <select name="item_id" class="form-select">
          <option value="">-- All Items --</option>
          <?php foreach ($items as $it): ?>
            <option value="<?= $it['id'] ?>" <?= ($item_id == $it['id']) ? 'selected' : '' ?>>
              <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-12 d-flex justify-content-end gap-2 mt-3 pt-2 border-top">
        <?php if ($date_from !== '' || $date_to !== '' || $department_id !== '' || $employee_id !== '' || $item_id !== ''): ?>
          <a href="stock-out-report.php" class="btn btn-outline-secondary">Reset Filters</a>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary-deep px-4">Generate Report</button>
      </div>
    </form>
  </div>
</div>

<!-- Ledger Table -->
<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Txn Code</th>
          <th>Issue Date</th>
          <th>Item / SKU</th>
          <th>Recipient Employee</th>
          <th>Department</th>
          <th>Quantity</th>
          <th>Issue Value</th>
          <th>Requisition #</th>
          <th>Authorized By</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="9" class="text-center py-5 text-muted">No stock issue transactions match your query parameters.</td></tr>
        <?php else: ?>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td class="font-monospace fw-bold text-dark small"><?= e($row['transaction_code']) ?></td>
              <td class="small text-muted text-nowrap"><?= format_date($row['transaction_date']) ?></td>
              <td>
                <div class="fw-semibold text-dark small"><?= e($row['item_name']) ?></div>
                <span class="font-monospace text-muted fs-xs"><?= e($row['item_code']) ?></span>
              </td>
              <td>
                <div class="fw-medium text-dark small"><?= e($row['employee_name'] ?? 'Unassigned') ?></div>
                <span class="text-muted fs-xs font-monospace"><?= e($row['employee_code'] ?? '') ?></span>
              </td>
              <td>
                <span class="badge bg-light text-dark border"><?= e($row['department_name'] ?? 'Direct') ?></span>
              </td>
              <td>
                <span class="fw-bold text-danger">-<?= $row['quantity'] ?></span>
                <span class="text-muted small"><?= e($row['unit']) ?></span>
              </td>
              <td class="fw-bold text-dark"><?= format_currency($row['row_total']) ?></td>
              <td class="font-monospace small text-muted"><?= e($row['reference_no'] ?? '-') ?></td>
              <td class="small text-muted"><?= e($row['creator_name']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
