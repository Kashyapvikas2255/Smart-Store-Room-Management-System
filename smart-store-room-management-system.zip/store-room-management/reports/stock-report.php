<?php
/**
 * Smart Store Room Management System
 * Current Stock Report (Alias to Inventory Summary)
 */
require_once __DIR__ . '/inventory-summary.php';
