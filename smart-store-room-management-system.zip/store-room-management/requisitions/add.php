<?php
/**
 * Smart Store Room Management System
 * Create New Material Requisition Request
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'New Requisition Request';
$db = Database::getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);
$error = '';

// Generate next Requisition No
$req_no = generate_requisition_no($db);

// Fetch active items with categories & stocks
$items = $db->query("
    SELECT i.id, i.item_code, i.item_name, i.current_stock, i.unit, i.location, i.rack_no, c.category_name
    FROM items i
    JOIN categories c ON i.category_id = c.id
    WHERE i.status = 'Active'
    ORDER BY i.item_name ASC
")->fetchAll();

// Fetch employees
$employees = $db->query("
    SELECT e.id, e.employee_code, e.employee_name, e.designation, e.department_id, d.department_name
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    WHERE e.status = 'Active'
    ORDER BY e.employee_name ASC
")->fetchAll();

// Fetch departments
$departments = $db->query("SELECT id, department_name FROM departments WHERE status = 'Active' ORDER BY department_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();

    $item_id = (int)($_POST['item_id'] ?? 0);
    $employee_id = (int)($_POST['employee_id'] ?? 0);
    $department_id = (int)($_POST['department_id'] ?? 0);
    $requested_qty = (int)($_POST['requested_qty'] ?? 0);
    $priority = trim($_POST['priority'] ?? 'Normal');
    $purpose = trim($_POST['purpose'] ?? '');

    if ($item_id <= 0) {
        $error = 'Please select an item from the inventory catalog.';
    } elseif ($employee_id <= 0) {
        $error = 'Please specify the requesting employee.';
    } elseif ($department_id <= 0) {
        $error = 'Please select the target department.';
    } elseif ($requested_qty <= 0) {
        $error = 'Requested quantity must be at least 1.';
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO requisitions (
                    requisition_no, item_id, employee_id, department_id,
                    requested_qty, priority, purpose, status, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?)
            ");
            $stmt->execute([
                $req_no,
                $item_id,
                $employee_id,
                $department_id,
                $requested_qty,
                $priority,
                $purpose,
                $user_id
            ]);

            set_flash('success', 'Requisition ' . $req_no . ' submitted successfully and sent to Store Manager for approval.');
            header('Location: index.php');
            exit;
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="container-fluid p-0" style="max-width: 900px;">
  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h3 class="fw-bold mb-1 text-dark">Create Material Requisition</h3>
      <p class="text-muted small mb-0">Submit a new internal request for store room materials and equipment</p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary d-flex align-items-center gap-2">
      <i class="fa-solid fa-arrow-left"></i>
      <span>Back to Requisitions</span>
    </a>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fa-solid fa-circle-exclamation me-2"></i><?= e($error) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card border-0 shadow-sm">
    <div class="card-body p-4">
      <form method="POST" action="add.php">
        <input type="hidden" name="csrf_token" value="<?= e(get_csrf_token()) ?>">

        <!-- Header Info Row -->
        <div class="row g-3 mb-4 p-3 bg-light rounded-3">
          <div class="col-md-6">
            <label class="form-label small text-muted text-uppercase fw-semibold mb-1">Generated Requisition #</label>
            <input type="text" class="form-control font-monospace fw-bold bg-white" value="<?= e($req_no) ?>" readonly>
          </div>
          <div class="col-md-6">
            <label class="form-label small text-muted text-uppercase fw-semibold mb-1">Date & Time</label>
            <input type="text" class="form-control bg-white" value="<?= date('d M Y, h:i A') ?>" readonly>
          </div>
        </div>

        <!-- Requestor Details -->
        <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">
          <i class="fa-solid fa-user-tag text-primary me-2"></i>Requestor Information
        </h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Requesting Employee <span class="text-danger">*</span></label>
            <select name="employee_id" id="employee_id" class="form-select" required onchange="autoFillDept(this)">
              <option value="">-- Choose Employee --</option>
              <?php foreach ($employees as $emp): ?>
                <option value="<?= $emp['id'] ?>" data-dept-id="<?= $emp['department_id'] ?>">
                  <?= e($emp['employee_name']) ?> (<?= e($emp['employee_code']) ?>) &bull; <?= e($emp['designation']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Target Department <span class="text-danger">*</span></label>
            <select name="department_id" id="department_id" class="form-select" required>
              <option value="">-- Choose Department --</option>
              <?php foreach ($departments as $dept): ?>
                <option value="<?= $dept['id'] ?>"><?= e($dept['department_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Material Details -->
        <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">
          <i class="fa-solid fa-boxes-stacked text-primary me-2"></i>Item & Material Specifications
        </h5>
        <div class="row g-3 mb-4">
          <div class="col-12">
            <label class="form-label fw-semibold">Select Store Room Item <span class="text-danger">*</span></label>
            <select name="item_id" id="item_id" class="form-select form-select-lg" required onchange="updateItemStockInfo(this)">
              <option value="">-- Select an Item from Store Catalog --</option>
              <?php foreach ($items as $itm): ?>
                <option value="<?= $itm['id'] ?>" 
                        data-code="<?= e($itm['item_code']) ?>"
                        data-stock="<?= (int)$itm['current_stock'] ?>"
                        data-unit="<?= e($itm['unit']) ?>"
                        data-location="<?= e($itm['location']) ?>"
                        data-rack="<?= e($itm['rack_no']) ?>"
                        data-category="<?= e($itm['category_name']) ?>">
                  <?= e($itm['item_name']) ?> (<?= e($itm['item_code']) ?>) &bull; Stock: <?= (int)$itm['current_stock'] ?> <?= e($itm['unit']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Dynamic Item Info Card -->
          <div class="col-12" id="itemInfoCard" style="display: none;">
            <div class="card border bg-light-subtle">
              <div class="card-body p-3">
                <div class="row g-2 text-sm">
                  <div class="col-sm-4">
                    <span class="text-muted small">Available In Store:</span>
                    <div class="fw-bold fs-6 text-dark" id="displayStock">-</div>
                  </div>
                  <div class="col-sm-4">
                    <span class="text-muted small">Category:</span>
                    <div class="fw-semibold text-dark" id="displayCategory">-</div>
                  </div>
                  <div class="col-sm-4">
                    <span class="text-muted small">Store Room Location:</span>
                    <div class="fw-semibold text-dark" id="displayLocation">-</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Requested Quantity <span class="text-danger">*</span></label>
            <div class="input-group">
              <input type="number" name="requested_qty" id="requested_qty" class="form-control form-control-lg fw-bold" min="1" required placeholder="e.g. 5">
              <span class="input-group-text bg-light fw-semibold" id="displayUnit">Units</span>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Priority / Urgency <span class="text-danger">*</span></label>
            <select name="priority" class="form-select form-select-lg" required>
              <option value="Normal" selected>Normal (Standard Replenishment)</option>
              <option value="Urgent">Urgent (Immediate Project Need)</option>
              <option value="Critical">Critical (Breakdown / Emergency)</option>
            </select>
          </div>

          <div class="col-12">
            <label class="form-label fw-semibold">Purpose & Operational Justification</label>
            <textarea name="purpose" class="form-control" rows="3" placeholder="Describe where or why these materials are needed (e.g. Project Code, Server Maintenance, Training Workshop, Office supplies replenishment)..."></textarea>
            <div class="form-text small">Providing clear operational reasons helps Store Managers review and authorize the requisition faster.</div>
          </div>
        </div>

        <div class="d-flex justify-content-end gap-3 pt-3 border-top">
          <a href="index.php" class="btn btn-light border px-4">Cancel</a>
          <button type="submit" class="btn btn-primary px-4 d-flex align-items-center gap-2">
            <i class="fa-solid fa-paper-plane"></i>
            <span>Submit Requisition Request</span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function autoFillDept(select) {
  const selectedOption = select.options[select.selectedIndex];
  const deptId = selectedOption.getAttribute('data-dept-id');
  if (deptId) {
    document.getElementById('department_id').value = deptId;
  }
}

function updateItemStockInfo(select) {
  const selectedOption = select.options[select.selectedIndex];
  const infoCard = document.getElementById('itemInfoCard');
  if (select.value === '') {
    infoCard.style.display = 'none';
    document.getElementById('displayUnit').textContent = 'Units';
    return;
  }
  
  const stock = parseInt(selectedOption.getAttribute('data-stock') || 0);
  const unit = selectedOption.getAttribute('data-unit') || 'Units';
  const cat = selectedOption.getAttribute('data-category') || '-';
  const loc = selectedOption.getAttribute('data-location') || '-';
  const rack = selectedOption.getAttribute('data-rack') || '';

  infoCard.style.display = 'block';
  document.getElementById('displayUnit').textContent = unit;
  document.getElementById('displayCategory').textContent = cat;
  document.getElementById('displayLocation').textContent = loc + (rack ? ' (Rack ' + rack + ')' : '');

  const stockElem = document.getElementById('displayStock');
  if (stock <= 0) {
    stockElem.innerHTML = '<span class="text-danger fw-bold"><i class="fa-solid fa-circle-xmark me-1"></i>0 ' + unit + ' (Currently Out of Stock)</span>';
  } else {
    stockElem.innerHTML = '<span class="text-success fw-bold"><i class="fa-solid fa-circle-check me-1"></i>' + stock + ' ' + unit + ' available</span>';
  }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
