<?php
/**
 * Smart Store Room Management System
 * Material Requisitions & Online Manager Approval Workflow
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Material Requisitions & Approvals';
$db = Database::getConnection();
$user_role = $_SESSION['user_role'] ?? 'Store Staff';
$user_id = (int)($_SESSION['user_id'] ?? 0);
$is_manager_or_admin = has_role(['Admin', 'Store Manager']);

// Handle CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $export_query = "
        SELECT 
            r.requisition_no,
            r.created_at,
            i.item_code,
            i.item_name,
            e.employee_name,
            e.employee_code,
            d.department_name,
            r.requested_qty,
            r.approved_qty,
            r.priority,
            r.status,
            r.purpose,
            u.name as approved_by_name,
            r.approved_at,
            r.rejection_reason
        FROM requisitions r
        JOIN items i ON r.item_id = i.id
        JOIN employees e ON r.employee_id = e.id
        JOIN departments d ON r.department_id = d.id
        LEFT JOIN users u ON r.approved_by = u.id
        ORDER BY r.id DESC
    ";
    $rows = $db->query($export_query)->fetchAll();
    $headers = [
        'Requisition No', 'Requested Date', 'Item Code', 'Item Name',
        'Employee Name', 'Employee Code', 'Department', 'Requested Qty',
        'Approved Qty', 'Priority', 'Status', 'Purpose', 'Approved By',
        'Approved At', 'Rejection Reason'
    ];
    $export_data = [];
    foreach ($rows as $row) {
        $export_data[] = [
            $row['requisition_no'],
            $row['created_at'],
            $row['item_code'],
            $row['item_name'],
            $row['employee_name'],
            $row['employee_code'],
            $row['department_name'],
            $row['requested_qty'],
            $row['approved_qty'],
            $row['priority'],
            $row['status'],
            $row['purpose'],
            $row['approved_by_name'] ?? 'N/A',
            $row['approved_at'] ?? 'N/A',
            $row['rejection_reason'] ?? ''
        ];
    }
    export_to_csv('Requisitions_Export_' . date('Y-m-d') . '.csv', $headers, $export_data);
}

// Handle Approval / Rejection / Issuance Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();
    $action = trim($_POST['action'] ?? '');
    $req_id = (int)($_POST['requisition_id'] ?? 0);

    $req_stmt = $db->prepare("
        SELECT r.*, i.current_stock, i.item_name, i.item_code, i.unit, i.purchase_price, i.selling_or_issue_price,
               e.employee_name, d.department_name
        FROM requisitions r
        JOIN items i ON r.item_id = i.id
        JOIN employees e ON r.employee_id = e.id
        JOIN departments d ON r.department_id = d.id
        WHERE r.id = ?
    ");
    $req_stmt->execute([$req_id]);
    $requisition = $req_stmt->fetch();

    if (!$requisition) {
        set_flash('error', 'Requisition record not found.');
        header('Location: index.php');
        exit;
    }

    if ($action === 'approve') {
        if (!$is_manager_or_admin) {
            set_flash('error', 'Access denied. Only Store Managers and Administrators can approve requisitions.');
            header('Location: index.php');
            exit;
        }

        $approved_qty = (int)($_POST['approved_qty'] ?? $requisition['requested_qty']);
        if ($approved_qty <= 0) {
            set_flash('error', 'Approved quantity must be at least 1.');
            header('Location: index.php');
            exit;
        }

        if ($approved_qty > $requisition['current_stock']) {
            set_flash('warning', 'Approved quantity exceeds current in-stock balance (' . $requisition['current_stock'] . ' available). Approval recorded, but restocking will be needed before issue.');
        }

        $stmt = $db->prepare("
            UPDATE requisitions 
            SET status = 'Approved', approved_qty = ?, approved_by = ?, approved_at = datetime('now')
            WHERE id = ?
        ");
        $stmt->execute([$approved_qty, $user_id, $req_id]);
        set_flash('success', 'Requisition #' . $requisition['requisition_no'] . ' successfully APPROVED for ' . $approved_qty . ' units.');
        header('Location: index.php');
        exit;
    } elseif ($action === 'reject') {
        if (!$is_manager_or_admin) {
            set_flash('error', 'Access denied. Only Store Managers and Administrators can reject requisitions.');
            header('Location: index.php');
            exit;
        }

        $reason = trim($_POST['rejection_reason'] ?? 'Not approved by store management.');
        $stmt = $db->prepare("
            UPDATE requisitions 
            SET status = 'Rejected', rejection_reason = ?, approved_by = ?, approved_at = datetime('now')
            WHERE id = ?
        ");
        $stmt->execute([$reason, $user_id, $req_id]);
        set_flash('warning', 'Requisition #' . $requisition['requisition_no'] . ' has been REJECTED.');
        header('Location: index.php');
        exit;
    } elseif ($action === 'issue') {
        // Issue stock based on approved quantity
        $issue_qty = (int)($requisition['approved_qty'] > 0 ? $requisition['approved_qty'] : $requisition['requested_qty']);

        if ($requisition['current_stock'] < $issue_qty) {
            set_flash('error', 'Cannot issue stock! Requested ' . $issue_qty . ' units, but only ' . $requisition['current_stock'] . ' units available in store room.');
            header('Location: index.php');
            exit;
        }

        try {
            $db->beginTransaction();

            $prev_stock = (int)$requisition['current_stock'];
            $new_stock = $prev_stock - $issue_qty;
            $unit_price = (float)$requisition['selling_or_issue_price'] ?: (float)$requisition['purchase_price'];
            $txn_code = generate_transaction_code($db, 'OUT');

            // 1. Insert stock_transaction
            $txn_stmt = $db->prepare("
                INSERT INTO stock_transactions (
                    transaction_code, item_id, transaction_type, quantity, 
                    previous_stock, new_stock, employee_id, department_id, 
                    unit_price, reference_no, remarks, transaction_date, created_by
                ) VALUES (?, ?, 'OUT', ?, ?, ?, ?, ?, ?, ?, ?, date('now'), ?)
            ");
            $txn_stmt->execute([
                $txn_code,
                $requisition['item_id'],
                $issue_qty,
                $prev_stock,
                $new_stock,
                $requisition['employee_id'],
                $requisition['department_id'],
                $unit_price,
                $requisition['requisition_no'],
                'Issued per Requisition #' . $requisition['requisition_no'] . ': ' . $requisition['purpose'],
                $user_id
            ]);
            $txn_id = (int)$db->lastInsertId();

            // 2. Deduct item stock
            $update_stmt = $db->prepare("UPDATE items SET current_stock = ?, updated_at = datetime('now') WHERE id = ?");
            $update_stmt->execute([$new_stock, $requisition['item_id']]);

            // 3. Mark requisition as Issued
            $req_update = $db->prepare("
                UPDATE requisitions 
                SET status = 'Issued', issued_at = datetime('now'), stock_transaction_id = ?
                WHERE id = ?
            ");
            $req_update->execute([$txn_id, $req_id]);

            $db->commit();

            set_flash('success', 'Stock issued successfully! ' . $issue_qty . ' units of ' . $requisition['item_name'] . ' handed over. Digital Issue Slip ready to print.');
            header('Location: ../slips/issue-slip.php?txn_id=' . $txn_id);
            exit;
        } catch (Exception $e) {
            $db->rollBack();
            set_flash('error', 'Error issuing stock: ' . $e->getMessage());
            header('Location: index.php');
            exit;
        }
    }
}

// Filters & Query
$status_filter = trim($_GET['status'] ?? '');
$priority_filter = trim($_GET['priority'] ?? '');
$search_query = trim($_GET['search'] ?? '');

$where_clauses = ['1=1'];
$params = [];

if ($status_filter !== '') {
    $where_clauses[] = 'r.status = ?';
    $params[] = $status_filter;
}
if ($priority_filter !== '') {
    $where_clauses[] = 'r.priority = ?';
    $params[] = $priority_filter;
}
if ($search_query !== '') {
    $where_clauses[] = '(r.requisition_no LIKE ? OR i.item_name LIKE ? OR i.item_code LIKE ? OR e.employee_name LIKE ? OR d.department_name LIKE ?)';
    $searchTerm = '%' . $search_query . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$where_sql = implode(' AND ', $where_clauses);

// Fetch summary metrics
$metric_stmt = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'Issued' THEN 1 ELSE 0 END) as issued,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected
    FROM requisitions
");
$metrics = $metric_stmt->fetch();

// Fetch requisitions list
$query = "
    SELECT 
        r.*,
        i.item_code,
        i.item_name,
        i.unit,
        i.current_stock,
        i.location,
        i.rack_no,
        e.employee_name,
        e.employee_code,
        e.designation,
        d.department_name,
        u_app.name as approved_by_name,
        u_req.name as created_by_name
    FROM requisitions r
    JOIN items i ON r.item_id = i.id
    JOIN employees e ON r.employee_id = e.id
    JOIN departments d ON r.department_id = d.id
    LEFT JOIN users u_app ON r.approved_by = u_app.id
    LEFT JOIN users u_req ON r.created_by = u_req.id
    WHERE $where_sql
    ORDER BY 
        CASE r.status 
            WHEN 'Pending' THEN 1 
            WHEN 'Approved' THEN 2 
            WHEN 'Issued' THEN 3 
            ELSE 4 
        END ASC,
        r.id DESC
";
$stmt = $db->prepare($query);
$stmt->execute($params);
$requisitions = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="container-fluid p-0">
  <!-- Page Header -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
      <h3 class="fw-bold mb-1 text-dark">Material Requisitions & Approvals</h3>
      <p class="text-muted small mb-0">Departmental material requests, online manager review workflow, and issue authorization</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a href="index.php?export=csv" class="btn btn-outline-success d-flex align-items-center gap-2">
        <i class="fa-solid fa-file-excel"></i>
        <span>Export CSV</span>
      </a>
      <a href="add.php" class="btn btn-primary d-flex align-items-center gap-2">
        <i class="fa-solid fa-plus"></i>
        <span>New Requisition Request</span>
      </a>
    </div>
  </div>

  <!-- Metric Badges Row -->
  <div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
      <a href="index.php?status=Pending" class="text-decoration-none">
        <div class="card stat-card border-0 shadow-sm <?= ($status_filter === 'Pending') ? 'border-start border-4 border-warning' : '' ?>">
          <div class="card-body p-3 d-flex align-items-center justify-content-between">
            <div>
              <span class="text-muted small fw-semibold text-uppercase">Pending Approval</span>
              <h3 class="fw-bold mb-0 text-warning"><?= (int)($metrics['pending'] ?? 0) ?></h3>
              <span class="text-xs text-muted">Awaiting Store Manager</span>
            </div>
            <div class="rounded-3 p-3 bg-warning-subtle text-warning fs-3">
              <i class="fa-solid fa-clock"></i>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-sm-6 col-xl-3">
      <a href="index.php?status=Approved" class="text-decoration-none">
        <div class="card stat-card border-0 shadow-sm <?= ($status_filter === 'Approved') ? 'border-start border-4 border-info' : '' ?>">
          <div class="card-body p-3 d-flex align-items-center justify-content-between">
            <div>
              <span class="text-muted small fw-semibold text-uppercase">Approved (Ready)</span>
              <h3 class="fw-bold mb-0 text-info"><?= (int)($metrics['approved'] ?? 0) ?></h3>
              <span class="text-xs text-muted">Ready for Stock-Out Issue</span>
            </div>
            <div class="rounded-3 p-3 bg-info-subtle text-info fs-3">
              <i class="fa-solid fa-check-double"></i>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-sm-6 col-xl-3">
      <a href="index.php?status=Issued" class="text-decoration-none">
        <div class="card stat-card border-0 shadow-sm <?= ($status_filter === 'Issued') ? 'border-start border-4 border-success' : '' ?>">
          <div class="card-body p-3 d-flex align-items-center justify-content-between">
            <div>
              <span class="text-muted small fw-semibold text-uppercase">Issued & Fulfilled</span>
              <h3 class="fw-bold mb-0 text-success"><?= (int)($metrics['issued'] ?? 0) ?></h3>
              <span class="text-xs text-muted">Completed with Issue Slips</span>
            </div>
            <div class="rounded-3 p-3 bg-success-subtle text-success fs-3">
              <i class="fa-solid fa-circle-check"></i>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-sm-6 col-xl-3">
      <a href="index.php" class="text-decoration-none">
        <div class="card stat-card border-0 shadow-sm">
          <div class="card-body p-3 d-flex align-items-center justify-content-between">
            <div>
              <span class="text-muted small fw-semibold text-uppercase">Total Requisitions</span>
              <h3 class="fw-bold mb-0 text-dark"><?= (int)($metrics['total'] ?? 0) ?></h3>
              <span class="text-xs text-muted">All-time historical log</span>
            </div>
            <div class="rounded-3 p-3 bg-secondary-subtle text-secondary fs-3">
              <i class="fa-solid fa-clipboard-list"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
  </div>

  <!-- Filters & Search Bar -->
  <div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
      <form method="GET" action="index.php" class="row g-2 align-items-center">
        <div class="col-12 col-md-4">
          <div class="input-group">
            <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
            <input type="text" name="search" class="form-control border-start-0" placeholder="Search by Req No, Item, Employee..." value="<?= e($search_query) ?>">
          </div>
        </div>
        <div class="col-6 col-md-3">
          <select name="status" class="form-select" onchange="this.form.submit()">
            <option value="">All Statuses</option>
            <option value="Pending" <?= ($status_filter === 'Pending') ? 'selected' : '' ?>>Pending Approval</option>
            <option value="Approved" <?= ($status_filter === 'Approved') ? 'selected' : '' ?>>Approved</option>
            <option value="Issued" <?= ($status_filter === 'Issued') ? 'selected' : '' ?>>Issued</option>
            <option value="Rejected" <?= ($status_filter === 'Rejected') ? 'selected' : '' ?>>Rejected</option>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <select name="priority" class="form-select" onchange="this.form.submit()">
            <option value="">All Priorities</option>
            <option value="Normal" <?= ($priority_filter === 'Normal') ? 'selected' : '' ?>>Normal</option>
            <option value="Urgent" <?= ($priority_filter === 'Urgent') ? 'selected' : '' ?>>Urgent</option>
            <option value="Critical" <?= ($priority_filter === 'Critical') ? 'selected' : '' ?>>Critical</option>
          </select>
        </div>
        <div class="col-12 col-md-2 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-grow-1">Filter</button>
          <a href="index.php" class="btn btn-light border" title="Reset Filters"><i class="fa-solid fa-rotate-right"></i></a>
        </div>
      </form>
    </div>
  </div>

  <!-- Requisitions Table -->
  <div class="card border-0 shadow-sm">
    <div class="table-responsive">
      <table class="table align-middle table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Requisition #</th>
            <th>Employee & Dept</th>
            <th>Requested Item</th>
            <th class="text-center">Req / Appr Qty</th>
            <th class="text-center">Priority</th>
            <th class="text-center">Status</th>
            <th class="text-end pe-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($requisitions)): ?>
            <tr>
              <td colspan="7" class="text-center py-5 text-muted">
                <i class="fa-solid fa-clipboard-check fs-1 text-secondary opacity-50 mb-3 d-block"></i>
                <h6 class="fw-semibold">No requisitions found</h6>
                <p class="small text-muted mb-3">There are no material requisition requests matching your active filter criteria.</p>
                <a href="add.php" class="btn btn-sm btn-primary">Create New Requisition</a>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($requisitions as $req): ?>
              <tr>
                <td>
                  <span class="fw-bold font-monospace text-primary"><?= e($req['requisition_no']) ?></span>
                  <div class="text-xs text-muted"><?= format_date($req['created_at'], true) ?></div>
                  <?php if (!empty($req['purpose'])): ?>
                    <div class="text-xs text-secondary mt-1" style="max-width:260px;" title="<?= e($req['purpose']) ?>">
                      <i class="fa-solid fa-quote-left opacity-50 me-1"></i><?= e(mb_strimwidth($req['purpose'], 0, 45, '...')) ?>
                    </div>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="fw-semibold text-dark"><?= e($req['employee_name']) ?></div>
                  <div class="text-xs text-muted"><?= e($req['department_name']) ?> &bull; <span class="badge bg-light text-dark border"><?= e($req['employee_code']) ?></span></div>
                </td>
                <td>
                  <div class="fw-semibold text-dark"><?= e($req['item_name']) ?></div>
                  <div class="text-xs text-muted">
                    <span class="font-monospace"><?= e($req['item_code']) ?></span> &bull; 
                    Location: <?= e($req['location']) ?> (<?= e($req['rack_no']) ?>)
                  </div>
                  <div class="text-xs mt-0.5">
                    Current Store Stock: 
                    <?php if ($req['current_stock'] <= 0): ?>
                      <span class="badge bg-danger">0 <?= e($req['unit']) ?> (Out of stock)</span>
                    <?php elseif ($req['current_stock'] < $req['requested_qty']): ?>
                      <span class="badge bg-warning text-dark"><?= $req['current_stock'] ?> <?= e($req['unit']) ?> (Low)</span>
                    <?php else: ?>
                      <span class="badge bg-success-subtle text-success"><?= $req['current_stock'] ?> <?= e($req['unit']) ?> In Stock</span>
                    <?php endif; ?>
                  </div>
                </td>
                <td class="text-center">
                  <div class="fs-6 fw-bold"><?= (int)$req['requested_qty'] ?> <span class="text-xs text-muted fw-normal"><?= e($req['unit']) ?></span></div>
                  <?php if ($req['status'] === 'Approved' || $req['status'] === 'Issued'): ?>
                    <div class="text-xs text-success fw-semibold">Appr: <?= (int)$req['approved_qty'] ?> <?= e($req['unit']) ?></div>
                  <?php endif; ?>
                </td>
                <td class="text-center">
                  <?= get_priority_badge($req['priority']) ?>
                </td>
                <td class="text-center">
                  <?= get_requisition_status_badge($req['status']) ?>
                  <?php if ($req['status'] === 'Approved' && !empty($req['approved_by_name'])): ?>
                    <div class="text-xs text-muted mt-1">by <?= e($req['approved_by_name']) ?></div>
                  <?php elseif ($req['status'] === 'Rejected' && !empty($req['rejection_reason'])): ?>
                    <div class="text-xs text-danger mt-1" title="<?= e($req['rejection_reason']) ?>">
                      <i class="fa-solid fa-circle-info me-1"></i><?= e(mb_strimwidth($req['rejection_reason'], 0, 30, '...')) ?>
                    </div>
                  <?php endif; ?>
                </td>
                <td class="text-end pe-3">
                  <div class="btn-group">
                    <?php if ($req['status'] === 'Pending'): ?>
                      <?php if ($is_manager_or_admin): ?>
                        <button type="button" class="btn btn-sm btn-success" 
                                data-bs-toggle="modal" 
                                data-bs-target="#approvalModal"
                                data-id="<?= $req['id'] ?>"
                                data-reqno="<?= e($req['requisition_no']) ?>"
                                data-item="<?= e($req['item_name']) ?>"
                                data-qty="<?= (int)$req['requested_qty'] ?>"
                                data-stock="<?= (int)$req['current_stock'] ?>"
                                data-unit="<?= e($req['unit']) ?>"
                                data-emp="<?= e($req['employee_name']) ?>"
                                title="Manager Approval">
                          <i class="fa-solid fa-check me-1"></i>Approve / Reject
                        </button>
                      <?php else: ?>
                        <span class="badge bg-secondary-subtle text-secondary py-2 px-2">Awaiting Manager</span>
                      <?php endif; ?>
                    <?php elseif ($req['status'] === 'Approved'): ?>
                      <form method="POST" action="index.php" onsubmit="return confirm('Confirm issuing <?= (int)$req['approved_qty'] ?> units of <?= e($req['item_name']) ?> to <?= e($req['employee_name']) ?>? This will deduct physical inventory.')">
                        <input type="hidden" name="csrf_token" value="<?= e(get_csrf_token()) ?>">
                        <input type="hidden" name="action" value="issue">
                        <input type="hidden" name="requisition_id" value="<?= $req['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-primary shadow-sm" <?= ($req['current_stock'] < $req['approved_qty']) ? 'disabled title="Insufficient stock in store room"' : '' ?>>
                          <i class="fa-solid fa-box-open me-1"></i>Issue Stock
                        </button>
                      </form>
                    <?php elseif ($req['status'] === 'Issued'): ?>
                      <a href="../slips/issue-slip.php?txn_id=<?= (int)$req['stock_transaction_id'] ?>" class="btn btn-sm btn-outline-primary" title="Print Issue Slip" target="_blank">
                        <i class="fa-solid fa-print me-1"></i>Slip
                      </a>
                      <a href="../slips/gate-pass.php?txn_id=<?= (int)$req['stock_transaction_id'] ?>" class="btn btn-sm btn-outline-secondary" title="Print Material Gate Pass" target="_blank">
                        <i class="fa-solid fa-door-open me-1"></i>Pass
                      </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Manager Approval / Rejection Modal -->
<div class="modal fade" id="approvalModal" tabindex="-1" aria-labelledby="approvalModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-light">
        <h5 class="modal-title fw-bold" id="approvalModalLabel">
          <i class="fa-solid fa-signature text-primary me-2"></i>Manager Requisition Review
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="index.php" id="approvalForm">
        <input type="hidden" name="csrf_token" value="<?= e(get_csrf_token()) ?>">
        <input type="hidden" name="requisition_id" id="modal_req_id" value="">
        <input type="hidden" name="action" id="modal_action" value="approve">

        <div class="modal-body p-4">
          <div class="alert alert-light border d-flex gap-3 mb-3">
            <div class="fs-3 text-primary"><i class="fa-solid fa-box-archive"></i></div>
            <div>
              <div class="fw-bold text-dark" id="modal_item_name">Item Name</div>
              <div class="text-xs text-muted">Requisition: <span id="modal_req_no" class="fw-semibold"></span></div>
              <div class="text-xs text-muted">Requested By: <span id="modal_emp" class="fw-semibold"></span></div>
              <div class="text-xs text-muted">Store Available Stock: <span id="modal_stock" class="badge bg-success"></span></div>
            </div>
          </div>

          <div id="approve_fields">
            <div class="mb-3">
              <label class="form-label fw-semibold">Authorize Approved Quantity <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="number" name="approved_qty" id="modal_approved_qty" class="form-control form-control-lg fw-bold text-primary" min="1" required>
                <span class="input-group-text bg-light fw-semibold" id="modal_unit">Units</span>
              </div>
              <div class="form-text small">You may approve full or partial quantity based on stock policy.</div>
            </div>
          </div>

          <div id="reject_fields" style="display:none;">
            <div class="mb-3">
              <label class="form-label fw-semibold text-danger">Rejection Reason <span class="text-danger">*</span></label>
              <textarea name="rejection_reason" id="modal_rejection_reason" class="form-control" rows="3" placeholder="Explain why this request is rejected (e.g. Budget restriction, out of policy, obsolete requirement)..."></textarea>
            </div>
          </div>
        </div>

        <div class="modal-footer bg-light justify-content-between">
          <button type="button" class="btn btn-outline-danger" id="btnShowReject">
            <i class="fa-solid fa-times me-1"></i>Reject Request
          </button>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-success" id="btnSubmitApproval">
              <i class="fa-solid fa-check-double me-1"></i>Approve Requisition
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const approvalModal = document.getElementById('approvalModal');
  if (approvalModal) {
    approvalModal.addEventListener('show.bs.modal', function(event) {
      const button = event.relatedTarget;
      const id = button.getAttribute('data-id');
      const reqNo = button.getAttribute('data-reqno');
      const item = button.getAttribute('data-item');
      const qty = button.getAttribute('data-qty');
      const stock = button.getAttribute('data-stock');
      const unit = button.getAttribute('data-unit');
      const emp = button.getAttribute('data-emp');

      document.getElementById('modal_req_id').value = id;
      document.getElementById('modal_req_no').textContent = reqNo;
      document.getElementById('modal_item_name').textContent = item;
      document.getElementById('modal_emp').textContent = emp;
      document.getElementById('modal_approved_qty').value = qty;
      document.getElementById('modal_stock').textContent = stock + ' ' + unit;
      document.getElementById('modal_unit').textContent = unit;

      // Reset to approve mode
      document.getElementById('modal_action').value = 'approve';
      document.getElementById('approve_fields').style.display = 'block';
      document.getElementById('reject_fields').style.display = 'none';
      document.getElementById('btnShowReject').style.display = 'inline-block';
      document.getElementById('btnSubmitApproval').className = 'btn btn-success';
      document.getElementById('btnSubmitApproval').innerHTML = '<i class="fa-solid fa-check-double me-1"></i>Approve Requisition';
    });
  }

  const btnShowReject = document.getElementById('btnShowReject');
  if (btnShowReject) {
    btnShowReject.addEventListener('click', function() {
      const isRejecting = document.getElementById('modal_action').value === 'reject';
      if (!isRejecting) {
        document.getElementById('modal_action').value = 'reject';
        document.getElementById('approve_fields').style.display = 'none';
        document.getElementById('reject_fields').style.display = 'block';
        document.getElementById('modal_rejection_reason').required = true;
        this.innerHTML = '<i class="fa-solid fa-arrow-left me-1"></i>Back to Approval';
        document.getElementById('btnSubmitApproval').className = 'btn btn-danger';
        document.getElementById('btnSubmitApproval').innerHTML = '<i class="fa-solid fa-ban me-1"></i>Confirm Rejection';
      } else {
        document.getElementById('modal_action').value = 'approve';
        document.getElementById('approve_fields').style.display = 'block';
        document.getElementById('reject_fields').style.display = 'none';
        document.getElementById('modal_rejection_reason').required = false;
        this.innerHTML = '<i class="fa-solid fa-times me-1"></i>Reject Request';
        document.getElementById('btnSubmitApproval').className = 'btn btn-success';
        document.getElementById('btnSubmitApproval').innerHTML = '<i class="fa-solid fa-check-double me-1"></i>Approve Requisition';
      }
    });
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
