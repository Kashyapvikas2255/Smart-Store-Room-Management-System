<?php
/**
 * Smart Store Room Management System
 * Official Material Gate Pass (Outward Movement Authorization)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$db = Database::getConnection();
$txn_id = (int)($_GET['txn_id'] ?? 0);

if ($txn_id <= 0) {
    die('Invalid Transaction ID.');
}

// Fetch transaction details
$stmt = $db->prepare("
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        i.location,
        i.rack_no,
        c.category_name,
        e.employee_name,
        e.employee_code,
        e.designation,
        d.department_name,
        u.name as authorized_by_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    LEFT JOIN users u ON st.created_by = u.id
    WHERE st.id = ?
");
$stmt->execute([$txn_id]);
$txn = $stmt->fetch();

if (!$txn) {
    die('Stock transaction record not found.');
}

$gate_pass_no = 'GP-' . str_replace('TXN-', '', $txn['transaction_code']);
$pass_type = trim($_GET['type'] ?? 'Non-Returnable');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Material Gate Pass - <?= e($gate_pass_no) ?></title>
  <!-- Bootstrap 5.3 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body {
      background-color: #f1f5f9;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #0f172a;
    }
    .gatepass-container {
      max-width: 820px;
      margin: 30px auto;
      background: #ffffff;
      padding: 35px;
      border-radius: 8px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
      border: 2px solid #334155;
    }
    .gatepass-header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 15px;
      margin-bottom: 20px;
    }
    .badge-gate {
      background: #0f172a;
      color: #ffffff;
      font-size: 14px;
      font-weight: 700;
      padding: 5px 14px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .security-box {
      border: 1px dashed #64748b;
      padding: 15px;
      background: #f8fafc;
      border-radius: 6px;
    }
    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .gatepass-container {
        box-shadow: none;
        border: 2px solid #000000;
        padding: 20px;
        margin: 0;
        max-width: 100%;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <!-- Top Action Bar (hidden on print) -->
  <div class="d-flex justify-content-between align-items-center mb-3 no-print" style="max-width:820px;margin:20px auto 0;">
    <a href="issue-slip.php?txn_id=<?= $txn_id ?>" class="btn btn-outline-secondary">
      <i class="fa-solid fa-arrow-left me-1"></i>Back to Issue Slip
    </a>
    <div class="d-flex gap-2">
      <button type="button" class="btn btn-dark" onclick="window.print()">
        <i class="fa-solid fa-print me-1"></i>Print Gate Pass
      </button>
    </div>
  </div>

  <div class="gatepass-container">
    <!-- Header -->
    <div class="gatepass-header d-flex justify-content-between align-items-center">
      <div>
        <h4 class="fw-bold mb-0 text-uppercase tracking-wider">SMART STORE ROOM MANAGEMENT</h4>
        <div class="text-sm text-muted">SECURITY & DISPATCH DIVISION &bull; MAIN WAREHOUSE</div>
      </div>
      <div class="text-end">
        <div class="badge-gate mb-1">MATERIAL GATE PASS</div>
        <div class="fw-bold text-danger text-sm">[ <?= strtoupper($pass_type) ?> ]</div>
      </div>
    </div>

    <!-- Meta Details Grid -->
    <div class="row g-3 mb-3 border p-2 bg-light text-sm">
      <div class="col-4">
        <span class="text-muted text-xs d-block">GATE PASS NUMBER:</span>
        <strong class="font-monospace fs-6 text-primary"><?= e($gate_pass_no) ?></strong>
      </div>
      <div class="col-4">
        <span class="text-muted text-xs d-block">ISSUE DATE & TIME:</span>
        <strong><?= format_date($txn['transaction_date']) ?></strong>
      </div>
      <div class="col-4">
        <span class="text-muted text-xs d-block">LINKED TXN REFERENCE:</span>
        <strong class="font-monospace"><?= e($txn['transaction_code']) ?></strong>
      </div>
    </div>

    <!-- Bearer / Person Carrying Material -->
    <div class="card border mb-3">
      <div class="card-header bg-light py-1.5 fw-bold text-xs text-uppercase">
        <i class="fa-solid fa-user me-1"></i>Authorized Bearer / Carrier Details
      </div>
      <div class="card-body p-3">
        <div class="row g-2 text-sm">
          <div class="col-sm-6">
            <span class="text-muted text-xs">Name:</span>
            <div class="fw-bold text-dark"><?= e($txn['employee_name'] ?? 'Authorized Carrier') ?></div>
          </div>
          <div class="col-sm-3">
            <span class="text-muted text-xs">Employee Code:</span>
            <div><?= e($txn['employee_code'] ?? 'N/A') ?></div>
          </div>
          <div class="col-sm-3">
            <span class="text-muted text-xs">Department:</span>
            <div class="fw-semibold"><?= e($txn['department_name'] ?? 'General') ?></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Materials Table -->
    <div class="table-responsive mb-3">
      <table class="table table-bordered align-middle mb-0">
        <thead class="table-dark text-xs text-uppercase">
          <tr>
            <th class="text-center" style="width: 40px;">#</th>
            <th>Item Description</th>
            <th class="text-center">Code</th>
            <th class="text-center">Quantity</th>
            <th class="text-center">Unit</th>
            <th>Purpose / Destination Site</th>
          </tr>
        </thead>
        <tbody class="text-sm">
          <tr>
            <td class="text-center fw-bold">1</td>
            <td class="fw-semibold"><?= e($txn['item_name']) ?></td>
            <td class="text-center font-monospace text-xs"><?= e($txn['item_code']) ?></td>
            <td class="text-center fs-6 fw-bold text-primary"><?= (int)$txn['quantity'] ?></td>
            <td class="text-center"><?= e($txn['unit']) ?></td>
            <td><?= e($txn['remarks'] ?: 'Departmental Usage') ?></td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Security Check Section -->
    <div class="security-box mb-4">
      <div class="fw-bold text-xs text-uppercase text-muted mb-2">
        <i class="fa-solid fa-shield-halved me-1 text-primary"></i>Main Security Gate Verification & Exit Log
      </div>
      <div class="row g-3 text-xs">
        <div class="col-4">
          <span class="text-muted d-block">Time of Gate Outward:</span>
          <div class="border-bottom pb-1 mt-1 text-dark fw-bold">______ : ______ AM / PM</div>
        </div>
        <div class="col-4">
          <span class="text-muted d-block">Security Guard on Duty:</span>
          <div class="border-bottom pb-1 mt-1">___________________________</div>
        </div>
        <div class="col-4">
          <span class="text-muted d-block">Security Verification Signature:</span>
          <div class="border-bottom pb-1 mt-1">___________________________</div>
        </div>
      </div>
    </div>

    <!-- Signatures -->
    <div class="row g-4 text-center mt-3 pt-2">
      <div class="col-4">
        <div class="border-top pt-2">
          <div class="fw-bold text-sm"><?= e($txn['authorized_by_name'] ?? 'Store Keeper') ?></div>
          <div class="text-xs text-muted">Store In-Charge / Issuer</div>
        </div>
      </div>
      <div class="col-4">
        <div class="border-top pt-2">
          <div class="fw-bold text-sm"><?= e($txn['employee_name'] ?? 'Bearer') ?></div>
          <div class="text-xs text-muted">Material Bearer Signature</div>
        </div>
      </div>
      <div class="col-4">
        <div class="border-top pt-2">
          <div class="fw-bold text-sm">Main Gate Security</div>
          <div class="text-xs text-muted">Outward Clearance Stamp</div>
        </div>
      </div>
    </div>

  </div>
</div>

</body>
</html>
