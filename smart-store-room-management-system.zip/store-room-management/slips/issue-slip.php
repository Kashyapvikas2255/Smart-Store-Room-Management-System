<?php
/**
 * Smart Store Room Management System
 * Digital Material Issue Slip / Store Voucher
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$db = Database::getConnection();
$txn_id = (int)($_GET['txn_id'] ?? 0);

if ($txn_id <= 0) {
    die('Invalid Transaction ID.');
}

// Fetch transaction details
$stmt = $db->prepare("
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        i.location,
        i.rack_no,
        c.category_name,
        e.employee_name,
        e.employee_code,
        e.designation,
        e.phone as employee_phone,
        d.department_name,
        u.name as issued_by_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    JOIN categories c ON i.category_id = c.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    LEFT JOIN users u ON st.created_by = u.id
    WHERE st.id = ?
");
$stmt->execute([$txn_id]);
$txn = $stmt->fetch();

if (!$txn) {
    die('Stock transaction record not found.');
}

$total_value = (float)$txn['unit_price'] * (int)$txn['quantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Material Issue Slip - <?= e($txn['transaction_code']) ?></title>
  <!-- Bootstrap 5.3 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body {
      background-color: #f8fafc;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #1e293b;
    }
    .slip-container {
      max-width: 800px;
      margin: 30px auto;
      background: #ffffff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      border: 1px solid #e2e8f0;
    }
    .slip-header {
      border-bottom: 2px solid #0284c7;
      padding-bottom: 20px;
      margin-bottom: 25px;
    }
    .company-title {
      font-size: 24px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .slip-badge {
      background-color: #f0fdf4;
      color: #166534;
      border: 1px solid #bbf7d0;
      font-size: 13px;
      font-weight: 700;
      padding: 4px 12px;
      border-radius: 20px;
      text-transform: uppercase;
    }
    .info-table th {
      background-color: #f8fafc;
      color: #64748b;
      font-weight: 600;
      font-size: 12px;
      text-transform: uppercase;
      width: 25%;
    }
    .info-table td {
      font-size: 14px;
      font-weight: 500;
    }
    .signature-box {
      margin-top: 60px;
      padding-top: 15px;
      border-top: 1px dashed #94a3b8;
      text-align: center;
    }
    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .slip-container {
        box-shadow: none;
        border: none;
        padding: 0;
        margin: 0;
        max-width: 100%;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <!-- Top Action Bar (hidden on print) -->
  <div class="d-flex justify-content-between align-items-center mb-3 no-print" style="max-width:800px;margin:20px auto 0;">
    <a href="../stock/history.php" class="btn btn-outline-secondary">
      <i class="fa-solid fa-arrow-left me-1"></i>Back to Transactions
    </a>
    <div class="d-flex gap-2">
      <a href="gate-pass.php?txn_id=<?= $txn_id ?>" class="btn btn-outline-primary">
        <i class="fa-solid fa-door-open me-1"></i>Generate Gate Pass
      </a>
      <button type="button" class="btn btn-primary" onclick="window.print()">
        <i class="fa-solid fa-print me-1"></i>Print Slip / Save PDF
      </button>
    </div>
  </div>

  <div class="slip-container">
    <!-- Header -->
    <div class="slip-header d-flex justify-content-between align-items-start">
      <div>
        <div class="d-flex align-items-center gap-2 mb-1">
          <i class="fa-solid fa-boxes-stacked text-primary fs-3"></i>
          <span class="company-title">SMART STORE ROOM MANAGEMENT</span>
        </div>
        <p class="text-muted small mb-0">Central Warehouse & Inventory Depot &bull; Internal Material Transfer</p>
        <p class="text-muted text-xs mb-0">Location: Main Facility Depot, Building 4 &bull; Contact: store@company.org</p>
      </div>
      <div class="text-end">
        <div class="slip-badge mb-2"><i class="fa-solid fa-check-circle me-1"></i>Material Issue Slip</div>
        <div class="font-monospace fw-bold fs-6 text-dark"><?= e($txn['transaction_code']) ?></div>
        <div class="text-xs text-muted">Date: <?= format_date($txn['transaction_date']) ?></div>
      </div>
    </div>

    <!-- Recipient & Reference Meta -->
    <div class="row g-3 mb-4">
      <div class="col-6">
        <div class="p-3 bg-light rounded-3 border">
          <span class="text-xs text-uppercase fw-bold text-muted d-block mb-2">Issued To (Recipient)</span>
          <div class="fw-bold fs-6 text-dark"><?= e($txn['employee_name'] ?? 'General Department Issue') ?></div>
          <div class="text-sm text-secondary">
            <?= e($txn['designation'] ?? '') ?> <?= !empty($txn['employee_code']) ? '(' . e($txn['employee_code']) . ')' : '' ?>
          </div>
          <div class="text-sm text-secondary">
            <i class="fa-solid fa-sitemap me-1 text-muted"></i>Department: <strong class="text-dark"><?= e($txn['department_name'] ?? 'General') ?></strong>
          </div>
          <?php if (!empty($txn['employee_phone'])): ?>
            <div class="text-xs text-muted mt-1"><i class="fa-solid fa-phone me-1"></i><?= e($txn['employee_phone']) ?></div>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-6">
        <div class="p-3 bg-light rounded-3 border">
          <span class="text-xs text-uppercase fw-bold text-muted d-block mb-2">Issuance Reference Details</span>
          <div class="text-sm mb-1">
            <span class="text-muted">Reference / Req No:</span> 
            <strong class="font-monospace text-primary"><?= e($txn['reference_no'] ?: 'N/A') ?></strong>
          </div>
          <div class="text-sm mb-1">
            <span class="text-muted">Issued By:</span> 
            <strong><?= e($txn['issued_by_name'] ?? 'Store Staff') ?></strong>
          </div>
          <div class="text-sm">
            <span class="text-muted">Issuing Depot:</span> 
            <span><?= e($txn['location']) ?> (Rack <?= e($txn['rack_no']) ?>)</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Items Table -->
    <div class="table-responsive mb-4">
      <table class="table table-bordered align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th style="width: 50px;" class="text-center">#</th>
            <th>Item Code & Description</th>
            <th class="text-center">Category</th>
            <th class="text-center">Qty Issued</th>
            <th class="text-end">Unit Price</th>
            <th class="text-end">Total Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="text-center fw-bold">1</td>
            <td>
              <div class="fw-bold text-dark"><?= e($txn['item_name']) ?></div>
              <div class="text-xs text-muted">Item Code: <span class="font-monospace"><?= e($txn['item_code']) ?></span></div>
              <div class="text-xs text-muted">Storage: <?= e($txn['location']) ?> &bull; Rack <?= e($txn['rack_no']) ?></div>
            </td>
            <td class="text-center text-sm"><?= e($txn['category_name']) ?></td>
            <td class="text-center">
              <span class="fs-5 fw-bold text-primary"><?= (int)$txn['quantity'] ?></span>
              <span class="text-xs text-muted d-block"><?= e($txn['unit']) ?></span>
            </td>
            <td class="text-end font-monospace"><?= format_currency($txn['unit_price']) ?></td>
            <td class="text-end font-monospace fw-bold"><?= format_currency($total_value) ?></td>
          </tr>
        </tbody>
        <tfoot class="table-light">
          <tr>
            <td colspan="3" class="text-end fw-bold">Grand Total:</td>
            <td class="text-center fw-bold fs-6 text-primary"><?= (int)$txn['quantity'] ?> <?= e($txn['unit']) ?></td>
            <td></td>
            <td class="text-end font-monospace fw-bold text-success fs-6"><?= format_currency($total_value) ?></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- Purpose / Remarks -->
    <?php if (!empty($txn['remarks'])): ?>
      <div class="p-3 bg-light rounded-3 border mb-4">
        <span class="text-xs text-uppercase fw-bold text-muted d-block mb-1">Purpose / Issue Notes</span>
        <div class="text-sm text-dark fst-italic">"<?= e($txn['remarks']) ?>"</div>
      </div>
    <?php endif; ?>

    <!-- Terms & Dual Signatures -->
    <div class="mt-4 pt-3">
      <div class="row g-4 text-center">
        <div class="col-4">
          <div class="signature-box">
            <div class="fw-bold text-dark"><?= e($txn['issued_by_name'] ?? 'Store Keeper') ?></div>
            <div class="text-xs text-muted">Issued By (Store Keeper)</div>
            <div class="text-xs text-muted mt-1"><?= format_date($txn['transaction_date']) ?></div>
          </div>
        </div>

        <div class="col-4">
          <div class="signature-box">
            <div class="fw-bold text-dark"><?= e($txn['employee_name'] ?? 'Authorized Receiver') ?></div>
            <div class="text-xs text-muted">Received By (Employee Signature)</div>
            <div class="text-xs text-muted mt-1">Date: ____________________</div>
          </div>
        </div>

        <div class="col-4">
          <div class="signature-box">
            <div class="fw-bold text-dark">Store Manager</div>
            <div class="text-xs text-muted">Authorized Authorization Sign</div>
            <div class="text-xs text-muted mt-1">Official Depot Stamp</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer Note -->
    <div class="text-center text-xs text-muted mt-5 pt-4 border-top">
      This is an official computer-generated Store Room Issue Slip. Please retain a copy for inventory auditing and departmental asset reconciliation.
    </div>
  </div>
</div>

</body>
</html>
