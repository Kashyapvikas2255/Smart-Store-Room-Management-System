<?php
/**
 * Smart Store Room Management System
 * Stock Adjustment & Physical Inventory Audit Reconciliations
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Stock Adjustment';
$db = Database::getConnection();
$error = '';

$preselected_item_id = (int)($_GET['item_id'] ?? 0);

// Fetch active items
$items = $db->query("
    SELECT id, item_code, item_name, current_stock, unit, purchase_price 
    FROM items 
    WHERE status = 'Active' 
    ORDER BY item_name ASC
")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = (int)($_POST['item_id'] ?? 0);
    $physical_stock = (int)($_POST['physical_stock'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Audit Correction');
    $adjustment_date = trim($_POST['adjustment_date'] ?? date('Y-m-d'));
    $remarks = trim($_POST['remarks'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification token expired.";
    } elseif (empty($item_id)) {
        $error = "Please select an item to adjust.";
    } elseif ($physical_stock < 0) {
        $error = "Physical stock count cannot be negative.";
    } else {
        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT id, item_name, current_stock, unit, purchase_price FROM items WHERE id = :id FOR UPDATE");
            $stmt->execute([':id' => $item_id]);
            $item = $stmt->fetch();

            if (!$item) {
                throw new Exception("Selected item does not exist.");
            }

            $system_stock = (int)$item['current_stock'];
            $difference = $physical_stock - $system_stock;

            if ($difference === 0) {
                throw new Exception("Physical counted stock is identical to system stock ({$system_stock} {$item['unit']}). No adjustment necessary.");
            }

            // 1. Update item current stock
            $upd = $db->prepare("UPDATE items SET current_stock = :physical_stock WHERE id = :id");
            $upd->execute([':physical_stock' => $physical_stock, ':id' => $item_id]);

            // 2. Insert into stock_adjustments table
            $ins_adj = $db->prepare("
                INSERT INTO stock_adjustments (
                    item_id, system_stock, physical_stock, difference,
                    reason, remarks, adjusted_by, adjustment_date
                ) VALUES (
                    :item_id, :system_stock, :physical_stock, :diff,
                    :reason, :remarks, :adjusted_by, :adj_date
                )
            ");
            $ins_adj->execute([
                ':item_id' => $item_id,
                ':system_stock' => $system_stock,
                ':physical_stock' => $physical_stock,
                ':diff' => $difference,
                ':reason' => $reason,
                ':remarks' => $remarks,
                ':adjusted_by' => $_SESSION['user_id'],
                ':adj_date' => $adjustment_date
            ]);

            // 3. Insert audit entry into stock_transactions table
            $txn_code = generate_transaction_code($db, 'ADJ');
            $diff_abs = abs($difference);
            $adj_notes = "[Audit Adjustment: {$reason}] System: {$system_stock}, Counted: {$physical_stock}, Variance: " . ($difference > 0 ? "+{$difference}" : $difference) . ". " . $remarks;

            $ins_txn = $db->prepare("
                INSERT INTO stock_transactions (
                    transaction_code, item_id, transaction_type, quantity,
                    previous_stock, new_stock, unit_price, reference_no,
                    remarks, transaction_date, created_by
                ) VALUES (
                    :txn_code, :item_id, 'ADJUSTMENT', :quantity,
                    :prev_stock, :new_stock, :unit_price, 'AUDIT-RECON',
                    :remarks, :txn_date, :created_by
                )
            ");
            $ins_txn->execute([
                ':txn_code' => $txn_code,
                ':item_id' => $item_id,
                ':quantity' => $diff_abs,
                ':prev_stock' => $system_stock,
                ':new_stock' => $physical_stock,
                ':unit_price' => $item['purchase_price'],
                ':remarks' => $adj_notes,
                ':txn_date' => $adjustment_date,
                ':created_by' => $_SESSION['user_id']
            ]);

            $db->commit();

            $sign = $difference > 0 ? "+{$difference}" : "{$difference}";
            set_flash('success', "Stock adjusted successfully! '{$item['item_name']}' reconciled from {$system_stock} to {$physical_stock} {$item['unit']} (Variance: {$sign}).");
            header("Location: history.php");
            exit;
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Stock Adjustment & Physical Audit</h3>
        <p class="text-muted small mb-0">Reconcile differences between system balances and physical shelf counts.</p>
      </div>
      <a href="history.php" class="btn btn-outline-secondary">
        <i class="fa-solid fa-clock-rotate-left me-1"></i> View History
      </a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="adjustment.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-md-6">
            <label for="adjustment_date" class="form-label">Audit / Reconciliation Date <span class="text-danger">*</span></label>
            <input type="date" class="form-control" id="adjustment_date" name="adjustment_date" value="<?= date('Y-m-d') ?>" required>
          </div>

          <div class="col-md-6">
            <label for="reason" class="form-label">Reason for Variance <span class="text-danger">*</span></label>
            <select class="form-select" id="reason" name="reason" required>
              <option value="Audit Correction">Routine Physical Audit Correction</option>
              <option value="Damaged Goods">Damaged Goods Found on Shelf</option>
              <option value="Expired Items">Expired / Past Shelf-Life Discard</option>
              <option value="Counting Error">Previous Counting / Entry Error</option>
              <option value="Lost or Stolen">Missing / Lost / Shrinkage</option>
              <option value="Found Unregistered">Unregistered Stock Discovered</option>
            </select>
          </div>

          <div class="col-12">
            <label for="item_id" class="form-label">Item / SKU to Reconcile <span class="text-danger">*</span></label>
            <select class="form-select" id="item_id" name="item_id" required>
              <option value="">-- Select Item to Reconcile --</option>
              <?php foreach ($items as $it): ?>
                <option value="<?= $it['id'] ?>" 
                  data-stock="<?= $it['current_stock'] ?>" 
                  data-unit="<?= e($it['unit']) ?>"
                  <?= ($preselected_item_id == $it['id']) ? 'selected' : '' ?>>
                  <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?> (Current: <?= $it['current_stock'] ?> <?= e($it['unit']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Comparison Metrics Widget -->
          <div class="col-12">
            <div class="card bg-light border-0 p-3 rounded-3">
              <div class="row text-center g-2">
                <div class="col-4 border-end">
                  <span class="text-muted small d-block">System Stock (Current)</span>
                  <strong class="fs-4 text-dark" id="disp_system_stock">0</strong>
                  <span class="text-muted small" id="disp_unit_1">units</span>
                </div>
                <div class="col-4 border-end">
                  <span class="text-muted small d-block">Counted (Physical)</span>
                  <strong class="fs-4 text-primary" id="disp_physical_stock">0</strong>
                  <span class="text-muted small" id="disp_unit_2">units</span>
                </div>
                <div class="col-4">
                  <span class="text-muted small d-block">Variance Difference</span>
                  <strong class="fs-4" id="disp_diff">0</strong>
                  <span class="text-muted small d-block" id="disp_diff_desc">Balanced</span>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <label for="physical_stock" class="form-label">Actual Physical Counted Stock <span class="text-danger">*</span></label>
            <input type="number" class="form-control form-control-lg fw-bold" id="physical_stock" name="physical_stock" min="0" placeholder="0" required>
            <div class="form-text">Enter the physical quantity counted during the stock-take.</div>
          </div>

          <div class="col-md-6">
            <label for="remarks" class="form-label">Audit Notes & Observations</label>
            <textarea class="form-control" id="remarks" name="remarks" rows="2" placeholder="Audited by warehouse supervisor, bay location verified..."></textarea>
          </div>
        </div>
      </div>

      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
        <a href="history.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" id="submit_btn" class="btn btn-warning text-dark px-4 fw-bold">
          <i class="fa-solid fa-sliders me-2"></i> Apply Stock Adjustment
        </button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const itemSelect = document.getElementById('item_id');
  const physicalInput = document.getElementById('physical_stock');
  const sysSpan = document.getElementById('disp_system_stock');
  const phySpan = document.getElementById('disp_physical_stock');
  const diffSpan = document.getElementById('disp_diff');
  const diffDesc = document.getElementById('disp_diff_desc');
  const unit1 = document.getElementById('disp_unit_1');
  const unit2 = document.getElementById('disp_unit_2');
  const submitBtn = document.getElementById('submit_btn');

  function calculateDiff() {
    const selected = itemSelect.options[itemSelect.selectedIndex];
    if (selected && selected.value) {
      const sysStock = parseInt(selected.getAttribute('data-stock') || '0', 10);
      const unit = selected.getAttribute('data-unit') || 'units';
      const phyStock = parseInt(physicalInput.value || '0', 10);
      const diff = phyStock - sysStock;

      sysSpan.textContent = sysStock;
      phySpan.textContent = phyStock;
      unit1.textContent = unit;
      unit2.textContent = unit;

      if (diff > 0) {
        diffSpan.textContent = '+' + diff;
        diffSpan.className = 'fs-4 text-success fw-bold';
        diffDesc.textContent = 'Surplus (+ ' + diff + ')';
        submitBtn.disabled = false;
      } else if (diff < 0) {
        diffSpan.textContent = diff;
        diffSpan.className = 'fs-4 text-danger fw-bold';
        diffDesc.textContent = 'Deficit (' + diff + ')';
        submitBtn.disabled = false;
      } else {
        diffSpan.textContent = '0';
        diffSpan.className = 'fs-4 text-muted fw-bold';
        diffDesc.textContent = 'No Variance';
        // Allow user to click, but warning in backend
      }
    } else {
      sysSpan.textContent = '0';
      phySpan.textContent = '0';
      diffSpan.textContent = '0';
      diffDesc.textContent = 'Balanced';
    }
  }

  itemSelect.addEventListener('change', function() {
    const selected = itemSelect.options[itemSelect.selectedIndex];
    if (selected && selected.value) {
      physicalInput.value = selected.getAttribute('data-stock') || '0';
    }
    calculateDiff();
  });

  physicalInput.addEventListener('input', calculateDiff);

  if (itemSelect.value) {
    calculateDiff();
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
