<?php
/**
 * Smart Store Room Management System
 * Transaction History & Audit Trail Ledger
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Transaction History';
$db = Database::getConnection();

// Filters
$type_filter = trim($_GET['type'] ?? '');
$item_id = trim($_GET['item_id'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$search = trim($_GET['search'] ?? '');

// Pagination
$limit = 15;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

$where_clauses = ["1=1"];
$params = [];

if ($type_filter !== '') {
    $where_clauses[] = "st.transaction_type = :type";
    $params[':type'] = $type_filter;
}

if ($item_id !== '') {
    $where_clauses[] = "st.item_id = :item_id";
    $params[':item_id'] = $item_id;
}

if ($date_from !== '') {
    $where_clauses[] = "st.transaction_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if ($date_to !== '') {
    $where_clauses[] = "st.transaction_date <= :date_to";
    $params[':date_to'] = $date_to;
}

if ($search !== '') {
    $where_clauses[] = "(st.transaction_code LIKE :search OR st.reference_no LIKE :search OR i.item_name LIKE :search OR i.item_code LIKE :search OR e.employee_name LIKE :search OR s.supplier_name LIKE :search)";
    $params[':search'] = "%{$search}%";
}

$where_sql = implode(' AND ', $where_clauses);

// CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $exp_sql = "
        SELECT 
            st.transaction_code,
            st.transaction_date,
            st.transaction_type,
            i.item_code,
            i.item_name,
            st.quantity,
            i.unit,
            st.previous_stock,
            st.new_stock,
            COALESCE(e.employee_name, s.supplier_name, 'Internal Store') as counterparty,
            d.department_name,
            st.reference_no,
            st.unit_price,
            (st.quantity * st.unit_price) as total_value,
            u.name as authorized_by,
            st.remarks
        FROM stock_transactions st
        JOIN items i ON st.item_id = i.id
        LEFT JOIN employees e ON st.employee_id = e.id
        LEFT JOIN departments d ON st.department_id = d.id
        LEFT JOIN suppliers s ON st.supplier_id = s.id
        JOIN users u ON st.created_by = u.id
        WHERE {$where_sql}
        ORDER BY st.transaction_date DESC, st.id DESC
    ";
    $exp_stmt = $db->prepare($exp_sql);
    $exp_stmt->execute($params);
    $rows = $exp_stmt->fetchAll();

    $headers = [
        'Txn Code', 'Date', 'Type', 'Item Code', 'Item Name', 'Quantity', 'Unit',
        'Prev Stock', 'New Stock', 'Counterparty', 'Department', 'Reference No',
        'Unit Price', 'Total Value', 'Authorized By', 'Remarks'
    ];
    $export_rows = [];
    foreach ($rows as $r) {
        $export_rows[] = [
            $r['transaction_code'],
            $r['transaction_date'],
            $r['transaction_type'],
            $r['item_code'],
            $r['item_name'],
            $r['quantity'],
            $r['unit'],
            $r['previous_stock'],
            $r['new_stock'],
            $r['counterparty'],
            $r['department_name'] ?? '',
            $r['reference_no'] ?? '',
            $r['unit_price'],
            $r['total_value'],
            $r['authorized_by'],
            $r['remarks'] ?? ''
        ];
    }
    export_to_csv('Transaction_Ledger_' . date('Y-m-d') . '.csv', $headers, $export_rows);
}

// Count
$count_stmt = $db->prepare("
    SELECT COUNT(*) 
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    WHERE {$where_sql}
");
$count_stmt->execute($params);
$total_records = (int)$count_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Records
$sql = "
    SELECT 
        st.*,
        i.item_code,
        i.item_name,
        i.unit,
        e.employee_name,
        e.employee_code,
        d.department_name,
        s.supplier_name,
        u.name as user_name
    FROM stock_transactions st
    JOIN items i ON st.item_id = i.id
    LEFT JOIN employees e ON st.employee_id = e.id
    LEFT JOIN departments d ON st.department_id = d.id
    LEFT JOIN suppliers s ON st.supplier_id = s.id
    JOIN users u ON st.created_by = u.id
    WHERE {$where_sql}
    ORDER BY st.transaction_date DESC, st.id DESC
    LIMIT {$limit} OFFSET {$offset}
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Dropdown items
$all_items = $db->query("SELECT id, item_code, item_name FROM items ORDER BY item_name ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Transaction Ledger & Audit Trail</h3>
    <p class="text-muted mb-0 small">Real-time ledger recording every intake, disbursement, return, and inventory audit.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="history.php?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-outline-success">
      <i class="fa-solid fa-file-excel me-1"></i> Export CSV
    </a>
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="fa-solid fa-print me-1"></i> Print Ledger
    </button>
    <a href="stock-in.php" class="btn btn-success">
      <i class="fa-solid fa-plus me-1"></i> Stock In
    </a>
    <a href="stock-out.php" class="btn btn-danger">
      <i class="fa-solid fa-minus me-1"></i> Stock Out
    </a>
  </div>
</div>

<!-- Filters Bar -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="history.php" class="row g-2 align-items-center">
      <div class="col-md-3">
        <input type="text" name="search" class="form-control" placeholder="Search code, ref, party..." value="<?= e($search) ?>">
      </div>
      <div class="col-md-2">
        <select name="type" class="form-select">
          <option value="">-- All Types --</option>
          <option value="IN" <?= $type_filter === 'IN' ? 'selected' : '' ?>>Stock IN</option>
          <option value="OUT" <?= $type_filter === 'OUT' ? 'selected' : '' ?>>Stock OUT</option>
          <option value="RETURN" <?= $type_filter === 'RETURN' ? 'selected' : '' ?>>Return</option>
          <option value="ADJUSTMENT" <?= $type_filter === 'ADJUSTMENT' ? 'selected' : '' ?>>Adjustment</option>
        </select>
      </div>
      <div class="col-md-3">
        <select name="item_id" class="form-select">
          <option value="">-- All Items --</option>
          <?php foreach ($all_items as $it): ?>
            <option value="<?= $it['id'] ?>" <?= ($item_id == $it['id']) ? 'selected' : '' ?>>
              <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <input type="date" name="date_from" class="form-control" title="From Date" value="<?= e($date_from) ?>" placeholder="From Date">
      </div>
      <div class="col-md-2 d-flex gap-2">
        <button type="submit" class="btn btn-primary-deep flex-grow-1">Filter</button>
        <?php if ($type_filter !== '' || $item_id !== '' || $date_from !== '' || $search !== ''): ?>
          <a href="history.php" class="btn btn-outline-secondary" title="Clear Filters"><i class="fa-solid fa-xmark"></i></a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Txn Code</th>
          <th>Date</th>
          <th>Type</th>
          <th>Item / SKU</th>
          <th>Quantity</th>
          <th>Balance Change</th>
          <th>Entity / Counterparty</th>
          <th>Reference #</th>
          <th>Authorized By</th>
          <th>Remarks</th>
          <th class="text-end pe-3">Slip / Pass</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($transactions)): ?>
          <tr><td colspan="11" class="text-center py-5 text-muted">No stock transactions found matching your criteria.</td></tr>
        <?php else: ?>
          <?php foreach ($transactions as $txn): ?>
            <tr>
              <td>
                <span class="font-monospace fw-bold text-dark fs-xs"><?= e($txn['transaction_code']) ?></span>
              </td>
              <td class="small text-muted text-nowrap">
                <?= format_date($txn['transaction_date']) ?>
              </td>
              <td>
                <?php
                  $badge_class = 'bg-secondary';
                  if ($txn['transaction_type'] === 'IN') $badge_class = 'bg-success';
                  elseif ($txn['transaction_type'] === 'OUT') $badge_class = 'bg-danger';
                  elseif ($txn['transaction_type'] === 'RETURN') $badge_class = 'bg-info text-dark';
                  elseif ($txn['transaction_type'] === 'ADJUSTMENT') $badge_class = 'bg-warning text-dark';
                ?>
                <span class="badge <?= $badge_class ?>"><?= e($txn['transaction_type']) ?></span>
              </td>
              <td>
                <a href="../items/view.php?id=<?= $txn['item_id'] ?>" class="text-decoration-none text-dark fw-semibold small hover-primary">
                  <?= e($txn['item_name']) ?>
                </a>
                <span class="font-monospace text-muted fs-xs d-block"><?= e($txn['item_code']) ?></span>
              </td>
              <td>
                <span class="fw-bold <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? 'text-success' : ($txn['transaction_type'] === 'OUT' ? 'text-danger' : 'text-dark') ?>">
                  <?= ($txn['transaction_type'] === 'IN' || $txn['transaction_type'] === 'RETURN') ? '+' : ($txn['transaction_type'] === 'OUT' ? '-' : '') ?><?= $txn['quantity'] ?>
                </span>
                <span class="text-muted small"><?= e($txn['unit']) ?></span>
              </td>
              <td class="small">
                <span class="text-muted"><?= $txn['previous_stock'] ?></span>
                <i class="fa-solid fa-arrow-right-long text-muted mx-1 fs-xs"></i>
                <strong class="text-dark"><?= $txn['new_stock'] ?></strong>
              </td>
              <td class="small">
                <?php if ($txn['transaction_type'] === 'IN'): ?>
                  <span class="fw-medium text-dark"><i class="fa-solid fa-truck text-muted me-1"></i><?= e($txn['supplier_name'] ?? 'Vendor Direct') ?></span>
                <?php else: ?>
                  <?php if ($txn['employee_name']): ?>
                    <span class="fw-medium text-dark"><i class="fa-solid fa-user text-muted me-1"></i><?= e($txn['employee_name']) ?></span>
                    <?php if ($txn['department_name']): ?>
                      <div class="text-muted fs-xs"><?= e($txn['department_name']) ?></div>
                    <?php endif; ?>
                  <?php else: ?>
                    <span class="text-muted">Internal Store</span>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
              <td class="small font-monospace text-muted"><?= e($txn['reference_no'] ?? '-') ?></td>
              <td class="small text-muted"><?= e($txn['user_name']) ?></td>
              <td class="small text-muted" style="max-width: 180px;" title="<?= e($txn['remarks']) ?>">
                <?= e(mb_strimwidth($txn['remarks'] ?? '', 0, 35, '...')) ?>
              </td>
              <td class="text-end pe-3">
                <div class="btn-group btn-group-sm">
                  <a href="../slips/issue-slip.php?txn_id=<?= $txn['id'] ?>" class="btn btn-outline-primary" target="_blank" title="Print Material Slip">
                    <i class="fa-solid fa-print"></i>
                  </a>
                  <?php if ($txn['transaction_type'] === 'OUT'): ?>
                    <a href="../slips/gate-pass.php?txn_id=<?= $txn['id'] ?>" class="btn btn-outline-secondary" target="_blank" title="Print Gate Pass">
                      <i class="fa-solid fa-door-open"></i>
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($total_pages > 1): ?>
    <div class="card-footer bg-white py-3 d-flex justify-content-between align-items-center">
      <div class="text-muted small">
        Showing <?= min($offset + 1, $total_records) ?> to <?= min($offset + $limit, $total_records) ?> of <?= $total_records ?> transactions
      </div>
      <nav>
        <ul class="pagination pagination-sm mb-0">
          <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Previous</a>
          </li>
          <?php for ($p = 1; $p <= $total_pages; $p++): ?>
            <li class="page-item <?= ($p === $page) ? 'active' : '' ?>">
              <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>"><?= $p ?></a>
            </li>
          <?php endfor; ?>
          <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next</a>
          </li>
        </ul>
      </nav>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
