<?php
/**
 * Smart Store Room Management System
 * Stock Returns (Return from Employee OR Return to Supplier)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Stock Returns';
$db = Database::getConnection();
$error = '';

// Pre-generate transaction code
$auto_txn_code = generate_transaction_code($db, 'RET');

// Fetch items
$items = $db->query("
    SELECT id, item_code, item_name, current_stock, unit, purchase_price 
    FROM items 
    WHERE status = 'Active' 
    ORDER BY item_name ASC
")->fetchAll();

// Fetch employees
$employees = $db->query("
    SELECT e.id, e.employee_code, e.employee_name, d.department_name, e.department_id
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    WHERE e.status = 'Active'
    ORDER BY e.employee_name ASC
")->fetchAll();

// Fetch suppliers
$suppliers = $db->query("
    SELECT id, supplier_name 
    FROM suppliers 
    WHERE status = 'Active' 
    ORDER BY supplier_name ASC
")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $txn_code = trim($_POST['transaction_code'] ?? '');
    $return_direction = $_POST['return_direction'] ?? 'FROM_EMPLOYEE'; // 'FROM_EMPLOYEE' or 'TO_SUPPLIER'
    $item_id = (int)($_POST['item_id'] ?? 0);
    $employee_id = ($return_direction === 'FROM_EMPLOYEE') ? (int)($_POST['employee_id'] ?? 0) : null;
    $supplier_id = ($return_direction === 'TO_SUPPLIER') ? (int)($_POST['supplier_id'] ?? 0) : null;
    $quantity = (int)($_POST['quantity'] ?? 0);
    $return_reason = trim($_POST['return_reason'] ?? '');
    $reference_no = trim($_POST['reference_no'] ?? '');
    $transaction_date = trim($_POST['transaction_date'] ?? date('Y-m-d'));
    $remarks = trim($_POST['remarks'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification token invalid.";
    } elseif (empty($item_id) || $quantity <= 0) {
        $error = "Please specify an item and a positive return quantity.";
    } elseif ($return_direction === 'FROM_EMPLOYEE' && empty($employee_id)) {
        $error = "Please select the employee returning the items.";
    } elseif ($return_direction === 'TO_SUPPLIER' && empty($supplier_id)) {
        $error = "Please select the supplier receiving the returned goods.";
    } else {
        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT id, item_name, current_stock, unit, purchase_price FROM items WHERE id = :id FOR UPDATE");
            $stmt->execute([':id' => $item_id]);
            $item = $stmt->fetch();

            if (!$item) {
                throw new Exception("Item not found.");
            }

            $prev_stock = (int)$item['current_stock'];

            if ($return_direction === 'FROM_EMPLOYEE') {
                // Returns from employee restore back into inventory
                $new_stock = $prev_stock + $quantity;
                $txn_direction_note = "Return from Employee (Restocked)";
            } else {
                // Return to supplier reduces stock on hand
                if ($quantity > $prev_stock) {
                    throw new Exception("Cannot return {$quantity} {$item['unit']} to supplier; current stock on hand is only {$prev_stock}.");
                }
                $new_stock = $prev_stock - $quantity;
                $txn_direction_note = "Return to Supplier (Procurement Chargeback / Defect)";
            }

            // Update item stock
            $upd = $db->prepare("UPDATE items SET current_stock = :new_stock WHERE id = :id");
            $upd->execute([':new_stock' => $new_stock, ':id' => $item_id]);

            // Combine return reason into remarks
            $full_remarks = "[{$txn_direction_note} - Reason: {$return_reason}] " . $remarks;

            // Fetch employee department if applicable
            $department_id = null;
            if ($employee_id) {
                $dep_stmt = $db->prepare("SELECT department_id FROM employees WHERE id = :id");
                $dep_stmt->execute([':id' => $employee_id]);
                $department_id = $dep_stmt->fetchColumn() ?: null;
            }

            // Insert stock transaction
            $ins = $db->prepare("
                INSERT INTO stock_transactions (
                    transaction_code, item_id, transaction_type, quantity,
                    previous_stock, new_stock, employee_id, department_id,
                    supplier_id, unit_price, reference_no, remarks, transaction_date, created_by
                ) VALUES (
                    :txn_code, :item_id, 'RETURN', :quantity,
                    :prev_stock, :new_stock, :employee_id, :dept_id,
                    :supplier_id, :unit_price, :ref_no, :remarks, :txn_date, :created_by
                )
            ");
            $ins->execute([
                ':txn_code' => $txn_code,
                ':item_id' => $item_id,
                ':quantity' => $quantity,
                ':prev_stock' => $prev_stock,
                ':new_stock' => $new_stock,
                ':employee_id' => $employee_id,
                ':dept_id' => $department_id,
                ':supplier_id' => $supplier_id,
                ':unit_price' => $item['purchase_price'],
                ':ref_no' => $reference_no,
                ':remarks' => $full_remarks,
                ':txn_date' => $transaction_date,
                ':created_by' => $_SESSION['user_id']
            ]);

            $db->commit();

            set_flash('success', "Stock return processed successfully. New stock for '{$item['item_name']}' is {$new_stock} {$item['unit']}.");
            header("Location: history.php");
            exit;
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Stock Returns</h3>
        <p class="text-muted small mb-0">Record items returned by staff or vendor RMA debit returns.</p>
      </div>
      <a href="history.php" class="btn btn-outline-secondary">
        <i class="fa-solid fa-clock-rotate-left me-1"></i> View History
      </a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="returns.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <div class="card-body p-4">
        <div class="row g-3">
          <!-- Return Type Toggle -->
          <div class="col-12">
            <label class="form-label fw-bold text-dark">Return Workflow Type <span class="text-danger">*</span></label>
            <div class="d-flex gap-4 p-3 bg-light rounded-3 border">
              <div class="form-check">
                <input class="form-check-input" type="radio" name="return_direction" id="type_employee" value="FROM_EMPLOYEE" checked>
                <label class="form-check-label fw-semibold text-dark" for="type_employee">
                  <i class="fa-solid fa-user-check text-success me-1"></i> Return from Employee <small class="text-muted d-block fw-normal">(Restocks items back into active inventory)</small>
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="return_direction" id="type_supplier" value="TO_SUPPLIER">
                <label class="form-check-label fw-semibold text-dark" for="type_supplier">
                  <i class="fa-solid fa-truck-ramp-box text-warning me-1"></i> Return to Supplier <small class="text-muted d-block fw-normal">(Defects / RMAs / chargebacks deducted from inventory)</small>
                </label>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <label for="transaction_code" class="form-label">Transaction Code</label>
            <input type="text" class="form-control font-monospace bg-light" id="transaction_code" name="transaction_code" value="<?= e($auto_txn_code) ?>" readonly>
          </div>

          <div class="col-md-6">
            <label for="transaction_date" class="form-label">Return Date <span class="text-danger">*</span></label>
            <input type="date" class="form-control" id="transaction_date" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
          </div>

          <div class="col-12">
            <label for="item_id" class="form-label">Item / SKU <span class="text-danger">*</span></label>
            <select class="form-select" id="item_id" name="item_id" required>
              <option value="">-- Choose Item --</option>
              <?php foreach ($items as $it): ?>
                <option value="<?= $it['id'] ?>" data-stock="<?= $it['current_stock'] ?>" data-unit="<?= e($it['unit']) ?>">
                  <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?> (Current Stock: <?= $it['current_stock'] ?> <?= e($it['unit']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Conditional: Employee Section -->
          <div class="col-md-6" id="employee_field_wrapper">
            <label for="employee_id" class="form-label">Returning Employee <span class="text-danger">*</span></label>
            <select class="form-select" id="employee_id" name="employee_id">
              <option value="">-- Select Employee --</option>
              <?php foreach ($employees as $emp): ?>
                <option value="<?= $emp['id'] ?>">
                  <?= e($emp['employee_name']) ?> (<?= e($emp['department_name']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Conditional: Supplier Section -->
          <div class="col-md-6" id="supplier_field_wrapper" style="display: none;">
            <label for="supplier_id" class="form-label">Destination Supplier <span class="text-danger">*</span></label>
            <select class="form-select" id="supplier_id" name="supplier_id">
              <option value="">-- Select Supplier --</option>
              <?php foreach ($suppliers as $sup): ?>
                <option value="<?= $sup['id'] ?>"><?= e($sup['supplier_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Return Reason -->
          <div class="col-md-6">
            <label for="return_reason" class="form-label">Condition / Reason <span class="text-danger">*</span></label>
            <select class="form-select" id="return_reason" name="return_reason" required>
              <option value="Unused / Project Surplus">Unused / Project Surplus</option>
              <option value="Damaged / Malfunctioning">Damaged / Malfunctioning</option>
              <option value="Wrong Specification / Incompatible">Wrong Specification / Incompatible</option>
              <option value="Expired / Past Shelf Life">Expired / Past Shelf Life</option>
              <option value="Temporary Tool Return">Temporary Tool Return</option>
            </select>
          </div>

          <!-- Quantity -->
          <div class="col-md-6">
            <label for="quantity" class="form-label">Quantity to Return <span class="text-danger">*</span></label>
            <input type="number" class="form-control form-control-lg fw-bold" id="quantity" name="quantity" min="1" placeholder="0" required>
          </div>

          <div class="col-md-6">
            <label for="reference_no" class="form-label">RMA / Return Voucher #</label>
            <input type="text" class="form-control font-monospace" id="reference_no" name="reference_no" placeholder="e.g. RET-2026-004">
          </div>

          <div class="col-12">
            <label for="remarks" class="form-label">Detailed Notes / Condition Report</label>
            <textarea class="form-control" id="remarks" name="remarks" rows="2" placeholder="Describe package condition, testing results, or replacement status..."></textarea>
          </div>
        </div>
      </div>

      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
        <a href="history.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-rotate-left me-2"></i> Process Return
        </button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const empRadio = document.getElementById('type_employee');
  const supRadio = document.getElementById('type_supplier');
  const empWrapper = document.getElementById('employee_field_wrapper');
  const supWrapper = document.getElementById('supplier_field_wrapper');

  function toggleDirection() {
    if (empRadio.checked) {
      empWrapper.style.display = 'block';
      supWrapper.style.display = 'none';
    } else {
      empWrapper.style.display = 'none';
      supWrapper.style.display = 'block';
    }
  }

  empRadio.addEventListener('change', toggleDirection);
  supRadio.addEventListener('change', toggleDirection);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
