<?php
/**
 * Smart Store Room Management System
 * Stock IN (Receiving Inventory & Procurement Intake)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Stock In (Receive Inventory)';
$db = Database::getConnection();
$error = '';

$preselected_item_id = (int)($_GET['item_id'] ?? 0);

// Fetch all active items with their details for dropdown
$items = $db->query("
    SELECT i.id, i.item_code, i.item_name, i.current_stock, i.unit, i.purchase_price, i.supplier_id, i.maximum_stock
    FROM items i
    WHERE i.status = 'Active'
    ORDER BY i.item_name ASC
")->fetchAll();

// Fetch active suppliers
$suppliers = $db->query("SELECT id, supplier_name FROM suppliers WHERE status = 'Active' ORDER BY supplier_name ASC")->fetchAll();

// Pre-generate transaction code
$auto_txn_code = generate_transaction_code($db, 'IN');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $txn_code = trim($_POST['transaction_code'] ?? '');
    $item_id = (int)($_POST['item_id'] ?? 0);
    $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
    $quantity = (int)($_POST['quantity'] ?? 0);
    $unit_price = max(0, (float)($_POST['unit_price'] ?? 0));
    $reference_no = trim($_POST['reference_no'] ?? '');
    $transaction_date = trim($_POST['transaction_date'] ?? date('Y-m-d'));
    $remarks = trim($_POST['remarks'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification token expired or invalid.";
    } elseif (empty($item_id) || $quantity <= 0) {
        $error = "Please select a valid item and enter a quantity greater than zero.";
    } elseif (empty($transaction_date)) {
        $error = "Transaction date is required.";
    } else {
        try {
            $db->beginTransaction();

            // Lock item row for update to ensure concurrency safety
            $stmt = $db->prepare("SELECT id, item_name, current_stock, unit, maximum_stock FROM items WHERE id = :id FOR UPDATE");
            $stmt->execute([':id' => $item_id]);
            $item = $stmt->fetch();

            if (!$item) {
                throw new Exception("The selected item does not exist or has been removed.");
            }

            $previous_stock = (int)$item['current_stock'];
            $new_stock = $previous_stock + $quantity;

            // Optional warning check for overstocking
            $overstock_notice = '';
            if ($item['maximum_stock'] > 0 && $new_stock > $item['maximum_stock']) {
                $overstock_notice = " Notice: Current quantity now exceeds maximum storage threshold ({$item['maximum_stock']} {$item['unit']}).";
            }

            // 1. Update item current stock
            $upd = $db->prepare("UPDATE items SET current_stock = :new_stock, purchase_price = :unit_price WHERE id = :id");
            $upd->execute([
                ':new_stock' => $new_stock,
                ':unit_price' => $unit_price,
                ':id' => $item_id
            ]);

            // 2. Insert transaction record
            $ins = $db->prepare("
                INSERT INTO stock_transactions (
                    transaction_code, item_id, transaction_type, quantity,
                    previous_stock, new_stock, supplier_id, unit_price,
                    reference_no, remarks, transaction_date, created_by
                ) VALUES (
                    :txn_code, :item_id, 'IN', :quantity,
                    :prev_stock, :new_stock, :supplier_id, :unit_price,
                    :ref_no, :remarks, :txn_date, :created_by
                )
            ");
            $ins->execute([
                ':txn_code' => $txn_code,
                ':item_id' => $item_id,
                ':quantity' => $quantity,
                ':prev_stock' => $previous_stock,
                ':new_stock' => $new_stock,
                ':supplier_id' => $supplier_id,
                ':unit_price' => $unit_price,
                ':ref_no' => $reference_no,
                ':remarks' => $remarks,
                ':txn_date' => $transaction_date,
                ':created_by' => $_SESSION['user_id']
            ]);

            $db->commit();

            set_flash('success', "Stock In recorded successfully! {$quantity} {$item['unit']} added to '{$item['item_name']}'. New Balance: {$new_stock}.{$overstock_notice}");
            header("Location: history.php");
            exit;
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error = "Transaction failed: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Stock In &mdash; Receiving Inventory</h3>
        <p class="text-muted small mb-0">Record incoming goods from suppliers or procurement orders.</p>
      </div>
      <a href="history.php" class="btn btn-outline-secondary">
        <i class="fa-solid fa-clock-rotate-left me-1"></i> View History
      </a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="stock-in.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <div class="card-body p-4">
        <div class="row g-3">
          <!-- Transaction Code & Date -->
          <div class="col-md-6">
            <label for="transaction_code" class="form-label">Transaction Code <span class="text-danger">*</span></label>
            <input type="text" class="form-control font-monospace bg-light" id="transaction_code" name="transaction_code" value="<?= e($auto_txn_code) ?>" readonly required>
          </div>

          <div class="col-md-6">
            <label for="transaction_date" class="form-label">Received Date <span class="text-danger">*</span></label>
            <input type="date" class="form-control" id="transaction_date" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
          </div>

          <!-- Item Selection -->
          <div class="col-md-8">
            <label for="item_id" class="form-label">Item / SKU to Receive <span class="text-danger">*</span></label>
            <select class="form-select" id="item_id" name="item_id" required>
              <option value="">-- Choose Item --</option>
              <?php foreach ($items as $it): ?>
                <option value="<?= $it['id'] ?>" 
                  data-stock="<?= $it['current_stock'] ?>"
                  data-unit="<?= e($it['unit']) ?>"
                  data-price="<?= $it['purchase_price'] ?>"
                  data-supplier="<?= $it['supplier_id'] ?>"
                  <?= ($preselected_item_id == $it['id']) ? 'selected' : '' ?>>
                  <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?> (Current: <?= $it['current_stock'] ?> <?= e($it['unit']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Supplier Selection -->
          <div class="col-md-4">
            <label for="supplier_id" class="form-label">Delivering Supplier</label>
            <select class="form-select" id="supplier_id" name="supplier_id">
              <option value="">-- Direct / Vendor --</option>
              <?php foreach ($suppliers as $sup): ?>
                <option value="<?= $sup['id'] ?>"><?= e($sup['supplier_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Live Stock Info Preview -->
          <div class="col-12" id="item_stock_banner" style="display: none;">
            <div class="p-3 bg-light rounded-3 d-flex justify-content-between align-items-center">
              <div>
                <span class="text-muted small">Current Balance on Hand:</span>
                <strong class="fs-5 text-dark ms-2" id="display_current_stock">0</strong>
                <span class="text-muted" id="display_unit">units</span>
              </div>
              <div>
                <span class="text-muted small">Expected New Balance:</span>
                <strong class="fs-5 text-success ms-2" id="display_new_stock">0</strong>
              </div>
            </div>
          </div>

          <!-- Quantity, Price & Total -->
          <div class="col-md-4">
            <label for="quantity" class="form-label">Quantity Received <span class="text-danger">*</span></label>
            <input type="number" class="form-control form-control-lg fw-bold" id="quantity" name="quantity" min="1" placeholder="0" required>
          </div>

          <div class="col-md-4">
            <label for="unit_price" class="form-label">Unit Purchase Price ($)</label>
            <input type="number" step="0.01" min="0" class="form-control form-control-lg" id="unit_price" name="unit_price" placeholder="0.00">
          </div>

          <div class="col-md-4">
            <label class="form-label text-muted">Total Value ($)</label>
            <input type="text" class="form-control form-control-lg bg-light fw-bold text-primary" id="total_amount" readonly value="$0.00">
          </div>

          <!-- Reference & Remarks -->
          <div class="col-md-6">
            <label for="reference_no" class="form-label">Supplier Invoice / PO / Delivery Note #</label>
            <input type="text" class="form-control font-monospace" id="reference_no" name="reference_no" placeholder="e.g. INV-98231 or PO-4412">
          </div>

          <div class="col-md-6">
            <label for="remarks" class="form-label">Remarks / Storage Notes</label>
            <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Batch number, delivery bay, inspection status...">
          </div>
        </div>
      </div>

      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
        <a href="history.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-success px-4">
          <i class="fa-solid fa-arrow-down-to-bracket me-2"></i> Confirm Stock In
        </button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const itemSelect = document.getElementById('item_id');
  const supplierSelect = document.getElementById('supplier_id');
  const qtyInput = document.getElementById('quantity');
  const priceInput = document.getElementById('unit_price');
  const totalInput = document.getElementById('total_amount');
  const banner = document.getElementById('item_stock_banner');
  const currentStockSpan = document.getElementById('display_current_stock');
  const newStockSpan = document.getElementById('display_new_stock');
  const unitSpan = document.getElementById('display_unit');

  function updateCalculations() {
    const selected = itemSelect.options[itemSelect.selectedIndex];
    if (selected && selected.value) {
      const curStock = parseInt(selected.getAttribute('data-stock') || '0', 10);
      const unit = selected.getAttribute('data-unit') || 'units';
      const defaultPrice = parseFloat(selected.getAttribute('data-price') || '0');
      const defaultSupplier = selected.getAttribute('data-supplier');

      banner.style.display = 'block';
      currentStockSpan.textContent = curStock;
      unitSpan.textContent = unit;

      if (!priceInput.value && defaultPrice > 0) {
        priceInput.value = defaultPrice.toFixed(2);
      }
      if (!supplierSelect.value && defaultSupplier) {
        supplierSelect.value = defaultSupplier;
      }

      const qty = parseInt(qtyInput.value || '0', 10);
      newStockSpan.textContent = (curStock + qty) + ' ' + unit;

      const price = parseFloat(priceInput.value || '0');
      totalInput.value = '$' + (qty * price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else {
      banner.style.display = 'none';
      totalInput.value = '$0.00';
    }
  }

  itemSelect.addEventListener('change', updateCalculations);
  qtyInput.addEventListener('input', updateCalculations);
  priceInput.addEventListener('input', updateCalculations);

  if (itemSelect.value) {
    updateCalculations();
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
