<?php
/**
 * Smart Store Room Management System
 * Stock OUT (Issuing Inventory to Staff & Departments)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Stock Out (Issue Inventory)';
$db = Database::getConnection();
$error = '';

$preselected_item_id = (int)($_GET['item_id'] ?? 0);
$preselected_emp_id = (int)($_GET['employee_id'] ?? 0);

// Fetch items that currently have stock > 0
$items = $db->query("
    SELECT i.id, i.item_code, i.item_name, i.current_stock, i.unit, i.reorder_level, i.selling_or_issue_price
    FROM items i
    WHERE i.status = 'Active' AND i.current_stock > 0
    ORDER BY i.item_name ASC
")->fetchAll();

// Fetch active employees with their departments
$employees = $db->query("
    SELECT e.id, e.employee_code, e.employee_name, e.department_id, d.department_name
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    WHERE e.status = 'Active'
    ORDER BY e.employee_name ASC
")->fetchAll();

// Auto-generate transaction code
$auto_txn_code = generate_transaction_code($db, 'OUT');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $txn_code = trim($_POST['transaction_code'] ?? '');
    $item_id = (int)($_POST['item_id'] ?? 0);
    $employee_id = (int)($_POST['employee_id'] ?? 0);
    $department_id = (int)($_POST['department_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 0);
    $reference_no = trim($_POST['reference_no'] ?? '');
    $transaction_date = trim($_POST['transaction_date'] ?? date('Y-m-d'));
    $remarks = trim($_POST['remarks'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Security token validation failed.";
    } elseif (empty($item_id) || empty($employee_id) || $quantity <= 0) {
        $error = "Please select an item, an employee, and specify a quantity greater than zero.";
    } elseif (empty($transaction_date)) {
        $error = "Issue date is required.";
    } else {
        try {
            $db->beginTransaction();

            // Lock item row to strictly prevent race conditions and negative inventory
            $stmt = $db->prepare("SELECT id, item_name, current_stock, reorder_level, unit, selling_or_issue_price FROM items WHERE id = :id FOR UPDATE");
            $stmt->execute([':id' => $item_id]);
            $item = $stmt->fetch();

            if (!$item) {
                throw new Exception("Selected item not found.");
            }

            $current_stock = (int)$item['current_stock'];

            // Prevent negative stock
            if ($quantity > $current_stock) {
                throw new Exception("Insufficient stock! Requested {$quantity} {$item['unit']}, but only {$current_stock} {$item['unit']} available in inventory.");
            }

            $previous_stock = $current_stock;
            $new_stock = $previous_stock - $quantity;

            // Update item table
            $upd = $db->prepare("UPDATE items SET current_stock = :new_stock WHERE id = :id");
            $upd->execute([':new_stock' => $new_stock, ':id' => $item_id]);

            // Insert stock transaction record
            $ins = $db->prepare("
                INSERT INTO stock_transactions (
                    transaction_code, item_id, transaction_type, quantity,
                    previous_stock, new_stock, employee_id, department_id,
                    unit_price, reference_no, remarks, transaction_date, created_by
                ) VALUES (
                    :txn_code, :item_id, 'OUT', :quantity,
                    :prev_stock, :new_stock, :employee_id, :dept_id,
                    :unit_price, :ref_no, :remarks, :txn_date, :created_by
                )
            ");
            $ins->execute([
                ':txn_code' => $txn_code,
                ':item_id' => $item_id,
                ':quantity' => $quantity,
                ':prev_stock' => $previous_stock,
                ':new_stock' => $new_stock,
                ':employee_id' => $employee_id,
                ':dept_id' => $department_id,
                ':unit_price' => $item['selling_or_issue_price'],
                ':ref_no' => $reference_no,
                ':remarks' => $remarks,
                ':txn_date' => $transaction_date,
                ':created_by' => $_SESSION['user_id']
            ]);

            $db->commit();

            // Build helpful alert warning if reorder level breached
            $alert_warning = "";
            if ($new_stock == 0) {
                $alert_warning = " ATTENTION: Item is now OUT OF STOCK (0 {$item['unit']}).";
            } elseif ($new_stock <= $item['reorder_level']) {
                $alert_warning = " WARNING: Stock has dropped to {$new_stock} {$item['unit']}, which is at or below the reorder point ({$item['reorder_level']}).";
            }

            set_flash('success', "Stock Out issued successfully! {$quantity} {$item['unit']} deducted. Remaining balance: {$new_stock}.{$alert_warning}");
            header("Location: history.php");
            exit;
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Stock Out &mdash; Issue Inventory</h3>
        <p class="text-muted small mb-0">Authorize and distribute store supplies to verified employees and departments.</p>
      </div>
      <a href="history.php" class="btn btn-outline-secondary">
        <i class="fa-solid fa-clock-rotate-left me-1"></i> View History
      </a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="stock-out.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <div class="card-body p-4">
        <div class="row g-3">
          <!-- Transaction Code & Issue Date -->
          <div class="col-md-6">
            <label for="transaction_code" class="form-label">Transaction Code <span class="text-danger">*</span></label>
            <input type="text" class="form-control font-monospace bg-light" id="transaction_code" name="transaction_code" value="<?= e($auto_txn_code) ?>" readonly required>
          </div>

          <div class="col-md-6">
            <label for="transaction_date" class="form-label">Issue Date <span class="text-danger">*</span></label>
            <input type="date" class="form-control" id="transaction_date" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
          </div>

          <!-- Item Selection -->
          <div class="col-12">
            <label for="item_id" class="form-label">Item / SKU to Issue <span class="text-danger">*</span></label>
            <select class="form-select" id="item_id" name="item_id" required>
              <option value="">-- Select Available Item --</option>
              <?php foreach ($items as $it): ?>
                <option value="<?= $it['id'] ?>" 
                  data-stock="<?= $it['current_stock'] ?>"
                  data-unit="<?= e($it['unit']) ?>"
                  data-reorder="<?= $it['reorder_level'] ?>"
                  <?= ($preselected_item_id == $it['id']) ? 'selected' : '' ?>>
                  <?= e($it['item_code']) ?> &mdash; <?= e($it['item_name']) ?> (Available: <?= $it['current_stock'] ?> <?= e($it['unit']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Real-Time Stock Feedback Banner -->
          <div class="col-12" id="stock_status_box" style="display: none;">
            <div class="p-3 bg-light rounded-3 d-flex justify-content-between align-items-center">
              <div>
                <span class="text-muted small">Current Available:</span>
                <strong class="fs-5 text-dark ms-1" id="box_current_stock">0</strong>
                <span class="text-muted" id="box_unit">units</span>
              </div>
              <div>
                <span class="text-muted small">Reorder Threshold:</span>
                <span class="badge bg-warning-subtle text-dark border ms-1" id="box_reorder">0</span>
              </div>
              <div>
                <span class="text-muted small">Balance After Issue:</span>
                <strong class="fs-5 ms-1" id="box_remaining_stock">0</strong>
              </div>
            </div>
          </div>

          <!-- Quantity to Issue -->
          <div class="col-md-6">
            <label for="quantity" class="form-label">Quantity to Issue <span class="text-danger">*</span></label>
            <input type="number" class="form-control form-control-lg fw-bold" id="quantity" name="quantity" min="1" placeholder="0" required>
            <div class="form-text text-danger fw-semibold" id="stock_error_msg" style="display: none;">
              <i class="fa-solid fa-triangle-exclamation me-1"></i> Cannot issue more than available stock!
            </div>
          </div>

          <div class="col-md-6">
            <label for="reference_no" class="form-label">Requisition / Work Order #</label>
            <input type="text" class="form-control form-control-lg font-monospace" id="reference_no" name="reference_no" placeholder="e.g. REQ-2026-0819">
          </div>

          <!-- Employee Selection -->
          <div class="col-md-6">
            <label for="employee_id" class="form-label">Recipient Employee <span class="text-danger">*</span></label>
            <select class="form-select" id="employee_id" name="employee_id" required>
              <option value="">-- Select Recipient --</option>
              <?php foreach ($employees as $emp): ?>
                <option value="<?= $emp['id'] ?>" 
                  data-dept-id="<?= $emp['department_id'] ?>" 
                  data-dept-name="<?= e($emp['department_name']) ?>"
                  <?= ($preselected_emp_id == $emp['id']) ? 'selected' : '' ?>>
                  <?= e($emp['employee_name']) ?> (<?= e($emp['employee_code']) ?> &bull; <?= e($emp['department_name']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Department (Auto-filled) -->
          <div class="col-md-6">
            <label for="department_name_display" class="form-label">Assigned Department</label>
            <input type="text" class="form-control bg-light" id="department_name_display" placeholder="Select an employee above" readonly>
            <input type="hidden" id="department_id" name="department_id" value="">
          </div>

          <!-- Purpose / Remarks -->
          <div class="col-12">
            <label for="remarks" class="form-label">Purpose / Project / Issue Notes</label>
            <textarea class="form-control" id="remarks" name="remarks" rows="2" placeholder="e.g. Project Apollo server rack upgrade, replacement for worn unit, etc."></textarea>
          </div>
        </div>
      </div>

      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between align-items-center">
        <a href="history.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" id="submit_btn" class="btn btn-danger px-4">
          <i class="fa-solid fa-arrow-up-from-bracket me-2"></i> Confirm Stock Out
        </button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const itemSelect = document.getElementById('item_id');
  const empSelect = document.getElementById('employee_id');
  const deptDisplay = document.getElementById('department_name_display');
  const deptIdInput = document.getElementById('department_id');
  const qtyInput = document.getElementById('quantity');
  const statusBox = document.getElementById('stock_status_box');
  const curStockSpan = document.getElementById('box_current_stock');
  const reorderSpan = document.getElementById('box_reorder');
  const remainingSpan = document.getElementById('box_remaining_stock');
  const unitSpan = document.getElementById('box_unit');
  const errorMsg = document.getElementById('stock_error_msg');
  const submitBtn = document.getElementById('submit_btn');

  function updateItemState() {
    const selected = itemSelect.options[itemSelect.selectedIndex];
    if (selected && selected.value) {
      const maxStock = parseInt(selected.getAttribute('data-stock') || '0', 10);
      const unit = selected.getAttribute('data-unit') || 'units';
      const reorder = parseInt(selected.getAttribute('data-reorder') || '0', 10);

      statusBox.style.display = 'block';
      curStockSpan.textContent = maxStock;
      unitSpan.textContent = unit;
      reorderSpan.textContent = reorder + ' ' + unit;
      qtyInput.max = maxStock;

      const qty = parseInt(qtyInput.value || '0', 10);
      const remaining = maxStock - qty;
      remainingSpan.textContent = remaining + ' ' + unit;

      if (remaining < 0) {
        remainingSpan.className = 'fs-5 ms-1 text-danger fw-bold';
        errorMsg.style.display = 'block';
        submitBtn.disabled = true;
      } else {
        remainingSpan.className = remaining <= reorder ? 'fs-5 ms-1 text-warning fw-bold' : 'fs-5 ms-1 text-success fw-bold';
        errorMsg.style.display = 'none';
        submitBtn.disabled = false;
      }
    } else {
      statusBox.style.display = 'none';
      submitBtn.disabled = false;
    }
  }

  function updateEmployeeDept() {
    const selected = empSelect.options[empSelect.selectedIndex];
    if (selected && selected.value) {
      deptDisplay.value = selected.getAttribute('data-dept-name') || '';
      deptIdInput.value = selected.getAttribute('data-dept-id') || '';
    } else {
      deptDisplay.value = '';
      deptIdInput.value = '';
    }
  }

  itemSelect.addEventListener('change', updateItemState);
  qtyInput.addEventListener('input', updateItemState);
  empSelect.addEventListener('change', updateEmployeeDept);

  if (itemSelect.value) updateItemState();
  if (empSelect.value) updateEmployeeDept();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
