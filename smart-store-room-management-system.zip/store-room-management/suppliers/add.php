<?php
/**
 * Smart Store Room Management System
 * Add Supplier
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Store Manager']);

$page_title = 'Add Supplier';
$db = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_name = trim($_POST['supplier_name'] ?? '');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($supplier_name) || empty($contact_person) || empty($phone) || empty($email)) {
        $error = "Please fill in all required supplier fields.";
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO suppliers (supplier_name, contact_person, phone, email, address, status)
                VALUES (:name, :contact, :phone, :email, :address, :status)
            ");
            $stmt->execute([
                ':name' => $supplier_name,
                ':contact' => $contact_person,
                ':phone' => $phone,
                ':email' => $email,
                ':address' => $address,
                ':status' => $status
            ]);
            
            set_flash('success', "Supplier '{$supplier_name}' added successfully.");
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            $error = "Error adding supplier: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold mb-0 text-dark">Add New Supplier</h3>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="add.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-12">
            <label for="supplier_name" class="form-label">Supplier / Company Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="supplier_name" name="supplier_name" placeholder="e.g. Apex Global Supplies Inc" required>
          </div>
          <div class="col-md-6">
            <label for="contact_person" class="form-label">Contact Person <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="contact_person" name="contact_person" placeholder="e.g. John Doe" required>
          </div>
          <div class="col-md-6">
            <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="+1 (555) 019-2834" required>
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Corporate Email <span class="text-danger">*</span></label>
            <input type="email" class="form-control" id="email" name="email" placeholder="sales@apexsupplies.com" required>
          </div>
          <div class="col-md-6">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status">
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div class="col-12">
            <label for="address" class="form-label">Physical / Warehouse Address <span class="text-danger">*</span></label>
            <textarea class="form-control" id="address" name="address" rows="3" placeholder="Building, Street, Suite, City, State..." required></textarea>
          </div>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-floppy-disk me-2"></i> Save Supplier
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
