<?php
/**
 * Smart Store Room Management System
 * Delete Supplier Handler
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid supplier ID.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

try {
    $chk_txn = $db->prepare("SELECT COUNT(*) FROM stock_transactions WHERE supplier_id = :id");
    $chk_txn->execute([':id' => $id]);
    $txn_count = (int)$chk_txn->fetchColumn();

    if ($txn_count > 0) {
        set_flash('error', "Cannot delete supplier with {$txn_count} recorded procurement transactions. Deactivate the supplier instead to maintain audit trails.");
        header("Location: index.php");
        exit;
    }

    $del = $db->prepare("DELETE FROM suppliers WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', "Supplier deleted successfully.");
} catch (Exception $e) {
    set_flash('error', "Database error: " . $e->getMessage());
}

header("Location: index.php");
exit;
