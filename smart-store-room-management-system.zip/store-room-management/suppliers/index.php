<?php
/**
 * Smart Store Room Management System
 * Supplier Management Listing & Procurement Stats
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_auth();

$page_title = 'Suppliers';
$db = Database::getConnection();

$search = trim($_GET['search'] ?? '');
$params = [];
$where_sql = "1=1";

if ($search !== '') {
    $where_sql = "(s.supplier_name LIKE :search OR s.contact_person LIKE :search OR s.email LIKE :search OR s.phone LIKE :search)";
    $params[':search'] = "%{$search}%";
}

// Fetch suppliers with metrics: Total items supplied and total units received via Stock IN
$sql = "
    SELECT 
        s.*,
        COUNT(DISTINCT i.id) as items_supplied_count,
        COALESCE(SUM(CASE WHEN st.transaction_type = 'IN' THEN st.quantity ELSE 0 END), 0) as total_units_received
    FROM suppliers s
    LEFT JOIN items i ON s.id = i.supplier_id
    LEFT JOIN stock_transactions st ON s.id = st.supplier_id
    WHERE {$where_sql}
    GROUP BY s.id
    ORDER BY s.supplier_name ASC
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$suppliers = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">Supplier Directory</h3>
    <p class="text-muted mb-0 small">Manage vendor relationships, contacts, procurement volumes, and supply histories.</p>
  </div>
  <?php if (has_role(['Admin', 'Store Manager'])): ?>
    <a href="add.php" class="btn btn-primary-deep">
      <i class="fa-solid fa-plus me-1"></i> Add Supplier
    </a>
  <?php endif; ?>
</div>

<!-- Search Bar -->
<div class="card border-0 shadow-sm rounded-3 mb-4">
  <div class="card-body p-3">
    <form method="GET" action="index.php" class="row g-2 align-items-center">
      <div class="col-md-6">
        <div class="input-group">
          <span class="input-group-text bg-white text-muted border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" name="search" class="form-control border-start-0" placeholder="Search supplier by name, contact person, phone, or email..." value="<?= e($search) ?>">
        </div>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-primary-deep w-100">Search</button>
      </div>
      <?php if ($search !== ''): ?>
        <div class="col-md-2">
          <a href="index.php" class="btn btn-outline-secondary w-100">Clear</a>
        </div>
      <?php endif; ?>
    </form>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Supplier Details</th>
          <th>Contact Person</th>
          <th>Phone & Email</th>
          <th>Supplied SKUs</th>
          <th>Total Units Received</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($suppliers)): ?>
          <tr><td colspan="7" class="text-center py-5 text-muted">No suppliers found.</td></tr>
        <?php else: ?>
          <?php foreach ($suppliers as $sup): ?>
            <tr>
              <td>
                <div class="fw-bold text-dark fs-6"><?= e($sup['supplier_name']) ?></div>
                <small class="text-muted"><i class="fa-solid fa-location-dot me-1 text-danger"></i><?= e($sup['address']) ?></small>
              </td>
              <td>
                <div class="fw-medium text-dark"><?= e($sup['contact_person']) ?></div>
              </td>
              <td>
                <div><i class="fa-solid fa-phone text-muted me-1 small"></i><?= e($sup['phone']) ?></div>
                <small class="text-muted"><i class="fa-regular fa-envelope me-1"></i><?= e($sup['email']) ?></small>
              </td>
              <td>
                <span class="badge bg-light text-dark border px-2 py-1"><?= $sup['items_supplied_count'] ?> items</span>
              </td>
              <td>
                <span class="fw-bold text-success">+<?= number_format($sup['total_units_received']) ?> units</span>
              </td>
              <td>
                <span class="badge <?= ($sup['status'] === 'Active') ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary' ?>">
                  <?= e($sup['status']) ?>
                </span>
              </td>
              <td class="text-end">
                <a href="../reports/stock-in-report.php?supplier_id=<?= $sup['id'] ?>" class="btn btn-sm btn-outline-info" title="View Supplier IN History">
                  <i class="fa-solid fa-clock-rotate-left"></i> History
                </a>
                <?php if (has_role(['Admin', 'Store Manager'])): ?>
                  <a href="edit.php?id=<?= $sup['id'] ?>" class="btn btn-sm btn-outline-primary ms-1" title="Edit Supplier">
                    <i class="fa-regular fa-pen-to-square"></i>
                  </a>
                <?php endif; ?>
                <?php if (has_role(['Admin'])): ?>
                  <a href="delete.php?id=<?= $sup['id'] ?>" class="btn btn-sm btn-outline-danger ms-1" onclick="return confirm('Delete this supplier record?');" title="Delete Supplier">
                    <i class="fa-regular fa-trash-can"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
