<?php
/**
 * Smart Store Room Management System
 * Add User (Admin Only)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$page_title = 'Add New User';
$db = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'Store Staff';
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($name) || empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } else {
        try {
            // Check username & email uniqueness
            $chk = $db->prepare("SELECT COUNT(*) FROM users WHERE username = :u OR email = :e");
            $chk->execute([':u' => $username, ':e' => $email]);
            if ($chk->fetchColumn() > 0) {
                $error = "Username or Email address is already in use.";
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $ins = $db->prepare("
                    INSERT INTO users (name, username, email, password, role, status)
                    VALUES (:name, :username, :email, :pwd, :role, :status)
                ");
                $ins->execute([
                    ':name' => $name,
                    ':username' => $username,
                    ':email' => $email,
                    ':pwd' => $hashed,
                    ':role' => $role,
                    ':status' => $status
                ]);

                set_flash('success', "User account '{$username}' created successfully.");
                header("Location: index.php");
                exit;
            }
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold mb-0 text-dark">Add New User Account</h3>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="add.php" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-12">
            <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="name" name="name" placeholder="e.g. Alex Henderson" value="<?= e($_POST['name'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
            <input type="text" class="form-control font-monospace" id="username" name="username" placeholder="e.g. ahenderson" value="<?= e($_POST['username'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
            <input type="email" class="form-control" id="email" name="email" placeholder="alex@company.com" value="<?= e($_POST['email'] ?? '') ?>" required>
          </div>
          <div class="col-md-6">
            <label for="password" class="form-label">Initial Password <span class="text-danger">*</span></label>
            <input type="password" class="form-control" id="password" name="password" required minlength="6">
            <div class="form-text">Minimum 6 characters.</div>
          </div>
          <div class="col-md-6">
            <label for="role" class="form-label">System Role <span class="text-danger">*</span></label>
            <select class="form-select" id="role" name="role" required>
              <option value="Store Staff">Store Staff (Stock In/Out, View)</option>
              <option value="Store Manager">Store Manager (Stock Operations, Inventory Editing)</option>
              <option value="Admin">Admin (Full System Control & Users)</option>
            </select>
          </div>
          <div class="col-md-6">
            <label for="status" class="form-label">Account Status</label>
            <select class="form-select" id="status" name="status">
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-user-check me-2"></i> Create Account
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
