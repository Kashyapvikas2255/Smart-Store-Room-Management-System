<?php
/**
 * Smart Store Room Management System
 * Delete User Account Handler
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid user identifier.");
    header("Location: index.php");
    exit;
}

if ($id == $_SESSION['user_id']) {
    set_flash('error', "Security violation: You cannot delete your currently active account.");
    header("Location: index.php");
    exit;
}

$db = Database::getConnection();

try {
    // Check if target is an Admin and whether they are the last Admin in system
    $target_stmt = $db->prepare("SELECT role, username FROM users WHERE id = :id");
    $target_stmt->execute([':id' => $id]);
    $target = $target_stmt->fetch();

    if (!$target) {
        set_flash('error', "User not found.");
        header("Location: index.php");
        exit;
    }

    if ($target['role'] === 'Admin') {
        $admin_count = (int)$db->query("SELECT COUNT(*) FROM users WHERE role = 'Admin'")->fetchColumn();
        if ($admin_count <= 1) {
            set_flash('error', "Cannot delete the sole remaining Administrator account.");
            header("Location: index.php");
            exit;
        }
    }

    // Check if user has generated transactions
    $txn_chk = $db->prepare("SELECT COUNT(*) FROM stock_transactions WHERE created_by = :id");
    $txn_chk->execute([':id' => $id]);
    if ($txn_chk->fetchColumn() > 0) {
        set_flash('error', "Cannot delete user '{$target['username']}' because audit records and transactions are linked to this account. You may deactivate the account instead.");
        header("Location: index.php");
        exit;
    }

    $del = $db->prepare("DELETE FROM users WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', "User account '{$target['username']}' deleted successfully.");
} catch (Exception $e) {
    set_flash('error', "Database error: " . $e->getMessage());
}

header("Location: index.php");
exit;
