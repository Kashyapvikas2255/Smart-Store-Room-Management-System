<?php
/**
 * Smart Store Room Management System
 * Edit User (Admin Only)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$page_title = 'Edit User Account';
$db = Database::getConnection();
$error = '';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('error', "Invalid user specified.");
    header("Location: index.php");
    exit;
}

$stmt = $db->prepare("SELECT id, name, username, email, role, status FROM users WHERE id = :id");
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();

if (!$user) {
    set_flash('error', "User not found.");
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'Store Staff';
    $status = $_POST['status'] ?? 'Active';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "CSRF verification failed.";
    } elseif (empty($name) || empty($email)) {
        $error = "Name and Email cannot be empty.";
    } else {
        try {
            // Cannot deactivate yourself
            if ($id == $_SESSION['user_id'] && $status !== 'Active') {
                throw new Exception("You cannot deactivate your own administrative account.");
            }

            // Cannot demote yourself
            if ($id == $_SESSION['user_id'] && $role !== 'Admin') {
                throw new Exception("You cannot remove your own Admin role.");
            }

            if (!empty($password)) {
                if (strlen($password) < 6) {
                    throw new Exception("New password must be at least 6 characters.");
                }
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $upd = $db->prepare("UPDATE users SET name = :name, email = :email, password = :pwd, role = :role, status = :status WHERE id = :id");
                $upd->execute([':name' => $name, ':email' => $email, ':pwd' => $hashed, ':role' => $role, ':status' => $status, ':id' => $id]);
            } else {
                $upd = $db->prepare("UPDATE users SET name = :name, email = :email, role = :role, status = :status WHERE id = :id");
                $upd->execute([':name' => $name, ':email' => $email, ':role' => $role, ':status' => $status, ':id' => $id]);
            }

            // If updating currently logged in user, refresh session name
            if ($id == $_SESSION['user_id']) {
                $_SESSION['user_name'] = $name;
            }

            set_flash('success', "User account updated successfully.");
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h3 class="fw-bold mb-0 text-dark">Edit User Account: <?= e($user['username']) ?></h3>
        <p class="text-muted small mb-0">Update account credentials, operational roles, and access state.</p>
      </div>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?= $id ?>" class="card border-0 shadow-sm rounded-3">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label text-muted">Username (Immutable)</label>
            <input type="text" class="form-control font-monospace bg-light" value="<?= e($user['username']) ?>" readonly>
          </div>
          <div class="col-md-6">
            <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="name" name="name" value="<?= e($user['name']) ?>" required>
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
            <input type="email" class="form-control" id="email" name="email" value="<?= e($user['email']) ?>" required>
          </div>
          <div class="col-md-6">
            <label for="password" class="form-label">Reset Password <small class="text-muted fw-normal">(Optional)</small></label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Leave empty to retain existing password">
          </div>
          <div class="col-md-6">
            <label for="role" class="form-label">System Role <span class="text-danger">*</span></label>
            <select class="form-select" id="role" name="role" required>
              <option value="Store Staff" <?= ($user['role'] === 'Store Staff') ? 'selected' : '' ?>>Store Staff</option>
              <option value="Store Manager" <?= ($user['role'] === 'Store Manager') ? 'selected' : '' ?>>Store Manager</option>
              <option value="Admin" <?= ($user['role'] === 'Admin') ? 'selected' : '' ?>>Admin</option>
            </select>
          </div>
          <div class="col-md-6">
            <label for="status" class="form-label">Account Status</label>
            <select class="form-select" id="status" name="status">
              <option value="Active" <?= ($user['status'] === 'Active') ? 'selected' : '' ?>>Active</option>
              <option value="Inactive" <?= ($user['status'] === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-footer bg-light py-3 px-4 d-flex justify-content-between">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary-deep px-4">
          <i class="fa-solid fa-check me-2"></i> Update Account
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
