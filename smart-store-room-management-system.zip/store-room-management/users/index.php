<?php
/**
 * Smart Store Room Management System
 * System User Management (Admin Only)
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin']);

$page_title = 'User Accounts';
$db = Database::getConnection();

$users = $db->query("SELECT id, name, username, email, role, status, created_at FROM users ORDER BY id ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
  <div>
    <h3 class="fw-bold mb-1 text-dark">User Account Management</h3>
    <p class="text-muted mb-0 small">Control operator permissions, roles, and administrative access credentials.</p>
  </div>
  <a href="add.php" class="btn btn-primary-deep">
    <i class="fa-solid fa-user-plus me-1"></i> Add New User
  </a>
</div>

<div class="card border-0 shadow-sm rounded-3">
  <div class="table-responsive">
    <table class="table table-custom table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>User</th>
          <th>Username</th>
          <th>Email Address</th>
          <th>Role / Permission Level</th>
          <th>Account Status</th>
          <th>Created Date</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                  <?= strtoupper(substr($u['name'], 0, 1)) ?>
                </div>
                <div>
                  <strong class="text-dark"><?= e($u['name']) ?></strong>
                  <?php if ($u['id'] == $_SESSION['user_id']): ?>
                    <span class="badge bg-info-subtle text-info border ms-1 fs-xs">You</span>
                  <?php endif; ?>
                </div>
              </div>
            </td>
            <td>
              <span class="font-monospace text-dark fw-semibold"><?= e($u['username']) ?></span>
            </td>
            <td class="small text-muted">
              <?= e($u['email']) ?>
            </td>
            <td>
              <?php
                $role_badge = 'bg-secondary';
                if ($u['role'] === 'Admin') $role_badge = 'bg-danger-subtle text-danger border border-danger-subtle';
                elseif ($u['role'] === 'Store Manager') $role_badge = 'bg-primary-subtle text-primary border border-primary-subtle';
                elseif ($u['role'] === 'Store Staff') $role_badge = 'bg-success-subtle text-success border border-success-subtle';
              ?>
              <span class="badge <?= $role_badge ?> fw-semibold"><?= e($u['role']) ?></span>
            </td>
            <td>
              <span class="badge <?= ($u['status'] === 'Active') ? 'bg-success' : 'bg-secondary' ?>">
                <?= e($u['status']) ?>
              </span>
            </td>
            <td class="small text-muted"><?= format_date($u['created_at']) ?></td>
            <td class="text-end">
              <a href="edit.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit User">
                <i class="fa-regular fa-pen-to-square"></i>
              </a>
              <?php if ($u['id'] != $_SESSION['user_id']): ?>
                <a href="delete.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger ms-1" onclick="return confirm('Are you sure you want to remove user \'<?= e($u['username']) ?>\'?');" title="Delete User">
                  <i class="fa-regular fa-trash-can"></i>
                </a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
